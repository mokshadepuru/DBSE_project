import { Bus, Navigation } from "lucide-react";
import "./MapPanel.css";

/**
 * A stylised, illustrative map. It does not call any mapping API — it lays
 * the route's stops out along a fixed path and places the bus marker
 * according to `progress` (0–100). Swap this component's internals for a
 * real Google Maps / Mapbox instance once the backend streams live
 * coordinates; the props contract (stops + progress + currentLocation)
 * can stay the same.
 */
export default function MapPanel({
  stops,
  progress = 0,
  currentLocation,
  busLabel = "BUS-01",
  lastUpdated = "just now",
  compact = false,
}) {
  const n = stops.length;
  const positions = stops.map((_, i) => (i / (n - 1)) * 84 + 8); // 8%..92%

  // Bus marker sits along the polyline according to progress
  const busX = 8 + (progress / 100) * 84;
  const busY = 50 + Math.sin((progress / 100) * Math.PI) * -14;

  return (
    <div className={`map-panel ${compact ? "map-panel--compact" : ""}`}>
      <div className="map-panel__badge">
        <span className="map-panel__live-dot" />
        {busLabel} • LIVE
      </div>

      <svg viewBox="0 0 400 220" className="map-panel__svg" preserveAspectRatio="none">
        <defs>
          <pattern id="mapGrid" width="20" height="20" patternUnits="userSpaceOnUse">
            <path d="M 20 0 L 0 0 0 20" fill="none" stroke="#f0dde2" strokeWidth="1" />
          </pattern>
        </defs>
        <rect width="400" height="220" fill="url(#mapGrid)" />

        {/* route line */}
        <path
          d={`M ${positions.map((p, i) => `${(p / 100) * 400} ${110 + Math.sin((p / 100) * Math.PI) * -30}`).join(" L ")}`}
          fill="none"
          stroke="#c85a6e"
          strokeWidth="3"
          strokeDasharray="1 10"
          strokeLinecap="round"
        />
        <path
          d={`M ${positions.map((p, i) => `${(p / 100) * 400} ${110 + Math.sin((p / 100) * Math.PI) * -30}`).join(" L ")}`}
          fill="none"
          stroke="#8f3048"
          strokeWidth="2.5"
          strokeLinecap="round"
          opacity="0.9"
        />

        {/* completed portion, heavier line */}
        <path
          d={`M ${positions
            .filter((p) => p <= 8 + (progress / 100) * 84)
            .map((p) => `${(p / 100) * 400} ${110 + Math.sin((p / 100) * Math.PI) * -30}`)
            .join(" L ")} L ${(busX / 100) * 400} ${110 + Math.sin((busX / 100) * Math.PI) * -30}`}
          fill="none"
          stroke="#6b1e2d"
          strokeWidth="4"
          strokeLinecap="round"
        />

        {/* stop markers */}
        {stops.map((s, i) => {
          const x = (positions[i] / 100) * 400;
          const y = 110 + Math.sin((positions[i] / 100) * Math.PI) * -30;
          const passed = positions[i] <= busX;
          return (
            <g key={s.name}>
              <circle cx={x} cy={y} r="7" fill={passed ? "#6b1e2d" : "#ffffff"} stroke="#6b1e2d" strokeWidth="2.5" />
              {i === 0 || i === n - 1 ? (
                <circle cx={x} cy={y} r="3" fill={passed ? "#fff8f9" : "#6b1e2d"} />
              ) : null}
              <text x={x} y={y - 16} textAnchor="middle" className="map-panel__stop-label">
                {s.name}
              </text>
            </g>
          );
        })}

        {/* bus marker */}
        <g transform={`translate(${(busX / 100) * 400}, ${110 + Math.sin((busX / 100) * Math.PI) * -30})`}>
          <circle r="14" fill="#6b1e2d" opacity="0.16">
            <animate attributeName="r" values="12;18;12" dur="2.4s" repeatCount="indefinite" />
            <animate attributeName="opacity" values="0.22;0.05;0.22" dur="2.4s" repeatCount="indefinite" />
          </circle>
          <circle r="10" fill="#6b1e2d" stroke="#fff" strokeWidth="2.5" />
        </g>
      </svg>

      <div className="map-panel__bus-icon" style={{ left: `${busX}%`, top: `${(110 + Math.sin((busX / 100) * Math.PI) * -30) / 220 * 100}%` }}>
        <Bus size={13} color="#fff8f9" strokeWidth={2.4} />
      </div>

      <div className="map-panel__footer">
        <div className="map-panel__coords">
          <Navigation size={13} />
          <span>
            {currentLocation.latitude.toFixed(4)}, {currentLocation.longitude.toFixed(4)}
          </span>
        </div>
        <div className="map-panel__updated">Last updated: {lastUpdated}</div>
      </div>
    </div>
  );
}
