import { AlertTriangle, CheckCircle2, Info, ChevronRight } from "lucide-react";
import "./AlertCard.css";

const ICONS = {
  warning: AlertTriangle,
  success: CheckCircle2,
  info: Info,
};

export default function AlertCard({ alert, onAction }) {
  const Icon = ICONS[alert.severity] ?? Info;

  return (
    <div className={`alert-card alert-card--${alert.severity} ${alert.status === "unread" ? "alert-card--unread" : ""}`}>
      <span className="alert-card__icon">
        <Icon size={17} />
      </span>
      <div className="alert-card__body">
        <div className="alert-card__row">
          <p className="alert-card__title">{alert.alert_type}</p>
          {alert.status === "unread" && <span className="alert-card__unread-dot" />}
        </div>
        <p className="alert-card__message">{alert.message}</p>
        <div className="alert-card__meta">
          <span>{alert.created_at}</span>
          {alert.action_label && (
            <button className="alert-card__action" onClick={onAction}>
              {alert.action_label}
              <ChevronRight size={13} />
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
