import { useState, useRef, useEffect } from "react";
import { Menu, Search, Bell } from "lucide-react";
import { alerts } from "../data/mockData.js";
import "./Navbar.css";

export default function Navbar({ title, onMenuClick }) {
  const [notifOpen, setNotifOpen] = useState(false);
  const panelRef = useRef(null);

  const unread = alerts.filter((a) => a.status === "unread");

  useEffect(() => {
    function handleClick(e) {
      if (panelRef.current && !panelRef.current.contains(e.target)) {
        setNotifOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClick);
    return () => document.removeEventListener("mousedown", handleClick);
  }, []);

  return (
    <header className="navbar">
      <div className="navbar__left">
        <button className="navbar__menu" onClick={onMenuClick} aria-label="Open menu">
          <Menu size={22} />
        </button>
        <h1 className="navbar__title">{title}</h1>
      </div>

      <div className="navbar__right">
        <div className="navbar__search">
          <Search size={16} />
          <input type="text" placeholder="Search students, buses, routes…" />
        </div>

        <div className="navbar__notif" ref={panelRef}>
          <button
            className="navbar__icon-btn"
            aria-label="Notifications"
            onClick={() => setNotifOpen((v) => !v)}
          >
            <Bell size={19} />
            {unread.length > 0 && <span className="navbar__badge">{unread.length}</span>}
          </button>

          {notifOpen && (
            <div className="navbar__panel">
              <div className="navbar__panel-header">
                <p>Notifications</p>
                <span>{unread.length} unread</span>
              </div>
              <ul className="navbar__panel-list">
                {alerts.slice(0, 4).map((a) => (
                  <li key={a.alert_id} className={a.status === "unread" ? "is-unread" : ""}>
                    <p className="navbar__panel-item-title">{a.alert_type}</p>
                    <p className="navbar__panel-item-msg">{a.message}</p>
                    <span className="navbar__panel-item-time">{a.created_at}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>

        <div className="navbar__profile">
          <div className="navbar__avatar">GR</div>
          <div className="navbar__profile-text">
            <p className="navbar__profile-name">Geya Reddy</p>
            <p className="navbar__profile-role">Parent</p>
          </div>
        </div>
      </div>
    </header>
  );
}
