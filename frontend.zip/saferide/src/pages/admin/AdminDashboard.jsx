import { useState } from "react";
import { Link } from "react-router-dom";
import {
  Users,
  Bus as BusIcon,
  Navigation2,
  UserRound,
  ShieldAlert,
  Calendar,
  UserPlus,
  ListChecks,
  BellRing,
  Route as RouteIcon,
  ArrowRight,
} from "lucide-react";
import StatCard from "../../components/StatCard.jsx";
import StatusBadge from "../../components/StatusBadge.jsx";
import AlertCard from "../../components/AlertCard.jsx";
import FleetMapPanel from "../../components/admin/FleetMapPanel.jsx";
import AdminTable from "../../components/admin/AdminTable.jsx";
import QuickActionModal from "../../components/admin/QuickActionModal.jsx";
import {
  adminSummary,
  adminBuses,
  fleetMapBuses,
  adminAlerts,
  adminRecentActivity,
} from "../../data/adminMockData.js";
import "../common.css";
import "./admin.css";

const BUS_STATUS_TONE = {
  "On Route": "success",
  Delayed: "warning",
  Stopped: "danger",
  Idle: "neutral",
};

const GPS_STATUS_TONE = {
  Active: "success",
  Offline: "danger",
};

const ACTIVITY_ICON = {
  boarding: Users,
  alighting: Navigation2,
  info: ListChecks,
};

const today = new Date().toLocaleDateString(undefined, {
  weekday: "long",
  year: "numeric",
  month: "long",
  day: "numeric",
});

const QUICK_ACTIONS = [
  { key: "student", label: "Add Student", icon: UserPlus },
  { key: "bus", label: "Add Bus", icon: BusIcon },
  { key: "driver", label: "Add Driver", icon: UserRound },
  { key: "trip", label: "Create Trip", icon: RouteIcon },
];

const MODAL_CONFIG = {
  student: {
    title: "Add Student",
    description: "Adds a row to the Students table below for this demo.",
    fields: [
      { name: "name", label: "Student Name", required: true },
      { name: "roll_number", label: "Roll Number", required: true },
      { name: "parent_name", label: "Parent Name", required: true },
      { name: "bus", label: "Assigned Bus", type: "select", options: ["BUS-01", "BUS-02", "BUS-03", "BUS-04"] },
    ],
  },
  bus: {
    title: "Add Bus",
    description: "Adds a row to the Bus Status table below for this demo.",
    fields: [
      { name: "bus_number", label: "Bus Number", required: true },
      { name: "registration_number", label: "Registration Number", required: true },
      { name: "driver", label: "Driver Name", required: true },
      { name: "route", label: "Route", type: "select", options: ["Route 1", "Route 2", "Route 3", "Route 4"] },
    ],
  },
  driver: {
    title: "Add Driver",
    description: "Adds a driver to the fleet roster for this demo.",
    fields: [
      { name: "name", label: "Driver Name", required: true },
      { name: "phone", label: "Phone Number", required: true },
      { name: "license_number", label: "License Number", required: true },
    ],
  },
  trip: {
    title: "Create Trip",
    description: "Schedules a new trip for this demo.",
    fields: [
      { name: "bus", label: "Bus", type: "select", options: ["BUS-01", "BUS-02", "BUS-03", "BUS-04"] },
      { name: "route", label: "Route", type: "select", options: ["Route 1", "Route 2", "Route 3", "Route 4"] },
      { name: "start_time", label: "Start Time", type: "time", required: true },
    ],
  },
};

export default function AdminDashboard() {
  const [activeModal, setActiveModal] = useState(null);
  const [extraBuses, setExtraBuses] = useState([]);

  const busRows = [...adminBuses, ...extraBuses];

  function handleQuickAction(data) {
    if (activeModal === "bus") {
      setExtraBuses((prev) => [
        ...prev,
        {
          bus_id: `new-${prev.length}`,
          bus_number: data.bus_number,
          registration_number: data.registration_number,
          capacity: "—",
          gps_device_id: "—",
          driver: data.driver,
          route: data.route,
          status: "Idle",
          gps_status: "Active",
          last_updated: "just now",
        },
      ]);
    }
    // Other quick actions (student / driver / trip) are demo-only
    // confirmations for this prototype — see the modal's note.
  }

  return (
    <div className="page">
      <div className="page-header">
        <div>
          <h2>Admin Dashboard</h2>
          <p className="page-header__eyebrow">
            Monitor school transportation, student journeys and safety in real time.
          </p>
        </div>
        <div className="admin-header-meta">
          <span className="admin-header-date">
            <Calendar size={14} />
            {today}
          </span>
        </div>
      </div>

      <div className="admin-stat-grid">
        <StatCard icon={Users} label="Total Students" value={adminSummary.totalStudents.value} meta={adminSummary.totalStudents.meta} />
        <StatCard icon={BusIcon} label="Active Buses" value={adminSummary.activeBuses.value} meta={adminSummary.activeBuses.meta} accent />
        <StatCard icon={Navigation2} label="Active Trips" value={adminSummary.activeTrips.value} meta={adminSummary.activeTrips.meta} />
        <StatCard icon={UserRound} label="Active Drivers" value={adminSummary.activeDrivers.value} meta={adminSummary.activeDrivers.meta} />
        <StatCard icon={ShieldAlert} label="Safety Alerts" value={adminSummary.safetyAlerts.value} meta={adminSummary.safetyAlerts.meta} />
      </div>

      <div className="card">
        <div className="card__header">
          <div>
            <h3>Live Bus Monitoring</h3>
            <p>GPS tracks each bus; student verification associates a child with that bus's trip.</p>
          </div>
        </div>
        <FleetMapPanel buses={fleetMapBuses} />
      </div>

      <div className="card">
        <div className="card__header">
          <div>
            <h3>Bus Status</h3>
            <p>Live operating status across the fleet.</p>
          </div>
          <Link to="/admin/buses" className="admin-table__action-btn">
            View All Buses
          </Link>
        </div>
        <AdminTable
          columns={[
            { header: "Bus", accessor: "bus_number" },
            { header: "Driver", accessor: "driver" },
            { header: "Route", accessor: "route" },
            {
              header: "Status",
              accessor: (row) => (
                <StatusBadge tone={BUS_STATUS_TONE[row.status] ?? "neutral"} dot={false}>
                  {row.status}
                </StatusBadge>
              ),
            },
            {
              header: "GPS",
              accessor: (row) => (
                <StatusBadge tone={GPS_STATUS_TONE[row.gps_status] ?? "neutral"}>
                  {row.gps_status}
                </StatusBadge>
              ),
            },
            { header: "Last Updated", accessor: "last_updated" },
            {
              header: "Actions",
              accessor: () => <button className="admin-table__action-btn">View</button>,
            },
          ]}
          rows={busRows}
        />
      </div>

      <div className="two-col-grid">
        <div className="card">
          <div className="card__header">
            <div>
              <h3>Recent Student Activity</h3>
              <p>Boarding and alighting events across the fleet.</p>
            </div>
          </div>
          <ul className="activity-list">
            {adminRecentActivity.map((item, i) => {
              const Icon = ACTIVITY_ICON[item.type] ?? ListChecks;
              return (
                <li className="activity-list__item" key={i}>
                  <span className={`activity-list__icon activity-list__icon--${item.type}`}>
                    <Icon size={15} />
                  </span>
                  <div>
                    <p className="activity-list__title">{item.title}</p>
                    <p className="activity-list__detail">{item.detail}</p>
                  </div>
                  <span className="activity-list__time">{item.time}</span>
                </li>
              );
            })}
          </ul>
        </div>

        <div className="card">
          <div className="card__header">
            <div>
              <h3>Safety Alerts</h3>
              <p>Requires administrator attention.</p>
            </div>
            <Link to="/admin/alerts" className="admin-table__action-btn">
              View All <ArrowRight size={12} style={{ verticalAlign: -1, marginLeft: 3 }} />
            </Link>
          </div>
          <div className="alert-list">
            {adminAlerts.slice(0, 4).map((a) => (
              <AlertCard key={a.alert_id} alert={a} />
            ))}
          </div>
        </div>
      </div>

      <div className="card">
        <div className="card__header">
          <div>
            <h3>Quick Admin Actions</h3>
            <p>Common tasks for managing today's fleet.</p>
          </div>
        </div>
        <div className="admin-quick-actions">
          {QUICK_ACTIONS.map(({ key, label, icon: Icon }) => (
            <button key={key} className="admin-quick-actions__btn" onClick={() => setActiveModal(key)}>
              <span><Icon size={16} /></span>
              {label}
            </button>
          ))}
          <Link to="/admin/alerts" className="admin-quick-actions__btn admin-quick-actions__btn--link">
            <span><BellRing size={16} /></span>
            View All Alerts
          </Link>
          <Link to="/route" className="admin-quick-actions__btn admin-quick-actions__btn--link">
            <span><RouteIcon size={16} /></span>
            View All Routes
          </Link>
        </div>
      </div>

      {activeModal && (
        <QuickActionModal
          title={MODAL_CONFIG[activeModal].title}
          description={MODAL_CONFIG[activeModal].description}
          fields={MODAL_CONFIG[activeModal].fields}
          onClose={() => setActiveModal(null)}
          onSubmit={handleQuickAction}
        />
      )}
    </div>
  );
}
