import { useState } from "react";
import StatusBadge from "../../components/StatusBadge.jsx";
import AdminTable from "../../components/admin/AdminTable.jsx";
import AdminToolbar from "../../components/admin/AdminToolbar.jsx";
import DetailModal from "../../components/admin/DetailModal.jsx";
import { adminBuses } from "../../data/adminMockData.js";
import "../common.css";
import "./admin.css";

const STATUS_TONE = {
  "On Route": "success",
  Delayed: "warning",
  Stopped: "danger",
  Idle: "neutral",
};

const GPS_TONE = {
  Active: "success",
  Offline: "danger",
};

export default function AdminBuses() {
  const [search, setSearch] = useState("");
  const [selected, setSelected] = useState(null);

  const rows = adminBuses.filter((b) => {
    if (!search.trim()) return true;
    const q = search.toLowerCase();
    return b.bus_number.toLowerCase().includes(q) || b.driver.toLowerCase().includes(q) || b.route.toLowerCase().includes(q);
  });

  return (
    <div className="page">
      <div className="page-header">
        <div>
          <h2>Buses</h2>
          <p className="page-header__eyebrow">Fleet roster, assigned drivers, and live GPS status.</p>
        </div>
      </div>

      <div className="card">
        <AdminToolbar
          searchValue={search}
          onSearchChange={setSearch}
          searchPlaceholder="Search by bus, driver, or route…"
        />

        <AdminTable
          columns={[
            { header: "Bus Number", accessor: "bus_number" },
            { header: "Registration", accessor: "registration_number" },
            { header: "Driver", accessor: "driver" },
            { header: "Capacity", accessor: "capacity" },
            { header: "GPS Device", accessor: "gps_device_id" },
            {
              header: "Status",
              accessor: (row) => (
                <StatusBadge tone={STATUS_TONE[row.status] ?? "neutral"} dot={false}>
                  {row.status}
                </StatusBadge>
              ),
            },
            { header: "Route", accessor: "route" },
            {
              header: "",
              accessor: (row) => (
                <button className="admin-table__action-btn" onClick={() => setSelected(row)}>
                  View
                </button>
              ),
            },
          ]}
          rows={rows}
          emptyMessage="No buses match your search."
        />
      </div>

      {selected && (
        <DetailModal
          title={selected.bus_number}
          onClose={() => setSelected(null)}
          rows={[
            ["Registration", selected.registration_number],
            ["Driver", selected.driver],
            ["Capacity", selected.capacity],
            ["GPS Device", selected.gps_device_id],
            ["Route", selected.route],
            ["Status", selected.status],
            ["GPS Status", <StatusBadge key="gps" tone={GPS_TONE[selected.gps_status] ?? "neutral"}>{selected.gps_status}</StatusBadge>],
            ["Last Updated", selected.last_updated],
          ]}
        />
      )}
    </div>
  );
}
