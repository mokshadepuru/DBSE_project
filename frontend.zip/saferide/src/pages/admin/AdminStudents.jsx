import { useMemo, useState } from "react";
import StatusBadge from "../../components/StatusBadge.jsx";
import AdminTable from "../../components/admin/AdminTable.jsx";
import AdminToolbar from "../../components/admin/AdminToolbar.jsx";
import DetailModal from "../../components/admin/DetailModal.jsx";
import { adminStudents } from "../../data/adminMockData.js";
import "../common.css";
import "./admin.css";

const STATUS_TONE = {
  "On Bus": "success",
  "Not Boarded": "neutral",
  Alighted: "info",
};

export default function AdminStudents() {
  const [search, setSearch] = useState("");
  const [busFilter, setBusFilter] = useState("All Buses");
  const [selected, setSelected] = useState(null);

  const buses = useMemo(() => ["All Buses", ...new Set(adminStudents.map((s) => s.bus))], []);

  const rows = adminStudents.filter((s) => {
    if (busFilter !== "All Buses" && s.bus !== busFilter) return false;
    if (!search.trim()) return true;
    const q = search.toLowerCase();
    return s.name.toLowerCase().includes(q) || s.roll_number.toLowerCase().includes(q) || s.parent_name.toLowerCase().includes(q);
  });

  return (
    <div className="page">
      <div className="page-header">
        <div>
          <h2>Students</h2>
          <p className="page-header__eyebrow">Every registered student across the fleet.</p>
        </div>
      </div>

      <div className="card">
        <AdminToolbar
          searchValue={search}
          onSearchChange={setSearch}
          searchPlaceholder="Search by name, roll number, or parent…"
          filters={[{ label: "Bus", value: busFilter, onChange: setBusFilter, options: buses }]}
        />

        <AdminTable
          columns={[
            { header: "Student ID", accessor: "student_id" },
            { header: "Name", accessor: "name" },
            { header: "Roll Number", accessor: "roll_number" },
            { header: "Parent", accessor: "parent_name" },
            { header: "Bus", accessor: "bus" },
            { header: "Pickup", accessor: "pickup_stop" },
            { header: "Drop", accessor: "drop_stop" },
            {
              header: "Status",
              accessor: (row) => (
                <StatusBadge tone={STATUS_TONE[row.status] ?? "neutral"} dot={false}>
                  {row.status}
                </StatusBadge>
              ),
            },
            {
              header: "",
              accessor: (row) => (
                <button className="admin-table__action-btn" onClick={() => setSelected(row)}>
                  View Details
                </button>
              ),
            },
          ]}
          rows={rows}
          emptyMessage="No students match your search."
        />
      </div>

      {selected && (
        <DetailModal
          title={selected.name}
          onClose={() => setSelected(null)}
          rows={[
            ["Roll Number", selected.roll_number],
            ["Parent Name", selected.parent_name],
            ["Bus", selected.bus],
            ["Pickup Stop", selected.pickup_stop],
            ["Drop Stop", selected.drop_stop],
            ["Status", selected.status],
          ]}
        />
      )}
    </div>
  );
}
