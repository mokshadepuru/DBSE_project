import { useMemo, useState } from "react";
import StatusBadge from "../../components/StatusBadge.jsx";
import AdminTable from "../../components/admin/AdminTable.jsx";
import AdminToolbar from "../../components/admin/AdminToolbar.jsx";
import { adminTrips } from "../../data/adminMockData.js";
import "../common.css";
import "./admin.css";

const STATUS_TONE = {
  "In Progress": "info",
  Completed: "success",
  Delayed: "warning",
  Stopped: "danger",
};

export default function AdminTrips() {
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("All Status");

  const statuses = useMemo(() => ["All Status", ...new Set(adminTrips.map((t) => t.status))], []);

  const rows = adminTrips.filter((t) => {
    if (statusFilter !== "All Status" && t.status !== statusFilter) return false;
    if (!search.trim()) return true;
    const q = search.toLowerCase();
    return t.bus.toLowerCase().includes(q) || t.driver.toLowerCase().includes(q) || t.route.toLowerCase().includes(q);
  });

  return (
    <div className="page">
      <div className="page-header">
        <div>
          <h2>Trips</h2>
          <p className="page-header__eyebrow">Scheduled and completed trips across the fleet.</p>
        </div>
      </div>

      <div className="card">
        <AdminToolbar
          searchValue={search}
          onSearchChange={setSearch}
          searchPlaceholder="Search by bus, driver, or route…"
          filters={[{ label: "Status", value: statusFilter, onChange: setStatusFilter, options: statuses }]}
        />

        <AdminTable
          columns={[
            { header: "Trip ID", accessor: "trip_id" },
            { header: "Bus", accessor: "bus" },
            { header: "Driver", accessor: "driver" },
            { header: "Route", accessor: "route" },
            { header: "Date", accessor: "date" },
            { header: "Start Time", accessor: "start_time" },
            { header: "End Time", accessor: "end_time" },
            {
              header: "Status",
              accessor: (row) => (
                <StatusBadge tone={STATUS_TONE[row.status] ?? "neutral"} dot={false}>
                  {row.status}
                </StatusBadge>
              ),
            },
          ]}
          rows={rows}
          emptyMessage="No trips match these filters."
        />
      </div>
    </div>
  );
}
