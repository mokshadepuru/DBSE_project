import { useState } from "react";
import { Satellite } from "lucide-react";
import AdminTable from "../../components/admin/AdminTable.jsx";
import AdminToolbar from "../../components/admin/AdminToolbar.jsx";
import StatusBadge from "../../components/StatusBadge.jsx";
import { adminGpsMonitoring } from "../../data/adminMockData.js";
import "../common.css";
import "./admin.css";

const STATUS_TONE = {
  Active: "success",
  Offline: "danger",
};

export default function AdminGps() {
  const [search, setSearch] = useState("");

  const rows = adminGpsMonitoring.filter((g) => {
    if (!search.trim()) return true;
    const q = search.toLowerCase();
    return g.bus.toLowerCase().includes(q) || g.gps_device_id.toLowerCase().includes(q);
  });

  return (
    <div className="page">
      <div className="page-header">
        <div>
          <h2>GPS Monitoring</h2>
          <p className="page-header__eyebrow">
            The latest reported position for each bus's GPS device. GPS tracks the bus — never the child.
          </p>
        </div>
      </div>

      <div className="card">
        <AdminToolbar
          searchValue={search}
          onSearchChange={setSearch}
          searchPlaceholder="Search by bus or device ID…"
        />

        <AdminTable
          columns={[
            { header: "Bus", accessor: "bus" },
            {
              header: "GPS Device",
              accessor: (row) => (
                <span style={{ display: "inline-flex", alignItems: "center", gap: 6 }}>
                  <Satellite size={13} />
                  {row.gps_device_id}
                </span>
              ),
            },
            { header: "Latitude", accessor: "latitude" },
            { header: "Longitude", accessor: "longitude" },
            { header: "Last Updated", accessor: "last_updated" },
            {
              header: "Status",
              accessor: (row) => (
                <StatusBadge tone={STATUS_TONE[row.status] ?? "neutral"}>{row.status}</StatusBadge>
              ),
            },
          ]}
          rows={rows}
          emptyMessage="No GPS devices match your search."
        />
      </div>
    </div>
  );
}
