import { useState } from "react";
import StatusBadge from "../../components/StatusBadge.jsx";
import AdminTable from "../../components/admin/AdminTable.jsx";
import AdminToolbar from "../../components/admin/AdminToolbar.jsx";
import DetailModal from "../../components/admin/DetailModal.jsx";
import { adminDrivers } from "../../data/adminMockData.js";
import "../common.css";
import "./admin.css";

const STATUS_TONE = {
  "On Duty": "success",
  "Off Duty": "neutral",
};

export default function AdminDrivers() {
  const [search, setSearch] = useState("");
  const [selected, setSelected] = useState(null);

  const rows = adminDrivers.filter((d) => {
    if (!search.trim()) return true;
    const q = search.toLowerCase();
    return d.name.toLowerCase().includes(q) || d.assigned_bus.toLowerCase().includes(q);
  });

  return (
    <div className="page">
      <div className="page-header">
        <div>
          <h2>Drivers</h2>
          <p className="page-header__eyebrow">Every driver currently on the roster.</p>
        </div>
      </div>

      <div className="card">
        <AdminToolbar
          searchValue={search}
          onSearchChange={setSearch}
          searchPlaceholder="Search by driver or bus…"
        />

        <AdminTable
          columns={[
            { header: "Driver", accessor: "name" },
            { header: "Phone", accessor: "phone" },
            { header: "License", accessor: "license_number" },
            { header: "Assigned Bus", accessor: "assigned_bus" },
            {
              header: "Status",
              accessor: (row) => (
                <StatusBadge tone={STATUS_TONE[row.status] ?? "neutral"} dot={false}>
                  {row.status}
                </StatusBadge>
              ),
            },
            {
              header: "",
              accessor: (row) => (
                <button className="admin-table__action-btn" onClick={() => setSelected(row)}>
                  View
                </button>
              ),
            },
          ]}
          rows={rows}
          emptyMessage="No drivers match your search."
        />
      </div>

      {selected && (
        <DetailModal
          title={selected.name}
          onClose={() => setSelected(null)}
          rows={[
            ["Phone", selected.phone],
            ["License Number", selected.license_number],
            ["Assigned Bus", selected.assigned_bus],
            ["Status", selected.status],
          ]}
        />
      )}
    </div>
  );
}
