import { MapPin, Flag, Clock3 } from "lucide-react";
import MapPanel from "../components/MapPanel.jsx";
import RouteProgress from "../components/RouteProgress.jsx";
import { route, activeTrip, bus, currentGpsLocation, lastUpdatedLabel } from "../data/mockData.js";
import "./common.css";

export default function RoutePage() {
  return (
    <div className="page">
      <div className="page-header">
        <div>
          <h2>Route</h2>
          <p className="page-header__eyebrow">{route.route_name} · {route.start_location} to {route.destination}</p>
        </div>
      </div>

      <div className="card" style={{ padding: 0, overflow: "hidden" }}>
        <MapPanel
          stops={route.stops}
          progress={activeTrip.progress}
          currentLocation={currentGpsLocation}
          busLabel={bus.bus_number}
          lastUpdated={lastUpdatedLabel}
        />
      </div>

      <div className="two-col-grid">
        <div className="card">
          <div className="card__header">
            <h3>Route Progress</h3>
          </div>
          <RouteProgress
            stops={route.stops}
            currentStop={activeTrip.currentStop}
            progress={activeTrip.progress}
          />
        </div>

        <div className="card">
          <div className="card__header">
            <h3>Stops</h3>
          </div>
          <ul className="stop-list">
            {route.stops.map((s, i) => (
              <li key={s.name}>
                <span className="stop-list__icon">
                  {i === 0 || i === route.stops.length - 1 ? <Flag size={14} /> : <MapPin size={14} />}
                </span>
                <div>
                  <p className="stop-list__name">{s.name}</p>
                  <p className="stop-list__type">
                    {s.type === "pickup" ? "Pickup point" : s.type === "destination" ? "Destination" : "Waypoint"}
                  </p>
                </div>
              </li>
            ))}
          </ul>
        </div>
      </div>

      <div className="card">
        <div className="card__header">
          <div>
            <h3>Estimated Arrival</h3>
            <p>Based on current bus progress along {route.route_name}.</p>
          </div>
          <div className="eta-pill">
            <Clock3 size={15} />
            {activeTrip.eta}
          </div>
        </div>
      </div>
    </div>
  );
}
