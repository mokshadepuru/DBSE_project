import { Bus, Navigation2, ShieldCheck, Clock3 } from "lucide-react";
import StatCard from "../components/StatCard.jsx";
import MapPanel from "../components/MapPanel.jsx";
import BusCard from "../components/BusCard.jsx";
import StudentCard from "../components/StudentCard.jsx";
import Timeline from "../components/Timeline.jsx";
import AlertCard from "../components/AlertCard.jsx";
import {
  student,
  bus,
  driver,
  route,
  activeTrip,
  boardingRecord,
  dashboardStats,
  currentGpsLocation,
  lastUpdatedLabel,
  journeyTimeline,
  alerts,
} from "../data/mockData.js";
import "./common.css";

export default function Dashboard() {
  const recentAlerts = alerts.slice(0, 3);

  return (
    <div className="page">
      <div className="page-header">
        <div>
          <h2>Good Morning, Parent 👋</h2>
          <p className="page-header__eyebrow">
            Here's your child's journey status for today.
          </p>
        </div>
      </div>

      <div className="stat-grid">
        <StatCard
          icon={Bus}
          label="Bus Status"
          value={dashboardStats.busStatus.bus_number}
          meta={`${dashboardStats.busStatus.status} · ${dashboardStats.busStatus.note}`}
          accent
        />
        <StatCard
          icon={Navigation2}
          label="Journey Status"
          value={dashboardStats.journeyStatus.status}
          meta={dashboardStats.journeyStatus.route}
        />
        <StatCard
          icon={ShieldCheck}
          label="Boarding Status"
          value={dashboardStats.boardingStatus.status}
          meta={dashboardStats.boardingStatus.time}
        />
        <StatCard
          icon={Clock3}
          label="ETA"
          value={dashboardStats.eta.time}
          meta={dashboardStats.eta.note}
        />
      </div>

      <div className="card">
        <div className="card__header">
          <div>
            <h3>Live Bus Tracking</h3>
            <p>GPS tracks the bus, while student verification associates the child with that bus trip.</p>
          </div>
        </div>
        <div className="tracking-grid">
          <MapPanel
            stops={route.stops}
            progress={activeTrip.progress}
            currentLocation={currentGpsLocation}
            busLabel={bus.bus_number}
            lastUpdated={lastUpdatedLabel}
          />
          <BusCard
            bus={bus}
            driver={driver}
            routeName={route.route_name}
            status={activeTrip.status}
            lastUpdated={lastUpdatedLabel}
          />
        </div>
      </div>

      <div className="two-col-grid">
        <StudentCard
          student={student}
          bus={bus}
          status="Currently on bus"
          boardingTime={boardingRecord.boarding_time}
          verification={boardingRecord.verification_method}
        />

        <div className="card">
          <div className="card__header">
            <div>
              <h3>Journey Timeline</h3>
              <p>Every verified event for today's trip, in order.</p>
            </div>
          </div>
          <Timeline items={journeyTimeline} />
        </div>
      </div>

      <div className="card">
        <div className="card__header">
          <div>
            <h3>Safety Alerts</h3>
            <p>Recent events for {student.name} and {bus.bus_number}.</p>
          </div>
        </div>
        <div className="alert-list">
          {recentAlerts.map((a) => (
            <AlertCard key={a.alert_id} alert={a} />
          ))}
        </div>
      </div>
    </div>
  );
}
