import { Satellite, Clock3, Gauge } from "lucide-react";
import MapPanel from "../components/MapPanel.jsx";
import BusCard from "../components/BusCard.jsx";
import RouteProgress from "../components/RouteProgress.jsx";
import StatusBadge from "../components/StatusBadge.jsx";
import {
  bus,
  driver,
  route,
  activeTrip,
  currentGpsLocation,
  lastUpdatedLabel,
} from "../data/mockData.js";
import "./common.css";

export default function LiveTracking() {
  return (
    <div className="page">
      <div className="page-header">
        <div>
          <h2>Live Tracking</h2>
          <p className="page-header__eyebrow">
            {bus.bus_number} is currently {activeTrip.status.toLowerCase()} on {route.route_name}.
          </p>
        </div>
        <StatusBadge tone="success">Live · GPS Active</StatusBadge>
      </div>

      <div className="tracking-grid">
        <div className="card" style={{ padding: 0, overflow: "hidden" }}>
          <MapPanel
            stops={route.stops}
            progress={activeTrip.progress}
            currentLocation={currentGpsLocation}
            busLabel={bus.bus_number}
            lastUpdated={lastUpdatedLabel}
          />
        </div>

        <div style={{ display: "flex", flexDirection: "column", gap: "20px" }}>
          <BusCard
            bus={bus}
            driver={driver}
            routeName={route.route_name}
            status={activeTrip.status}
            lastUpdated={lastUpdatedLabel}
          />

          <div className="card">
            <div className="card__header">
              <h3>Trip Snapshot</h3>
            </div>
            <ul className="snapshot-list">
              <li>
                <span><Gauge size={14} /> Speed (est.)</span>
                <span className="snapshot-list__value">34 km/h</span>
              </li>
              <li>
                <span><Satellite size={14} /> Coordinates</span>
                <span className="snapshot-list__value">
                  {currentGpsLocation.latitude.toFixed(4)}, {currentGpsLocation.longitude.toFixed(4)}
                </span>
              </li>
              <li>
                <span><Clock3 size={14} /> ETA</span>
                <span className="snapshot-list__value">{activeTrip.eta}</span>
              </li>
            </ul>
          </div>
        </div>
      </div>

      <div className="card">
        <div className="card__header">
          <div>
            <h3>Route Progress</h3>
            <p>
              {route.start_location} → Kukatpally → JNTU → {route.destination}
            </p>
          </div>
        </div>
        <RouteProgress
          stops={route.stops}
          currentStop={activeTrip.currentStop}
          progress={activeTrip.progress}
        />
      </div>
    </div>
  );
}
