/**
 * Mock data layer for the SafeRide portal.
 *
 * Every export here is shaped to mirror a table (or a join of tables) in the
 * `school_bus_safety` MySQL database described in the project spec. When the
 * Node.js + Express API is ready, each of these exports can be replaced with
 * a fetch call to the matching endpoint without touching component code —
 * e.g. `students` -> `GET /api/students/:id`, `gpsLocations` -> a live
 * websocket/poll from `GET /api/buses/:id/location`, and so on.
 *
 * IMPORTANT: this file never claims to read a live GPS device or a live
 * database. It is illustrative data only.
 */

// ---- students ---------------------------------------------------------
export const student = {
  student_id: 1,
  name: "Moksha",
  roll_number: "2520030515",
  parent_name: "Geya Reddy",
  parent_phone: "+91 98765 43210",
  pickup_stop: "KPHB",
  drop_stop: "KLH University",
};

// ---- buses --------------------------------------------------------------
export const bus = {
  bus_id: 1,
  bus_number: "BUS-01",
  registration_number: "TS 09 EA 4471",
  capacity: 42,
  gps_device_id: "GPS001",
};

// ---- drivers --------------------------------------------------------------
export const driver = {
  driver_id: 1,
  name: "Ramesh Kumar",
  phone: "+91 90142 55631",
  license_number: "TS10 2016 0042311",
};

// ---- routes --------------------------------------------------------------
export const route = {
  route_id: 1,
  route_name: "Route 1",
  start_location: "KPHB",
  destination: "KLH University",
  stops: [
    { name: "KPHB", type: "pickup", lat: 17.4938, lng: 78.3915 },
    { name: "Kukatpally", type: "waypoint", lat: 17.4849, lng: 78.4108 },
    { name: "JNTU", type: "waypoint", lat: 17.4933, lng: 78.3915 },
    { name: "KLH University", type: "destination", lat: 17.5453, lng: 78.5731 },
  ],
};

// ---- trips --------------------------------------------------------------
export const activeTrip = {
  trip_id: 501,
  bus_id: bus.bus_id,
  driver_id: driver.driver_id,
  route_id: route.route_id,
  trip_date: "2026-09-09",
  start_time: "07:00 AM",
  end_time: null,
  status: "On Route",
  eta: "08:05 AM",
  progress: 62, // percent of route completed, used to place the bus marker
  currentStop: "JNTU",
  nextStop: "KLH University",
};

// ---- boarding_records -----------------------------------------------------
export const boardingRecord = {
  boarding_id: 9001,
  student_id: student.student_id,
  trip_id: activeTrip.trip_id,
  boarding_time: "07:32 AM",
  boarding_latitude: 17.4938,
  boarding_longitude: 78.3915,
  verification_method: "QR",
};

// ---- alighting_records ------------------------------------------------
export const alightingRecord = {
  alighting_id: null,
  student_id: student.student_id,
  trip_id: activeTrip.trip_id,
  alighting_time: null,
  alighting_latitude: null,
  alighting_longitude: null,
  verification_method: null,
  status: "Not yet alighted",
};

// ---- gps_locations (bus, not the child) --------------------------------
export const gpsLocations = [
  { location_id: 1, bus_id: bus.bus_id, latitude: 17.4938, longitude: 78.3915, recorded_at: "07:00 AM" },
  { location_id: 2, bus_id: bus.bus_id, latitude: 17.4890, longitude: 78.4010, recorded_at: "07:20 AM" },
  { location_id: 3, bus_id: bus.bus_id, latitude: 17.4849, longitude: 78.4108, recorded_at: "07:38 AM" },
  { location_id: 4, bus_id: bus.bus_id, latitude: 17.4933, longitude: 78.3915, recorded_at: "07:50 AM" },
];

export const currentGpsLocation = gpsLocations[gpsLocations.length - 1];
export const lastUpdatedLabel = "2 min ago";

// ---- alerts --------------------------------------------------------------
export const alerts = [
  {
    alert_id: 1,
    student_id: student.student_id,
    bus_id: bus.bus_id,
    alert_type: "Route Deviation",
    category: "safety",
    severity: "warning",
    message: "BUS-01 has moved away from the planned route.",
    created_at: "10 minutes ago",
    status: "unread",
    action_label: "View Route",
  },
  {
    alert_id: 2,
    student_id: student.student_id,
    bus_id: bus.bus_id,
    alert_type: "Boarding Verified",
    category: "journey",
    severity: "success",
    message: "Moksha successfully boarded BUS-01 via QR verification.",
    created_at: "07:32 AM",
    status: "read",
  },
  {
    alert_id: 3,
    student_id: null,
    bus_id: bus.bus_id,
    alert_type: "Bus On Route",
    category: "journey",
    severity: "info",
    message: "Bus is currently following the planned route.",
    created_at: "07:45 AM",
    status: "read",
  },
  {
    alert_id: 4,
    student_id: student.student_id,
    bus_id: bus.bus_id,
    alert_type: "Trip Started",
    category: "journey",
    severity: "info",
    message: "BUS-01 departed from the depot for the morning trip.",
    created_at: "07:00 AM",
    status: "read",
  },
  {
    alert_id: 5,
    student_id: null,
    bus_id: bus.bus_id,
    alert_type: "GPS Unavailable",
    category: "safety",
    severity: "warning",
    message: "GPS signal from BUS-01 was briefly unavailable near Kukatpally.",
    created_at: "Yesterday, 08:12 AM",
    status: "read",
  },
  {
    alert_id: 6,
    student_id: student.student_id,
    bus_id: bus.bus_id,
    alert_type: "Alighting Verified",
    category: "journey",
    severity: "success",
    message: "Moksha alighted safely at KLH University.",
    created_at: "Yesterday, 08:06 AM",
    status: "read",
  },
];

// ---- dashboard timeline (derived view over trips/boarding/gps) ------------
export const journeyTimeline = [
  { time: "07:00 AM", title: "Trip Started", description: "BUS-01 departed from the depot.", type: "start" },
  { time: "07:32 AM", title: "Student Boarded", description: "Moksha boarded using QR verification.", type: "boarding" },
  { time: "07:45 AM", title: "KPHB", description: "Bus passed the pickup area.", type: "stop" },
  { time: "07:50 AM", title: "JNTU", description: "Bus is currently moving through this stop.", type: "current" },
  { time: "08:05 AM", title: "KLH University", description: "Expected arrival at destination.", type: "upcoming" },
];

// ---- trips / journey history (join of trips + boarding + alighting) ------
export const journeyHistory = [
  { trip_id: 501, date: "09 Sep 2026", bus: "BUS-01", route: "Route 1", boarded: "07:32 AM", alighted: "—", verification: "QR", status: "In Progress" },
  { trip_id: 498, date: "08 Sep 2026", bus: "BUS-01", route: "Route 1", boarded: "07:30 AM", alighted: "08:04 AM", verification: "QR", status: "Completed" },
  { trip_id: 495, date: "07 Sep 2026", bus: "BUS-01", route: "Route 1", boarded: "07:34 AM", alighted: "08:08 AM", verification: "RFID", status: "Completed" },
  { trip_id: 492, date: "06 Sep 2026", bus: "BUS-02", route: "Route 1", boarded: "07:36 AM", alighted: "08:10 AM", verification: "QR", status: "Completed" },
  { trip_id: 489, date: "05 Sep 2026", bus: "BUS-01", route: "Route 1", boarded: "07:31 AM", alighted: "08:03 AM", verification: "QR", status: "Completed" },
  { trip_id: 486, date: "04 Sep 2026", bus: "BUS-01", route: "Route 1", boarded: "—", alighted: "—", verification: "—", status: "Missed" },
  { trip_id: 483, date: "03 Sep 2026", bus: "BUS-01", route: "Route 1", boarded: "07:29 AM", alighted: "08:02 AM", verification: "NFC", status: "Completed" },
];

// ---- dashboard summary stat cards -----------------------------------------
export const dashboardStats = {
  busStatus: { bus_number: bus.bus_number, status: "Live", note: "Currently active" },
  journeyStatus: { status: "On Route", route: route.route_name },
  boardingStatus: { status: "Boarded", time: boardingRecord.boarding_time },
  eta: { time: activeTrip.eta, note: "Estimated arrival" },
};

// ---- parent profile ---------------------------------------------------
export const parentProfile = {
  name: "Geya Reddy",
  email: "anitha.reddy@example.com",
  phone: "+91 98765 43210",
  address: "Plot 14, Vivekananda Nagar, KPHB, Hyderabad",
  children: [student.name],
  joined: "June 2025",
};
