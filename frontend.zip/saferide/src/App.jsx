import { useState, useEffect } from "react";
import { Routes, Route, useLocation } from "react-router-dom";
import Sidebar from "./components/Sidebar.jsx";
import Navbar from "./components/Navbar.jsx";
import Dashboard from "./pages/Dashboard.jsx";
import LiveTracking from "./pages/LiveTracking.jsx";
import StudentDetails from "./pages/StudentDetails.jsx";
import JourneyHistory from "./pages/JourneyHistory.jsx";
import Alerts from "./pages/Alerts.jsx";
import RoutePage from "./pages/Route.jsx";
import Profile from "./pages/Profile.jsx";
import Settings from "./pages/Settings.jsx";
import AdminDashboard from "./pages/admin/AdminDashboard.jsx";
import AdminStudents from "./pages/admin/AdminStudents.jsx";
import AdminBuses from "./pages/admin/AdminBuses.jsx";
import AdminDrivers from "./pages/admin/AdminDrivers.jsx";
import AdminTrips from "./pages/admin/AdminTrips.jsx";
import AdminBoarding from "./pages/admin/AdminBoarding.jsx";
import AdminAlighting from "./pages/admin/AdminAlighting.jsx";
import AdminGps from "./pages/admin/AdminGps.jsx";
import AdminAlerts from "./pages/admin/AdminAlerts.jsx";
import "./App.css";

const PAGE_TITLES = {
  "/": "Dashboard",
  "/live-tracking": "Live Tracking",
  "/my-child": "My Child",
  "/journey-history": "Journey History",
  "/alerts": "Safety Alerts",
  "/route": "Route",
  "/profile": "Profile",
  "/settings": "Settings",
  "/admin": "Admin Dashboard",
  "/admin/students": "Students",
  "/admin/buses": "Buses",
  "/admin/drivers": "Drivers",
  "/admin/trips": "Trips",
  "/admin/boarding": "Boarding Records",
  "/admin/alighting": "Alighting Records",
  "/admin/gps": "GPS Monitoring",
  "/admin/alerts": "Admin Alerts",
};

export default function App() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const location = useLocation();
  const title = PAGE_TITLES[location.pathname] ?? "Dashboard";

  // Close the mobile sidebar whenever the route changes.
  useEffect(() => {
    setSidebarOpen(false);
  }, [location.pathname]);

  return (
    <div className="shell">
      <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />

      {sidebarOpen && (
        <button
          className="shell__scrim"
          aria-label="Close menu"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      <div className="shell__main">
        <Navbar title={title} onMenuClick={() => setSidebarOpen(true)} />

        <main className="shell__content">
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/live-tracking" element={<LiveTracking />} />
            <Route path="/my-child" element={<StudentDetails />} />
            <Route path="/journey-history" element={<JourneyHistory />} />
            <Route path="/alerts" element={<Alerts />} />
            <Route path="/route" element={<RoutePage />} />
            <Route path="/profile" element={<Profile />} />
            <Route path="/settings" element={<Settings />} />

            <Route path="/admin" element={<AdminDashboard />} />
            <Route path="/admin/students" element={<AdminStudents />} />
            <Route path="/admin/buses" element={<AdminBuses />} />
            <Route path="/admin/drivers" element={<AdminDrivers />} />
            <Route path="/admin/trips" element={<AdminTrips />} />
            <Route path="/admin/boarding" element={<AdminBoarding />} />
            <Route path="/admin/alighting" element={<AdminAlighting />} />
            <Route path="/admin/gps" element={<AdminGps />} />
            <Route path="/admin/alerts" element={<AdminAlerts />} />
          </Routes>
        </main>
      </div>
    </div>
  );
}
