# SafeRide — School Bus Tracking & Student Safety Portal

A premium, wine-red/burgundy themed parent dashboard for monitoring a school
bus journey, verifying student boarding/alighting, and receiving safety
alerts. Built as a frontend-only React project, structured so a
Node.js + Express + MySQL backend can be dropped in later without changing
component code.

## Core safety model

This app never claims to track a child's live GPS location. Instead:

- **WHO** — a QR / RFID / NFC scan identifies the student when they board or
  alight (`verification_method` on `boarding_records` / `alighting_records`).
- **WHERE** — a GPS device attached to the *bus* reports the bus's location
  (`gps_locations`, keyed by `bus_id`).
- **WHEN** — every event is timestamped.

In short: **GPS tracks the bus, while student verification associates the
child with that bus trip.** This phrasing is used throughout the UI.

## Getting started

```bash
npm install
npm run dev
```

Then open the printed local URL (typically `http://localhost:5173`).

Other scripts:

```bash
npm run build    # production build to dist/
npm run preview  # preview the production build locally
npm run lint     # oxlint
```

## Tech stack

- React 19 + React Router 6
- Plain CSS with a design-token system (`src/index.css`) — no CSS framework
- [lucide-react](https://lucide.dev) icons
- Vite as the build tool

## Project structure

```
src/
  components/     Reusable UI: Sidebar, Navbar, StatCard, BusCard,
                  StudentCard, AlertCard, Timeline, MapPanel,
                  RouteProgress, StatusBadge, DataTable
  pages/          Dashboard, LiveTracking, StudentDetails, JourneyHistory,
                  Alerts, Route, Profile, Settings
  data/
    mockData.js   Mock data shaped to match the school_bus_safety MySQL
                  schema — see below
  App.jsx         Route table + shell layout (sidebar/navbar/content)
  main.jsx        App entry point (BrowserRouter mount)
```

## Mock data → future API mapping

`src/data/mockData.js` is the single place mock data lives. Every export
name maps to a table (or a join of tables) in the planned `school_bus_safety`
MySQL database:

| Export              | Backed by table(s)                          | Future endpoint (example)           |
|----------------------|----------------------------------------------|--------------------------------------|
| `student`            | `students`                                    | `GET /api/students/:id`             |
| `bus`                 | `buses`                                       | `GET /api/buses/:id`                |
| `driver`              | `drivers`                                     | `GET /api/drivers/:id`              |
| `route`               | `routes`                                      | `GET /api/routes/:id`               |
| `activeTrip`          | `trips`                                       | `GET /api/trips/active`             |
| `boardingRecord`      | `boarding_records`                            | `GET /api/trips/:id/boarding`       |
| `alightingRecord`     | `alighting_records`                           | `GET /api/trips/:id/alighting`      |
| `gpsLocations`        | `gps_locations`                               | `GET /api/buses/:id/locations` (or a websocket stream) |
| `alerts`              | `alerts`                                      | `GET /api/alerts?student_id=`       |
| `journeyHistory`      | join of `trips` + `boarding_records` + `alighting_records` | `GET /api/students/:id/history` |

When the backend is ready, replace the corresponding import in a page with a
data-fetching hook (e.g. `useEffect` + `fetch`, or React Query) that returns
the same shape — no component prop signatures need to change.

Planned architecture:

```
React Frontend → Node.js + Express Backend → MySQL Database → GPS Device API
Backend → Firebase Cloud Messaging → Parent (push notifications)
```

## Design system

Wine red / burgundy on light, spacious surfaces — tokens live in
`src/index.css` (`:root` custom properties) and are reused everywhere
instead of hard-coded colors, so the palette stays consistent across every
page and component.

## Responsive behavior

- **Desktop (≥1024px):** fixed sidebar, full stat grid, side-by-side map +
  bus card.
- **Tablet (640–1024px):** sidebar collapses behind a hamburger menu with a
  scrim; grids reflow to fewer columns.
- **Mobile (≤560px):** single-column stacking throughout, condensed navbar,
  touch-sized controls.

## Notes for the college submission

- All data in this build is illustrative mock data — no live GPS device or
  database connection is implemented, as intended for the frontend-only
  milestone.
- Component props are intentionally plain (no backend-specific assumptions)
  so the same UI can be reused once the Express API exists.
