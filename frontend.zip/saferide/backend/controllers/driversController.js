const { pool } = require("../db");
const { asyncHandler, isValidId } = require("./helpers");

// GET /api/drivers
const getAllDrivers = asyncHandler(async (req, res) => {
  const [rows] = await pool.query("SELECT * FROM drivers ORDER BY name");
  res.json(rows);
});

// GET /api/drivers/:id
const getDriverById = asyncHandler(async (req, res) => {
  const { id } = req.params;
  if (!isValidId(id)) {
    return res.status(400).json({ error: "Driver id must be a number." });
  }

  const [rows] = await pool.query("SELECT * FROM drivers WHERE driver_id = ?", [id]);
  if (rows.length === 0) {
    return res.status(404).json({ error: `No driver found with id ${id}.` });
  }
  res.json(rows[0]);
});

module.exports = { getAllDrivers, getDriverById };
