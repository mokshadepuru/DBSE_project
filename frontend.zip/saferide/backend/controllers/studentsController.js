const { pool } = require("../db");
const { asyncHandler, isValidId } = require("./helpers");

// GET /api/students
const getAllStudents = asyncHandler(async (req, res) => {
  const [rows] = await pool.query("SELECT * FROM students ORDER BY name");
  res.json(rows);
});

// GET /api/students/:id
// Returns the student's own record plus a "currentTrip" block built from
// their most recent boarding record. This is the combined view the
// frontend's "My Child" page needs (student + bus + driver + route +
// boarding + alighting) without having to make four separate requests.
const getStudentById = asyncHandler(async (req, res) => {
  const { id } = req.params;
  if (!isValidId(id)) {
    return res.status(400).json({ error: "Student id must be a number." });
  }

  const [studentRows] = await pool.query("SELECT * FROM students WHERE student_id = ?", [id]);
  if (studentRows.length === 0) {
    return res.status(404).json({ error: `No student found with id ${id}.` });
  }
  const student = studentRows[0];

  const [tripRows] = await pool.query(
    `SELECT
        t.trip_id, t.trip_date, t.start_time, t.end_time,
        b.bus_id, b.bus_number, b.registration_number, b.gps_device_id,
        d.driver_id, d.name AS driver_name, d.phone AS driver_phone,
        r.route_id, r.route_name, r.start_location, r.destination,
        br.boarding_id, br.boarding_time, br.boarding_latitude, br.boarding_longitude,
        br.verification_method AS boarding_verification,
        ar.alighting_id, ar.alighting_time, ar.alighting_latitude, ar.alighting_longitude,
        ar.verification_method AS alighting_verification
      FROM boarding_records br
      JOIN trips t   ON t.trip_id = br.trip_id
      JOIN buses b   ON b.bus_id = t.bus_id
      JOIN drivers d ON d.driver_id = t.driver_id
      JOIN routes r  ON r.route_id = t.route_id
      LEFT JOIN alighting_records ar
             ON ar.trip_id = br.trip_id AND ar.student_id = br.student_id
     WHERE br.student_id = ?
     ORDER BY br.boarding_time DESC
     LIMIT 1`,
    [id]
  );

  const currentTrip = tripRows[0] || null;
  const status = !currentTrip
    ? "No trip on record"
    : currentTrip.alighting_time
    ? "Alighted"
    : "Currently on bus";

  res.json({
    ...student,
    status,
    currentTrip,
  });
});

// GET /api/students/:id/history
// Journey history for the Journey History page: every trip on the
// student's regular bus, with their boarding/alighting for that trip if it
// exists, and a derived status (Completed / In Progress / Missed).
const getStudentHistory = asyncHandler(async (req, res) => {
  const { id } = req.params;
  if (!isValidId(id)) {
    return res.status(400).json({ error: "Student id must be a number." });
  }

  const [studentRows] = await pool.query("SELECT student_id FROM students WHERE student_id = ?", [id]);
  if (studentRows.length === 0) {
    return res.status(404).json({ error: `No student found with id ${id}.` });
  }

  const { getAssignedBusId } = require("./helpers");
  const busId = await getAssignedBusId(id);

  const [rows] = await pool.query(
    `SELECT
        t.trip_id, t.trip_date, t.end_time,
        b.bus_number,
        r.route_name,
        br.boarding_time, br.verification_method AS boarding_verification,
        ar.alighting_time, ar.verification_method AS alighting_verification
      FROM trips t
      JOIN buses b  ON b.bus_id = t.bus_id
      JOIN routes r ON r.route_id = t.route_id
      LEFT JOIN boarding_records br
             ON br.trip_id = t.trip_id AND br.student_id = ?
      LEFT JOIN alighting_records ar
             ON ar.trip_id = t.trip_id AND ar.student_id = ?
     WHERE t.bus_id = ?
     ORDER BY t.trip_date DESC`,
    [id, id, busId]
  );

  const history = rows.map((row) => {
    let status;
    if (row.alighting_time) status = "Completed";
    else if (row.boarding_time && !row.end_time) status = "In Progress";
    else if (row.boarding_time) status = "Completed";
    else status = "Missed";

    return {
      trip_id: row.trip_id,
      date: row.trip_date,
      bus: row.bus_number,
      route: row.route_name,
      boarded: row.boarding_time || null,
      alighted: row.alighting_time || null,
      verification: row.boarding_verification || row.alighting_verification || null,
      status,
    };
  });

  res.json(history);
});

module.exports = { getAllStudents, getStudentById, getStudentHistory };
