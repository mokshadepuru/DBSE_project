const { pool } = require("../db");
const { asyncHandler, isValidId } = require("./helpers");

const TRIP_SELECT = `
  SELECT t.trip_id, t.trip_date, t.start_time, t.end_time,
         b.bus_id, b.bus_number,
         d.driver_id, d.name AS driver_name,
         r.route_id, r.route_name, r.start_location, r.destination
    FROM trips t
    JOIN buses b   ON b.bus_id = t.bus_id
    JOIN drivers d ON d.driver_id = t.driver_id
    JOIN routes r  ON r.route_id = t.route_id
`;

// GET /api/trips
const getAllTrips = asyncHandler(async (req, res) => {
  const [rows] = await pool.query(`${TRIP_SELECT} ORDER BY t.trip_date DESC, t.start_time DESC`);
  res.json(rows);
});

// GET /api/trips/:id
const getTripById = asyncHandler(async (req, res) => {
  const { id } = req.params;
  if (!isValidId(id)) {
    return res.status(400).json({ error: "Trip id must be a number." });
  }

  const [rows] = await pool.query(`${TRIP_SELECT} WHERE t.trip_id = ?`, [id]);
  if (rows.length === 0) {
    return res.status(404).json({ error: `No trip found with id ${id}.` });
  }
  res.json(rows[0]);
});

module.exports = { getAllTrips, getTripById };
