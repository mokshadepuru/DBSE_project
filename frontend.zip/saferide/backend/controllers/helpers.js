const { pool } = require("../db");

/**
 * Wraps an async route handler so a rejected promise is forwarded to
 * Express's error-handling middleware instead of crashing the process.
 */
function asyncHandler(fn) {
  return (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);
}

/**
 * The schema doesn't have a students↔buses assignment table — a student is
 * only ever linked to a bus indirectly, through the trip they boarded.
 * For a single-route prototype like this one, the most reliable stand-in
 * for "this student's regular bus" is the bus from their most recent
 * boarding record, falling back to the first bus on record if the student
 * has never boarded yet.
 */
async function getAssignedBusId(studentId) {
  const [rows] = await pool.query(
    `SELECT t.bus_id
       FROM boarding_records br
       JOIN trips t ON t.trip_id = br.trip_id
      WHERE br.student_id = ?
      ORDER BY br.boarding_time DESC
      LIMIT 1`,
    [studentId]
  );
  if (rows.length > 0) return rows[0].bus_id;

  const [fallback] = await pool.query("SELECT bus_id FROM buses ORDER BY bus_id LIMIT 1");
  return fallback.length > 0 ? fallback[0].bus_id : null;
}

function isValidId(value) {
  return /^\d+$/.test(String(value));
}

module.exports = { asyncHandler, getAssignedBusId, isValidId };
