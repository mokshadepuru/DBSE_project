const { pool } = require("../db");
const { asyncHandler, isValidId } = require("./helpers");

// GET /api/buses
const getAllBuses = asyncHandler(async (req, res) => {
  const [rows] = await pool.query("SELECT * FROM buses ORDER BY bus_number");
  res.json(rows);
});

// GET /api/buses/:id
// Bus details plus its most recent trip (driver + route) and its most
// recent GPS fix, so the frontend's bus/live-tracking cards can render in
// one request.
const getBusById = asyncHandler(async (req, res) => {
  const { id } = req.params;
  if (!isValidId(id)) {
    return res.status(400).json({ error: "Bus id must be a number." });
  }

  const [busRows] = await pool.query("SELECT * FROM buses WHERE bus_id = ?", [id]);
  if (busRows.length === 0) {
    return res.status(404).json({ error: `No bus found with id ${id}.` });
  }

  const [tripRows] = await pool.query(
    `SELECT t.trip_id, t.trip_date, t.start_time, t.end_time,
            d.driver_id, d.name AS driver_name, d.phone AS driver_phone,
            r.route_id, r.route_name, r.start_location, r.destination
       FROM trips t
       JOIN drivers d ON d.driver_id = t.driver_id
       JOIN routes r  ON r.route_id = t.route_id
      WHERE t.bus_id = ?
      ORDER BY t.trip_date DESC, t.start_time DESC
      LIMIT 1`,
    [id]
  );

  const [gpsRows] = await pool.query(
    `SELECT latitude, longitude, recorded_at
       FROM gps_locations
      WHERE bus_id = ?
      ORDER BY recorded_at DESC
      LIMIT 1`,
    [id]
  );

  const currentTrip = tripRows[0] || null;

  res.json({
    ...busRows[0],
    status: currentTrip && !currentTrip.end_time ? "On Route" : "Idle",
    currentTrip,
    lastKnownLocation: gpsRows[0] || null,
  });
});

module.exports = { getAllBuses, getBusById };
