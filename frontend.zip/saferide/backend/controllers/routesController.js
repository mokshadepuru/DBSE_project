const { pool } = require("../db");
const { asyncHandler, isValidId } = require("./helpers");

// GET /api/routes
const getAllRoutes = asyncHandler(async (req, res) => {
  const [rows] = await pool.query("SELECT * FROM routes ORDER BY route_name");
  res.json(rows);
});

// GET /api/routes/:id
const getRouteById = asyncHandler(async (req, res) => {
  const { id } = req.params;
  if (!isValidId(id)) {
    return res.status(400).json({ error: "Route id must be a number." });
  }

  const [rows] = await pool.query("SELECT * FROM routes WHERE route_id = ?", [id]);
  if (rows.length === 0) {
    return res.status(404).json({ error: `No route found with id ${id}.` });
  }
  res.json(rows[0]);
});

module.exports = { getAllRoutes, getRouteById };
