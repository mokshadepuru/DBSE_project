/**
 * scripts/initDb.js
 *
 * Convenience script for local setup: creates the school_bus_safety schema
 * (CREATE TABLE IF NOT EXISTS — it will not touch tables that already
 * exist) and loads the seed data that matches the frontend's original mock
 * data. Safe to re-run.
 *
 * Usage:
 *   npm run db:init
 */
require("dotenv").config();
const fs = require("fs");
const path = require("path");
const mysql = require("mysql2/promise");

async function run() {
  const connection = await mysql.createConnection({
    host: process.env.DB_HOST || "localhost",
    port: Number(process.env.DB_PORT) || 3306,
    user: process.env.DB_USER || "root",
    password: process.env.DB_PASSWORD || "",
    multipleStatements: true,
  });

  const schemaSql = fs.readFileSync(path.join(__dirname, "..", "sql", "schema.sql"), "utf8");
  const seedSql = fs.readFileSync(path.join(__dirname, "..", "sql", "seed.sql"), "utf8");

  console.log("→ Creating database and tables (if they don't already exist)...");
  await runStatements(connection, schemaSql);

  console.log("→ Loading seed data...");
  await runStatements(connection, seedSql);

  console.log("✓ Database ready.");
  await connection.end();
}

// Runs a .sql file statement-by-statement so a harmless "index already
// exists" error on a re-run doesn't abort the whole script.
async function runStatements(connection, sql) {
  const statements = sql
    .split(/;\s*[\r\n]+/)
    .map((s) => s.trim())
    .filter(Boolean);

  for (const statement of statements) {
    try {
      await connection.query(statement);
    } catch (err) {
      // 1061 = ER_DUP_KEYNAME (index already exists) — safe to ignore on re-run.
      if (err.errno === 1061) continue;
      console.error("Failed statement:\n", statement.slice(0, 120), "...");
      throw err;
    }
  }
}

run().catch((err) => {
  console.error("Database initialization failed:", err.message);
  process.exit(1);
});
