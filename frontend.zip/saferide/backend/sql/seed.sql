-- =========================================================================
-- SafeRide — seed data
-- Mirrors the values that were previously hard-coded as frontend mock data,
-- so switching the frontend over to the real API doesn't change what's on
-- screen. Uses INSERT ... ON DUPLICATE KEY UPDATE where a natural unique key
-- exists, so this file is safe to re-run.
-- =========================================================================

USE school_bus_safety;

INSERT INTO students (student_id, name, roll_number, parent_name, parent_phone, pickup_stop, drop_stop)
VALUES (1, 'Moksha', '2520030515', 'Geya Reddy', '+91 98765 43210', 'KPHB', 'KLH University')
ON DUPLICATE KEY UPDATE
  name = VALUES(name),
  parent_name = VALUES(parent_name),
  parent_phone = VALUES(parent_phone),
  pickup_stop = VALUES(pickup_stop),
  drop_stop = VALUES(drop_stop);

INSERT INTO buses (bus_id, bus_number, registration_number, capacity, gps_device_id)
VALUES
  (1, 'BUS-01', 'TS 09 EA 4471', 42, 'GPS001'),
  (2, 'BUS-02', 'TS 09 EA 5522', 40, 'GPS002')
ON DUPLICATE KEY UPDATE
  registration_number = VALUES(registration_number),
  capacity = VALUES(capacity),
  gps_device_id = VALUES(gps_device_id);

INSERT INTO drivers (driver_id, name, phone, license_number)
VALUES (1, 'Ramesh Kumar', '+91 90142 55631', 'TS10 2016 0042311')
ON DUPLICATE KEY UPDATE
  phone = VALUES(phone),
  license_number = VALUES(license_number);

INSERT INTO routes (route_id, route_name, start_location, destination)
VALUES (1, 'Route 1', 'KPHB', 'KLH University')
ON DUPLICATE KEY UPDATE
  start_location = VALUES(start_location),
  destination = VALUES(destination);

-- Today's active trip (no end_time yet => still in progress) plus a short
-- trip history so Journey History has something to show.
INSERT INTO trips (trip_id, bus_id, driver_id, route_id, trip_date, start_time, end_time) VALUES
  (501, 1, 1, 1, CURDATE(),                       '07:00:00', NULL),
  (498, 1, 1, 1, CURDATE() - INTERVAL 1 DAY,       '07:00:00', '08:04:00'),
  (495, 1, 1, 1, CURDATE() - INTERVAL 2 DAY,       '07:00:00', '08:08:00'),
  (492, 2, 1, 1, CURDATE() - INTERVAL 3 DAY,       '07:02:00', '08:10:00'),
  (489, 1, 1, 1, CURDATE() - INTERVAL 4 DAY,       '07:00:00', '08:03:00'),
  (483, 1, 1, 1, CURDATE() - INTERVAL 6 DAY,       '07:00:00', '08:02:00')
ON DUPLICATE KEY UPDATE trip_date = VALUES(trip_date);

INSERT INTO boarding_records (boarding_id, student_id, trip_id, boarding_time, boarding_latitude, boarding_longitude, verification_method) VALUES
  (9001, 1, 501, CONCAT(CURDATE(), ' 07:32:00'),                    17.4938, 78.3915, 'QR'),
  (9002, 1, 498, CONCAT(CURDATE() - INTERVAL 1 DAY, ' 07:30:00'),   17.4938, 78.3915, 'QR'),
  (9003, 1, 495, CONCAT(CURDATE() - INTERVAL 2 DAY, ' 07:34:00'),   17.4938, 78.3915, 'RFID'),
  (9004, 1, 492, CONCAT(CURDATE() - INTERVAL 3 DAY, ' 07:36:00'),   17.4938, 78.3915, 'QR'),
  (9005, 1, 489, CONCAT(CURDATE() - INTERVAL 4 DAY, ' 07:31:00'),   17.4938, 78.3915, 'QR'),
  (9006, 1, 483, CONCAT(CURDATE() - INTERVAL 6 DAY, ' 07:29:00'),   17.4938, 78.3915, 'NFC')
ON DUPLICATE KEY UPDATE boarding_time = VALUES(boarding_time);

INSERT INTO alighting_records (alighting_id, student_id, trip_id, alighting_time, alighting_latitude, alighting_longitude, verification_method) VALUES
  (8001, 1, 498, CONCAT(CURDATE() - INTERVAL 1 DAY, ' 08:04:00'),  17.5453, 78.5731, 'QR'),
  (8002, 1, 495, CONCAT(CURDATE() - INTERVAL 2 DAY, ' 08:08:00'),  17.5453, 78.5731, 'RFID'),
  (8003, 1, 492, CONCAT(CURDATE() - INTERVAL 3 DAY, ' 08:10:00'),  17.5453, 78.5731, 'QR'),
  (8004, 1, 489, CONCAT(CURDATE() - INTERVAL 4 DAY, ' 08:03:00'),  17.5453, 78.5731, 'QR'),
  (8005, 1, 483, CONCAT(CURDATE() - INTERVAL 6 DAY, ' 08:02:00'),  17.5453, 78.5731, 'NFC')
ON DUPLICATE KEY UPDATE alighting_time = VALUES(alighting_time);

-- Note: trip_id 486 (a "missed" day) is intentionally left with no
-- boarding/alighting record — the API derives a "Missed" status for any
-- trip in the past that has no boarding record for the student.
INSERT INTO trips (trip_id, bus_id, driver_id, route_id, trip_date, start_time, end_time) VALUES
  (486, 1, 1, 1, CURDATE() - INTERVAL 5 DAY, '07:00:00', '08:05:00')
ON DUPLICATE KEY UPDATE trip_date = VALUES(trip_date);

INSERT INTO gps_locations (location_id, bus_id, latitude, longitude, recorded_at) VALUES
  (1, 1, 17.4938, 78.3915, CONCAT(CURDATE(), ' 07:00:00')),
  (2, 1, 17.4890, 78.4010, CONCAT(CURDATE(), ' 07:20:00')),
  (3, 1, 17.4849, 78.4108, CONCAT(CURDATE(), ' 07:38:00')),
  (4, 1, 17.4933, 78.3915, CONCAT(CURDATE(), ' 07:50:00'))
ON DUPLICATE KEY UPDATE latitude = VALUES(latitude), longitude = VALUES(longitude);

INSERT INTO alerts (alert_id, student_id, bus_id, alert_type, message, created_at, status) VALUES
  (1, 1, 1, 'Route Deviation',   'BUS-01 has moved away from the planned route.',        CONCAT(CURDATE(), ' 07:55:00'), 'unread'),
  (2, 1, 1, 'Boarding Verified', 'Moksha successfully boarded BUS-01 via QR verification.', CONCAT(CURDATE(), ' 07:32:00'), 'read'),
  (3, NULL, 1, 'Bus On Route',   'Bus is currently following the planned route.',        CONCAT(CURDATE(), ' 07:45:00'), 'read'),
  (4, 1, 1, 'Trip Started',      'BUS-01 departed from the depot for the morning trip.', CONCAT(CURDATE(), ' 07:00:00'), 'read'),
  (5, NULL, 1, 'GPS Unavailable','GPS signal from BUS-01 was briefly unavailable near Kukatpally.', CONCAT(CURDATE() - INTERVAL 1 DAY, ' 08:12:00'), 'read'),
  (6, 1, 1, 'Alighting Verified','Moksha alighted safely at KLH University.',            CONCAT(CURDATE() - INTERVAL 1 DAY, ' 08:06:00'), 'read')
ON DUPLICATE KEY UPDATE message = VALUES(message);
