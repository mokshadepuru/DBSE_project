import "./StatusBadge.css";

/**
 * tone: "success" | "warning" | "info" | "danger" | "neutral"
 */
export default function StatusBadge({ children, tone = "neutral", dot = true }) {
  return (
    <span className={`status-badge status-badge--${tone}`}>
      {dot && <span className="status-badge__dot" />}
      {children}
    </span>
  );
}
