import { useState, useRef, useEffect } from "react";
import { Menu, Search, Bell, LogOut } from "lucide-react";
import { useNavigate } from "react-router-dom";

import { useAuth } from "../context/AuthContext.jsx";
import "./Navbar.css";
import { useSafeRideData } from "../context/SafeRideDataContext.jsx";

export default function Navbar({ title, onMenuClick }) {
  const [notifOpen, setNotifOpen] = useState(false);
  const panelRef = useRef(null);
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const { alerts, adminAlerts, markAlertRead } = useSafeRideData();
  const isAdmin = user?.role === "admin";
  const notificationAlerts = isAdmin ? adminAlerts : alerts;
  const unread = notificationAlerts.filter((a) => a.status === "unread");
  useEffect(() => { function handleClick(e) { if (panelRef.current && !panelRef.current.contains(e.target)) setNotifOpen(false); } document.addEventListener("mousedown", handleClick); return () => document.removeEventListener("mousedown", handleClick); }, []);
  const initials = (user?.name || "SafeRide").split(" ").map((part) => part[0]).slice(0,2).join("").toUpperCase();
  return <header className="navbar">
    <div className="navbar__left"><button className="navbar__menu" onClick={onMenuClick} aria-label="Open menu"><Menu size={22}/></button><h1 className="navbar__title">{title}</h1></div>
    <div className="navbar__right">
      <div className="navbar__search"><Search size={16}/><input type="text" placeholder="Search students, buses, routes…"/></div>
      <div className="navbar__notif" ref={panelRef}><button className="navbar__icon-btn" aria-label="Notifications" onClick={() => setNotifOpen((v) => !v)}><Bell size={19}/>{unread.length > 0 && <span className="navbar__badge">{unread.length}</span>}</button>{notifOpen && <div className="navbar__panel"><div className="navbar__panel-header"><p>Notifications</p><span>{unread.length} unread</span></div><ul className="navbar__panel-list">{notificationAlerts.slice(0,4).map((a) => <li key={a.alert_id} className={a.status === "unread" ? "is-unread" : ""} role="button" tabIndex={0} onClick={() => { markAlertRead(a.alert_id, isAdmin); setNotifOpen(false); navigate(isAdmin ? "/admin/alerts" : "/alerts"); }} onKeyDown={(e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); markAlertRead(a.alert_id, isAdmin); setNotifOpen(false); navigate(isAdmin ? "/admin/alerts" : "/alerts"); } }}><p className="navbar__panel-item-title">{a.alert_type}</p><p className="navbar__panel-item-msg">{a.message}</p><span className="navbar__panel-item-time">{a.created_at}</span></li>)}</ul></div>}</div>
      <div className="navbar__profile"><div className="navbar__avatar">{initials}</div><div className="navbar__profile-text"><p className="navbar__profile-name">{user?.name || "SafeRide User"}</p><p className="navbar__profile-role">{user?.role ? user.role.charAt(0).toUpperCase()+user.role.slice(1) : "User"}</p></div><button className="navbar__logout" onClick={logout} title="Sign out" aria-label="Sign out"><LogOut size={17}/></button></div>
    </div>
  </header>;
}
