import { useEffect, useMemo, useState } from "react";
import { MapContainer, TileLayer, Marker, Polyline, Popup, Tooltip, ZoomControl, useMap } from "react-leaflet";
import L from "leaflet";
import "leaflet/dist/leaflet.css";
import { Navigation, Maximize2, MapPinOff } from "lucide-react";
import "./MapPanel.css";

/**
 * Real interactive street map (Leaflet + OpenStreetMap tiles).
 *
 * Props contract is unchanged from the previous illustrative map, so every
 * existing page keeps working:
 *   stops          route stops {name, location, sequence, lat, lng, type}
 *   currentLocation  latest GPS reading {latitude, longitude}
 *   currentStop    stop object the bus is currently at (optional)
 *   dropStopName   the child's get-down stop (optional)
 *   busLabel, lastUpdated, compact
 *
 * Nothing here is a live GPS feed: the bus marker is placed at whatever
 * reading the app already holds (static demo data or the backend's latest row).
 */

const TILE_URL = "https://tile.openstreetmap.org/{z}/{x}/{y}.png";
const TILE_ATTRIBUTION = '&copy; <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noreferrer">OpenStreetMap</a> contributors';
const FALLBACK_CENTER = [17.4933, 78.3915]; // only used if no valid coordinate exists

const num = (v) => (v === null || v === undefined || v === "" ? NaN : Number(v));
const isValidPoint = (lat, lng) => {
  const a = num(lat), b = num(lng);
  return Number.isFinite(a) && Number.isFinite(b) && Math.abs(a) <= 90 && Math.abs(b) <= 180;
};

// lucide "bus" glyph as a static string (Leaflet divIcons take HTML, not React)
const busSvg = '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#fff8f9" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M8 6v6"/><path d="M15 6v6"/><path d="M2 12h19.6"/><path d="M18 18h3s.5-1.7.8-2.8c.1-.4.2-.8.2-1.2 0-.4-.1-.8-.2-1.2l-1.4-5C20.1 6.8 19.1 6 18 6H4a2 2 0 0 0-2 2v10h3"/><circle cx="7" cy="18" r="2"/><path d="M9 18h5"/><circle cx="16" cy="18" r="2"/></svg>';

const stopIcon = (label) =>
  L.divIcon({
    className: "sr-marker-wrap",
    html: `<div class="sr-stop">${label}</div>`,
    iconSize: [28, 28],
    iconAnchor: [14, 14],
    popupAnchor: [0, -14],
  });

const dropIcon = (label) =>
  L.divIcon({
    className: "sr-marker-wrap",
    html: `<div class="sr-stop sr-stop--drop"><span class="sr-stop__star">★</span><span class="sr-stop__num">${label}</span></div>`,
    iconSize: [42, 42],
    iconAnchor: [21, 21],
    popupAnchor: [0, -22],
  });

const busIcon = L.divIcon({
  className: "sr-marker-wrap",
  html: `<div class="sr-bus">${busSvg}</div>`,
  iconSize: [38, 38],
  iconAnchor: [19, 58], // bus floats above its GPS point so it doesn't hide the stop beneath it
  popupAnchor: [0, -40],
});

const TOOLTIP_DIRS = ["left", "bottom", "right", "top"];

function FitToPoints({ points, fitKey }) {
  const map = useMap();
  // Keep Leaflet sized correctly when the card/grid resizes (prevents grey/collapsed maps)
  useEffect(() => {
    const el = map.getContainer();
    const ro = new ResizeObserver(() => map.invalidateSize());
    ro.observe(el);
    const t = setTimeout(() => map.invalidateSize(), 120);
    return () => { ro.disconnect(); clearTimeout(t); };
  }, [map]);

  useEffect(() => {
    if (!points.length) return;
    map.invalidateSize();
    if (points.length === 1) map.setView(points[0], 15);
    else map.fitBounds(L.latLngBounds(points), { padding: [72, 72], maxZoom: 16 });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [map, fitKey]);
  return null;
}

function FitButton({ points }) {
  const map = useMap();
  if (!points.length) return null;
  return (
    <button
      type="button"
      className="map-panel__fit"
      title="Fit whole route"
      aria-label="Fit whole route"
      onClick={(e) => {
        e.stopPropagation();
        if (points.length === 1) map.setView(points[0], 15);
        else map.fitBounds(L.latLngBounds(points), { padding: [72, 72], maxZoom: 16 });
      }}
    >
      <Maximize2 size={15} />
    </button>
  );
}

export default function MapPanel({
  stops = [],
  currentLocation,
  busLabel = "BUS-01",
  lastUpdated = "just now",
  compact = false,
  dropStopName = null,
  currentStop = null,
}) {
  const [tileErrors, setTileErrors] = useState(0);
  const [tilesLoaded, setTilesLoaded] = useState(0);

  // Valid stops only, in route order. A malformed stop is skipped, never fatal.
  const { validStops, skipped } = useMemo(() => {
    const list = (Array.isArray(stops) ? stops : []).map((s, i) => ({ ...s, _i: i }));
    const ok = list
      .filter((s) => s && isValidPoint(s.lat, s.lng))
      .sort((a, b) => (num(a.sequence) || a._i + 1) - (num(b.sequence) || b._i + 1));
    return { validStops: ok, skipped: list.length - ok.length };
  }, [stops]);

  const busValid = currentLocation && isValidPoint(currentLocation.latitude, currentLocation.longitude);
  const busPos = busValid ? [num(currentLocation.latitude), num(currentLocation.longitude)] : null;

  const routePoints = validStops.map((s) => [num(s.lat), num(s.lng)]);
  const fitPoints = busPos ? [...routePoints, busPos] : routePoints;
  const fitKey = fitPoints.map((p) => p.join(",")).join("|");

  // Completed part of the route = stops up to the bus's current stop, then the bus itself.
  const currentIdx = currentStop ? validStops.findIndex((s) => s.name === currentStop.name) : -1;
  const donePoints = currentIdx >= 0 ? [...routePoints.slice(0, currentIdx + 1), ...(busPos ? [busPos] : [])] : [];
  const showTileNotice = tileErrors > 0 && tilesLoaded === 0;

  return (
    <div className={`map-panel ${compact ? "map-panel--compact" : ""}`}>
      <div className="map-panel__badge">
        <span className="map-panel__live-dot" />
        {busLabel} • LIVE
      </div>

      <div className="map-panel__map">
        <MapContainer
          center={fitPoints[0] || FALLBACK_CENTER}
          zoom={13}
          scrollWheelZoom
          zoomControl={false}
          className="map-panel__leaflet"
        >
          <TileLayer
            url={TILE_URL}
            attribution={TILE_ATTRIBUTION}
            maxZoom={19}
            eventHandlers={{
              tileerror: () => setTileErrors((n) => n + 1),
              tileload: () => setTilesLoaded((n) => n + 1),
            }}
          />
          <ZoomControl position="topright" />
          <FitToPoints points={fitPoints} fitKey={fitKey} />
          <FitButton points={fitPoints} />

          {routePoints.length > 1 && (
            <>
              <Polyline positions={routePoints} pathOptions={{ color: "#8f3048", weight: 5, opacity: 0.55, dashArray: "2 10", lineCap: "round" }} />
              {donePoints.length > 1 && (
                <Polyline positions={donePoints} pathOptions={{ color: "#6b1e2d", weight: 6, opacity: 0.95, lineCap: "round" }} />
              )}
            </>
          )}

          {validStops.map((s, idx) => {
            const isDrop = dropStopName && s.name === dropStopName;
            const seq = num(s.sequence) || s._i + 1;
            const name = s.name || "Unnamed stop";
            return (
              <Marker
                key={`${name}-${s._i}`}
                position={[num(s.lat), num(s.lng)]}
                icon={isDrop ? dropIcon(seq) : stopIcon(seq)}
                zIndexOffset={isDrop ? 500 : 0}
              >
                <Tooltip
                  direction={isDrop ? "left" : TOOLTIP_DIRS[idx % 4]}
                  offset={isDrop ? [-24, 0] : [0, 0]}
                  permanent={!!isDrop}
                  className={isDrop ? "sr-tip sr-tip--drop" : "sr-tip"}
                >
                  {isDrop ? "★ Child's Stop" : name}
                </Tooltip>
                <Popup className="sr-popup">
                  <div className="sr-popup__body">
                    {isDrop && <p className="sr-popup__badge">★ Child's Drop-off Stop</p>}
                    <h4>{name}</h4>
                    <dl>
                      <dt>Location</dt><dd>{s.location || s.address || "Not available"}</dd>
                      <dt>Stop sequence</dt><dd>{seq} of {validStops.length}</dd>
                      <dt>Latitude</dt><dd>{num(s.lat).toFixed(4)}</dd>
                      <dt>Longitude</dt><dd>{num(s.lng).toFixed(4)}</dd>
                    </dl>
                  </div>
                </Popup>
              </Marker>
            );
          })}

          {busPos && (
            <Marker position={busPos} icon={busIcon} zIndexOffset={1000}>
              <Popup className="sr-popup">
                <div className="sr-popup__body">
                  <h4>{busLabel}</h4>
                  <dl>
                    <dt>Bus ID</dt><dd>{busLabel}</dd>
                    <dt>Current location</dt><dd>{currentStop?.location ? `Near ${currentStop.location}` : "Not available"}</dd>
                    <dt>Latitude</dt><dd>{busPos[0].toFixed(4)}</dd>
                    <dt>Longitude</dt><dd>{busPos[1].toFixed(4)}</dd>
                    <dt>Last updated</dt><dd>{lastUpdated || "Not available"}</dd>
                  </dl>
                  <p className="sr-popup__note">Static demo reading, not a live GPS feed.</p>
                </div>
              </Popup>
            </Marker>
          )}
        </MapContainer>

        {showTileNotice && (
          <div className="map-panel__notice" role="status">
            <MapPinOff size={15} /> Map tiles couldn't load. Check your internet connection. Route and stops are still shown.
          </div>
        )}
        {!validStops.length && (
          <div className="map-panel__notice" role="status">
            <MapPinOff size={15} /> No valid stop coordinates available for this route.
          </div>
        )}
      </div>

      <div className="map-panel__footer">
        <div className="map-panel__coords">
          <Navigation size={13} />
          <span>
            {busPos ? `${busPos[0].toFixed(4)}, ${busPos[1].toFixed(4)}` : "GPS location unavailable"}
            {busPos && currentStop?.location ? ` · Near ${currentStop.location}` : ""}
          </span>
        </div>
        <div className="map-panel__updated">
          Last updated: {lastUpdated}
          {skipped > 0 ? ` · ${skipped} stop(s) skipped (invalid coordinates)` : ""}
        </div>
      </div>
    </div>
  );
}
