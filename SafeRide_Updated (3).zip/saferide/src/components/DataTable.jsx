import StatusBadge from "./StatusBadge.jsx";
import "./DataTable.css";

const STATUS_TONE = {
  Completed: "success",
  "In Progress": "info",
  Missed: "danger",
};

export default function DataTable({ columns, rows }) {
  return (
    <div className="data-table__wrap">
      <table className="data-table">
        <thead>
          <tr>
            {columns.map((c) => (
              <th key={c}>{c}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.length === 0 ? (
            <tr>
              <td colSpan={columns.length} className="data-table__empty">
                No journeys match these filters.
              </td>
            </tr>
          ) : (
            rows.map((row, i) => (
              <tr key={i}>
                <td>{row.date}</td>
                <td>{row.bus}</td>
                <td>{row.route}</td>
                <td>{row.boarded}</td>
                <td>{row.alighted}</td>
                <td>{row.verification}</td>
                <td>
                  <StatusBadge tone={STATUS_TONE[row.status] ?? "neutral"} dot={false}>
                    {row.status}
                  </StatusBadge>
                </td>
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  );
}
