import { Flag, QrCode, MapPin, Navigation, GraduationCap } from "lucide-react";
import "./Timeline.css";

const ICONS = {
  start: Flag,
  boarding: QrCode,
  stop: MapPin,
  current: Navigation,
  upcoming: GraduationCap,
};

export default function Timeline({ items }) {
  return (
    <ol className="timeline">
      {items.map((item, i) => {
        const Icon = ICONS[item.type] ?? MapPin;
        const isCurrent = item.type === "current";
        const isUpcoming = item.type === "upcoming";
        return (
          <li key={i} className={`timeline__item ${isCurrent ? "timeline__item--current" : ""} ${isUpcoming ? "timeline__item--upcoming" : ""}`}>
            <span className="timeline__marker">
              <Icon size={14} />
            </span>
            <div className="timeline__body">
              <div className="timeline__row">
                <p className="timeline__title">{item.title}</p>
                <span className="timeline__time">{item.time}</span>
              </div>
              <p className="timeline__desc">{item.description}</p>
            </div>
          </li>
        );
      })}
    </ol>
  );
}
