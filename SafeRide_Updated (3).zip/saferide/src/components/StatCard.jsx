import "./StatCard.css";

export default function StatCard({ icon: Icon, label, value, meta, accent = false }) {
  return (
    <div className={`stat-card ${accent ? "stat-card--accent" : ""}`}>
      <div className="stat-card__top">
        <span className="stat-card__label">{label}</span>
        <span className="stat-card__icon">
          <Icon size={17} strokeWidth={2} />
        </span>
      </div>
      <p className="stat-card__value">{value}</p>
      {meta && <p className="stat-card__meta">{meta}</p>}
    </div>
  );
}
