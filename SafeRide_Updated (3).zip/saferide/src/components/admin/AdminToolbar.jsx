import { Search } from "lucide-react";
import "./AdminTable.css";

export default function AdminToolbar({ searchValue, onSearchChange, searchPlaceholder = "Search…", filters }) {
  return (
    <div className="admin-toolbar">
      <div className="admin-toolbar__search">
        <Search size={15} />
        <input
          type="text"
          value={searchValue}
          onChange={(e) => onSearchChange(e.target.value)}
          placeholder={searchPlaceholder}
        />
      </div>

      {filters && filters.length > 0 && (
        <div className="admin-toolbar__filters">
          {filters.map((f) => (
            <select
              key={f.label}
              className="select-input"
              value={f.value}
              onChange={(e) => f.onChange(e.target.value)}
            >
              {f.options.map((opt) => (
                <option key={opt}>{opt}</option>
              ))}
            </select>
          ))}
        </div>
      )}
    </div>
  );
}
