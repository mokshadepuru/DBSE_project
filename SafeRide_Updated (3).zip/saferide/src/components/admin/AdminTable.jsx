import "../../pages/common.css";
import "./AdminTable.css";

/**
 * A generic, column-driven table for the Admin pages.
 *
 * Unlike the parent-facing <DataTable>, which has Journey History's exact
 * columns baked in, this one takes a `columns` array of
 * `{ header, accessor }` (accessor is a key on the row, or a function that
 * receives the row and returns a node — used for badges/actions). This lets
 * every admin page reuse one component instead of hand-rolling a table each
 * time.
 */
export default function AdminTable({ columns, rows, emptyMessage = "No records match these filters." }) {
  return (
    <div className="data-table__wrap admin-table__wrap">
      <table className="data-table">
        <thead>
          <tr>
            {columns.map((col) => (
              <th key={col.header}>{col.header}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.length === 0 ? (
            <tr>
              <td colSpan={columns.length} className="data-table__empty">
                {emptyMessage}
              </td>
            </tr>
          ) : (
            rows.map((row, i) => (
              <tr key={row.id ?? i}>
                {columns.map((col) => (
                  <td key={col.header}>
                    {typeof col.accessor === "function" ? col.accessor(row) : row[col.accessor]}
                  </td>
                ))}
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  );
}
