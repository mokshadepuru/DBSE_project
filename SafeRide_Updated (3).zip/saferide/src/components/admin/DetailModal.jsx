import { X } from "lucide-react";
import "./DetailModal.css";

/**
 * Read-only counterpart to <QuickActionModal>: shows a simple label/value
 * list for whichever row the admin clicked "View Details" / "View" on.
 */
export default function DetailModal({ title, rows, onClose }) {
  return (
    <div className="detail-modal__overlay" onClick={onClose}>
      <div className="detail-modal" onClick={(e) => e.stopPropagation()}>
        <div className="detail-modal__header">
          <h3>{title}</h3>
          <button className="detail-modal__close" onClick={onClose} aria-label="Close">
            <X size={18} />
          </button>
        </div>
        <dl className="detail-modal__list">
          {rows.map(([label, value]) => (
            <div className="detail-modal__row" key={label}>
              <dt>{label}</dt>
              <dd>{value ?? "—"}</dd>
            </div>
          ))}
        </dl>
      </div>
    </div>
  );
}
