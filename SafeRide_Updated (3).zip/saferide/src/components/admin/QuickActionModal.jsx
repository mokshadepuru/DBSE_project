import { X } from "lucide-react";
import "./QuickActionModal.css";

/**
 * A simple, reusable modal for the Admin dashboard's "Quick Actions".
 * Since the backend isn't finished yet, submitting a form here only updates
 * local React state in the page that opened it — it never claims to write
 * to MySQL. Each page that uses this shows a small note saying so.
 */
export default function QuickActionModal({ title, description, fields, onClose, onSubmit }) {
  function handleSubmit(e) {
    e.preventDefault();
    const data = Object.fromEntries(new FormData(e.target).entries());
    onSubmit(data);
    onClose();
  }

  return (
    <div className="qa-modal__overlay" onClick={onClose}>
      <div className="qa-modal" onClick={(e) => e.stopPropagation()}>
        <div className="qa-modal__header">
          <div>
            <h3>{title}</h3>
            {description && <p>{description}</p>}
          </div>
          <button className="qa-modal__close" onClick={onClose} aria-label="Close">
            <X size={18} />
          </button>
        </div>

        <form className="qa-modal__form" onSubmit={handleSubmit}>
          {fields.map((f) => (
            <label key={f.name}>
              <span>{f.label}</span>
              {f.type === "select" ? (
                <select name={f.name} className="select-input" defaultValue={f.options?.[0]}>
                  {f.options.map((opt) => (
                    <option key={opt}>{opt}</option>
                  ))}
                </select>
              ) : (
                <input
                  name={f.name}
                  type={f.type || "text"}
                  className="select-input"
                  placeholder={f.placeholder}
                  required={f.required}
                />
              )}
            </label>
          ))}

          <p className="qa-modal__note">
            Demo only — this adds a row to the table on screen. Connect the backend to persist it to MySQL.
          </p>

          <div className="qa-modal__actions">
            <button type="button" className="pill-btn" onClick={onClose}>
              Cancel
            </button>
            <button type="submit" className="pill-btn pill-btn--active">
              Save
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
