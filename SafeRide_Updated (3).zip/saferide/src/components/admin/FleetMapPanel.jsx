import { Bus as BusIcon } from "lucide-react";
import StatusBadge from "../StatusBadge.jsx";
import "./FleetMapPanel.css";

const STATUS_TONE = {
  "On Route": "success",
  Delayed: "warning",
  Stopped: "danger",
};

/**
 * A fleet-wide version of the parent dashboard's <MapPanel>: instead of one
 * bus following one route, it lays out several buses (each with its own
 * short route) as parallel lanes on the same illustrative canvas. Like
 * <MapPanel>, this never claims to be a live mapping API — swap it for a
 * real map once the backend streams live bus coordinates.
 */
export default function FleetMapPanel({ buses }) {
  return (
    <div className="fleet-map">
      <div className="fleet-map__badge">
        <span className="fleet-map__live-dot" />
        FLEET · LIVE
      </div>

      <div className="fleet-map__lanes">
        {buses.map((bus) => (
          <div className="fleet-lane" key={bus.bus_number}>
            <div className="fleet-lane__label">
              <span className="fleet-lane__icon">
                <BusIcon size={13} />
              </span>
              <span className="fleet-lane__name">{bus.bus_number}</span>
              <span className="fleet-lane__route">{bus.route}</span>
              <StatusBadge tone={STATUS_TONE[bus.status] ?? "neutral"} dot={false}>
                {bus.status}
              </StatusBadge>
            </div>

            <div className="fleet-lane__track">
              <div className="fleet-lane__line" />
              <div className="fleet-lane__fill" style={{ width: `${bus.progress}%` }} />
              {bus.stops.map((stop, i) => {
                const pos = (i / (bus.stops.length - 1)) * 100;
                const passed = pos <= bus.progress;
                return (
                  <div
                    key={stop}
                    className={`fleet-lane__stop ${passed ? "is-passed" : ""}`}
                    style={{ left: `${pos}%` }}
                    title={stop}
                  />
                );
              })}
              <div className="fleet-lane__bus" style={{ left: `${bus.progress}%` }}>
                <BusIcon size={11} />
              </div>
            </div>

            <div className="fleet-lane__meta">
              <span>{bus.stops[0]} → {bus.stops[bus.stops.length - 1]}</span>
              <span>Updated {bus.lastUpdated}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
