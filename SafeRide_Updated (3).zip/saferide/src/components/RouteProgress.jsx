import { Check } from "lucide-react";
import "./RouteProgress.css";

export default function RouteProgress({ stops, currentStop, progress, dropStopName = null }) {
  const currentIndex = stops.findIndex((s) => s.name === currentStop);

  return (
    <div className="route-progress">
      <div className="route-progress__track">
        <div className="route-progress__fill" style={{ width: `${progress}%` }} />
      </div>
      <div className="route-progress__stops">
        {stops.map((s, i) => {
          const done = i < currentIndex;
          const active = i === currentIndex;
          const isDrop = dropStopName && s.name === dropStopName;
          return (
            <div key={s.name} className={`route-progress__stop ${done ? "is-done" : ""} ${active ? "is-active" : ""} ${isDrop ? "is-drop" : ""}`}>
              <span className="route-progress__dot">{done ? <Check size={11} /> : null}</span>
              <span className="route-progress__label">{s.name}</span>
              {s.location && <span className="route-progress__location">{s.location}</span>}
              {isDrop && <span className="route-progress__drop-tag">Child's Stop</span>}
            </div>
          );
        })}
      </div>
    </div>
  );
}
