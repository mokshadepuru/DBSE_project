import { NavLink } from "react-router-dom";
import { LayoutDashboard, MapPin, UserRound, History, BellRing, Route as RouteIcon, CircleUser, Settings as SettingsIcon, X, ShieldCheck, Users, Bus, UserCog, Navigation2, QrCode, LogOut, Satellite, BusFront } from "lucide-react";
import { useAuth } from "../context/AuthContext.jsx";
import "./Sidebar.css";

const NAV_ITEMS = [
  { to: "/", label: "Dashboard", icon: LayoutDashboard, end: true },
  { to: "/live-tracking", label: "Live Tracking", icon: MapPin },
  { to: "/my-child", label: "My Child", icon: UserRound },
  { to: "/journey-history", label: "Journey History", icon: History },
  { to: "/alerts", label: "Alerts", icon: BellRing },
  { to: "/route", label: "Route", icon: RouteIcon },
  { to: "/profile", label: "Profile", icon: CircleUser },
  { to: "/settings", label: "Settings", icon: SettingsIcon },
];
const DRIVER_NAV_ITEMS = [
  { to: "/driver", label: "Driver Dashboard", icon: BusFront, end: true },
  { to: "/live-tracking", label: "Live Tracking", icon: MapPin },
  { to: "/route", label: "Route", icon: RouteIcon },
];
const ADMIN_NAV_ITEMS = [
  { to: "/admin", label: "Admin Dashboard", icon: ShieldCheck, end: true },
  { to: "/admin/students", label: "Students", icon: Users },
  { to: "/admin/buses", label: "Buses", icon: Bus },
  { to: "/admin/drivers", label: "Drivers", icon: UserCog },
  { to: "/admin/trips", label: "Trips", icon: Navigation2 },
  { to: "/admin/boarding", label: "Boarding Records", icon: QrCode },
  { to: "/admin/alighting", label: "Alighting Records", icon: LogOut },
  { to: "/admin/gps", label: "GPS Monitoring", icon: Satellite },
  { to: "/admin/alerts", label: "Alerts", icon: BellRing },
];

export default function Sidebar({ isOpen, onClose }) {
  const { user } = useAuth();
  const items = user?.role === "admin" ? ADMIN_NAV_ITEMS : user?.role === "driver" ? DRIVER_NAV_ITEMS : NAV_ITEMS;
  const section = user?.role === "admin" ? null : user?.role === "driver" ? "Driver" : null;
  return (
    <aside className={`sidebar ${isOpen ? "sidebar--open" : ""}`}>
      <div className="sidebar__top">
        <div className="sidebar__brand"><span className="sidebar__mark" aria-hidden="true"><svg viewBox="0 0 40 40" width="26" height="26"><path d="M6 24.5V15a4 4 0 0 1 4-4h20a4 4 0 0 1 4 4v9.5a2 2 0 0 1-2 2H30a3.5 3.5 0 0 1-7 0h-6a3.5 3.5 0 0 1-7 0H8a2 2 0 0 1-2-2Z" fill="#FFF8F9"/><circle cx="13" cy="27.5" r="2.1" fill="#FFF8F9"/><circle cx="27" cy="27.5" r="2.1" fill="#FFF8F9"/><rect x="9" y="13.5" width="22" height="6" rx="1.4" fill="#6B1E2D"/></svg></span><div className="sidebar__brand-text"><p className="sidebar__brand-name">SafeRide</p><p className="sidebar__brand-sub">{user?.role === "admin" ? "Admin Portal" : user?.role === "driver" ? "Driver Portal" : "Student Safety Portal"}</p></div></div>
        <button className="sidebar__close" onClick={onClose} aria-label="Close menu"><X size={20} /></button>
      </div>
      <nav className="sidebar__nav">
        {section && <p className="sidebar__section-label">{section}</p>}
        {items.map(({ to, label, icon: Icon, end }) => <NavLink key={to} to={to} end={end} className={({ isActive }) => `sidebar__link ${isActive ? "sidebar__link--active" : ""}`}><Icon size={19} strokeWidth={2}/><span>{label}</span></NavLink>)}
      </nav>
      <div className="sidebar__footer"><p className="sidebar__footer-title">Safety, always in view</p><p className="sidebar__footer-text">GPS follows the bus. Verification confirms your child.</p></div>
    </aside>
  );
}
