import { ShieldCheck, QrCode } from "lucide-react";
import "./StudentCard.css";

export default function StudentCard({ student, bus, status, boardingTime, verification }) {
  const initials = student.name
    .split(" ")
    .map((w) => w[0])
    .join("")
    .toUpperCase();

  return (
    <div className="student-card">
      <div className="student-card__header">
        <div className="student-card__avatar">{initials}</div>
        <div>
          <p className="student-card__name">{student.name}</p>
          <p className="student-card__roll">Roll No: {student.roll_number}</p>
        </div>
      </div>

      <div className="student-card__status">
        <ShieldCheck size={18} />
        <span>{status}</span>
      </div>

      <div className="student-card__grid">
        <div>
          <p className="student-card__label">Pickup</p>
          <p className="student-card__value">{student.pickup_stop}</p>
        </div>
        <div>
          <p className="student-card__label">Drop</p>
          <p className="student-card__value">{student.drop_stop}</p>
        </div>
        <div>
          <p className="student-card__label">Bus</p>
          <p className="student-card__value">{bus.bus_number}</p>
        </div>
        <div>
          <p className="student-card__label">Boarded</p>
          <p className="student-card__value">{boardingTime}</p>
        </div>
      </div>

      <div className="student-card__verify">
        <QrCode size={15} />
        <span>{verification} Verified</span>
      </div>
    </div>
  );
}
