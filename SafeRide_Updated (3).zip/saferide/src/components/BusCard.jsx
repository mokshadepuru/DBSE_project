import { Bus, User, Route as RouteIcon, Satellite, Clock } from "lucide-react";
import StatusBadge from "./StatusBadge.jsx";
import "./BusCard.css";

export default function BusCard({ bus, driver, routeName, status, lastUpdated }) {
  return (
    <div className="bus-card">
      <div className="bus-card__header">
        <div className="bus-card__icon">
          <Bus size={20} />
        </div>
        <div>
          <p className="bus-card__title">{bus.bus_number}</p>
          <p className="bus-card__sub">{bus.registration_number}</p>
        </div>
        <StatusBadge tone="success">{status}</StatusBadge>
      </div>

      <ul className="bus-card__rows">
        <li>
          <span><User size={14} /> Driver</span>
          <span className="bus-card__value">{driver.name}</span>
        </li>
        <li>
          <span><RouteIcon size={14} /> Route</span>
          <span className="bus-card__value">{routeName}</span>
        </li>
        <li>
          <span><Satellite size={14} /> GPS</span>
          <span className="bus-card__value bus-card__value--active">Active</span>
        </li>
        <li>
          <span><Clock size={14} /> Updated</span>
          <span className="bus-card__value">{lastUpdated}</span>
        </li>
      </ul>
    </div>
  );
}
