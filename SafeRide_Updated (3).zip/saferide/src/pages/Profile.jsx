import { Mail, Phone, MapPin, Calendar, GraduationCap, Pencil } from "lucide-react";
import { useSafeRideData } from "../context/SafeRideDataContext.jsx";
import "./common.css";
import "./StudentDetails.css";


export default function Profile() {
  const { parentProfile, student } = useSafeRideData();
  const initials = parentProfile.name
    .split(" ")
    .map((w) => w[0])
    .join("")
    .toUpperCase();

  return (
    <div className="page">
      <div className="page-header">
        <div>
          <h2>Profile</h2>
          <p className="page-header__eyebrow">Your account and linked student information.</p>
        </div>
      </div>

      <div className="student-profile card">
        <div className="student-profile__header">
          <div className="student-profile__avatar">{initials}</div>
          <div>
            <p className="student-profile__name">{parentProfile.name}</p>
            <p className="student-profile__roll">Parent since {parentProfile.joined}</p>
          </div>
          <button className="pill-btn">
            <Pencil size={13} style={{ marginRight: 6, verticalAlign: -2 }} />
            Edit Profile
          </button>
        </div>

        <div className="student-profile__grid">
          <div className="detail-block">
            <span className="detail-block__icon"><Mail size={15} /></span>
            <div>
              <p className="detail-block__label">Email</p>
              <p className="detail-block__value">{parentProfile.email}</p>
            </div>
          </div>
          <div className="detail-block">
            <span className="detail-block__icon"><Phone size={15} /></span>
            <div>
              <p className="detail-block__label">Phone</p>
              <p className="detail-block__value">{parentProfile.phone}</p>
            </div>
          </div>
          <div className="detail-block">
            <span className="detail-block__icon"><MapPin size={15} /></span>
            <div>
              <p className="detail-block__label">Address</p>
              <p className="detail-block__value">{parentProfile.address}</p>
            </div>
          </div>
          <div className="detail-block">
            <span className="detail-block__icon"><Calendar size={15} /></span>
            <div>
              <p className="detail-block__label">Member Since</p>
              <p className="detail-block__value">{parentProfile.joined}</p>
            </div>
          </div>
        </div>
      </div>

      <div className="card">
        <div className="card__header">
          <h3>Linked Students</h3>
        </div>
        <div className="linked-student">
          <span className="linked-student__icon"><GraduationCap size={16} /></span>
          <div>
            <p className="linked-student__name">{student.name}</p>
            <p className="linked-student__roll">Roll No: {student.roll_number} · {student.pickup_stop} → {student.drop_stop}</p>
          </div>
        </div>
      </div>
    </div>
  );
}
