import { Link } from "react-router-dom";
import { BusFront, CheckCircle2, Clock3, MapPin, QrCode, ShieldCheck } from "lucide-react";
import { useAuth } from "../context/AuthContext.jsx";
import { useSafeRideData } from "../context/SafeRideDataContext.jsx";
import "./common.css";
import "./driver.css";

export default function DriverDashboard() {
  const { user } = useAuth();
  const { bus, driver, activeTrip, route, boardingRecord } = useSafeRideData();
  const driverName = user?.name || driver?.name || "Driver";

  return (
    <div className="page">
      <div className="driver-hero">
        <div><p className="page-header__eyebrow">DRIVER PORTAL</p><h2>Good evening, {driverName.split(" ")[0]}.</h2><p>Keep every journey safe, verified, and on schedule.</p></div>
        <div className="driver-hero__icon"><BusFront size={30} /></div>
      </div>

      <div className="stat-grid">
        <div className="driver-stat"><span><BusFront size={17} /> Assigned bus</span><strong>{bus?.bus_number || "BUS-104"}</strong></div>
        <div className="driver-stat"><span><MapPin size={17} /> Route</span><strong>{route?.name || "Route 12"}</strong></div>
        <div className="driver-stat"><span><Clock3 size={17} /> Trip status</span><strong>{activeTrip?.status || "In Progress"}</strong></div>
        <div className="driver-stat"><span><CheckCircle2 size={17} /> Boarding</span><strong>{boardingRecord?.status || "Verified"}</strong></div>
      </div>

      <div className="two-col-grid">
        <div className="card">
          <div className="card__header"><div><h3>Current trip</h3><p>Live details for your assigned journey.</p></div><span className="driver-status"><span /> Active</span></div>
          <div className="driver-trip-card"><div><span>Bus</span><strong>{bus?.bus_number || "BUS-104"}</strong></div><div><span>Route</span><strong>{route?.name || "Route 12"}</strong></div><div><span>Next stop</span><strong>{route?.stops?.[0]?.name || "Main Gate"}</strong></div></div>
          <Link className="driver-primary" to="/live-tracking">Open live tracking <MapPin size={17} /></Link>
        </div>
        <div className="card">
          <div className="card__header"><div><h3>Safety checklist</h3><p>Quick checks before departure.</p></div><ShieldCheck size={21} color="var(--wine-700)" /></div>
          <ul className="driver-checklist"><li><CheckCircle2 size={17} /> GPS device connected</li><li><CheckCircle2 size={17} /> Vehicle inspection recorded</li><li><CheckCircle2 size={17} /> Student verification ready</li></ul>
          <button className="driver-secondary" type="button"><QrCode size={17} /> Open boarding scanner</button>
        </div>
      </div>
    </div>
  );
}
