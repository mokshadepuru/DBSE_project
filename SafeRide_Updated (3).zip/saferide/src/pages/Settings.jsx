import { useState } from "react";
import {
  BellRing,
  ShieldAlert,
  MapPinned,
  UserCog,
  Lock,
  Check,
} from "lucide-react";
import "./common.css";
import "./Settings.css";

function ToggleRow({ title, description, checked, onChange }) {
  return (
    <div className="toggle-row">
      <div>
        <p className="toggle-row__title">{title}</p>
        <p className="toggle-row__desc">{description}</p>
      </div>
      <button
        className={`switch ${checked ? "switch--on" : ""}`}
        role="switch"
        aria-checked={checked}
        aria-label={title}
        onClick={() => onChange(!checked)}
      >
        <span className="switch__thumb" />
      </button>
    </div>
  );
}

export default function Settings() {
  const [notifications, setNotifications] = useState({
    boarding: true,
    alighting: true,
    routeDeviation: true,
    delays: false,
    dailySummary: true,
  });

  const [safety, setSafety] = useState({
    sosAlerts: true,
    gpsUnavailable: true,
    unrecognizedVerification: true,
  });

  const [location, setLocation] = useState({
    liveTracking: true,
    shareWithSchool: true,
    backgroundUpdates: false,
  });

  const [privacy, setPrivacy] = useState({
    shareDataAnalytics: false,
    twoFactor: true,
  });

  const [saved, setSaved] = useState(false);

  function toggle(setFn, key) {
    setFn((prev) => ({ ...prev, [key]: !prev[key] }));
    setSaved(false);
  }

  function handleSave() {
    setSaved(true);
    setTimeout(() => setSaved(false), 2500);
  }

  return (
    <div className="page">
      <div className="page-header">
        <div>
          <h2>Settings</h2>
          <p className="page-header__eyebrow">
            Manage how SafeRide notifies you and what it's allowed to track.
          </p>
        </div>
        <button className="pill-btn pill-btn--active" onClick={handleSave}>
          {saved ? (
            <>
              <Check size={13} style={{ marginRight: 6, verticalAlign: -2 }} />
              Saved
            </>
          ) : (
            "Save Changes"
          )}
        </button>
      </div>

      <div className="card">
        <div className="card__header">
          <span className="settings-section__icon"><BellRing size={16} /></span>
          <div>
            <h3>Notification Settings</h3>
            <p>Choose which journey events send you a notification.</p>
          </div>
        </div>
        <div className="toggle-list">
          <ToggleRow
            title="Boarding confirmations"
            description="Notify me when my child boards the bus."
            checked={notifications.boarding}
            onChange={() => toggle(setNotifications, "boarding")}
          />
          <ToggleRow
            title="Alighting confirmations"
            description="Notify me when my child leaves the bus."
            checked={notifications.alighting}
            onChange={() => toggle(setNotifications, "alighting")}
          />
          <ToggleRow
            title="Route deviation alerts"
            description="Notify me if the bus moves off its planned route."
            checked={notifications.routeDeviation}
            onChange={() => toggle(setNotifications, "routeDeviation")}
          />
          <ToggleRow
            title="Delay alerts"
            description="Notify me if the bus is running behind schedule."
            checked={notifications.delays}
            onChange={() => toggle(setNotifications, "delays")}
          />
          <ToggleRow
            title="Daily journey summary"
            description="Send a short summary once the trip is complete."
            checked={notifications.dailySummary}
            onChange={() => toggle(setNotifications, "dailySummary")}
          />
        </div>
      </div>

      <div className="card">
        <div className="card__header">
          <span className="settings-section__icon"><ShieldAlert size={16} /></span>
          <div>
            <h3>Safety Alerts</h3>
            <p>Critical alerts that stay on even when other notifications are off.</p>
          </div>
        </div>
        <div className="toggle-list">
          <ToggleRow
            title="SOS alerts"
            description="Immediate alert if an SOS is raised on the bus."
            checked={safety.sosAlerts}
            onChange={() => toggle(setSafety, "sosAlerts")}
          />
          <ToggleRow
            title="GPS unavailable warnings"
            description="Notify me if the bus's GPS signal is lost."
            checked={safety.gpsUnavailable}
            onChange={() => toggle(setSafety, "gpsUnavailable")}
          />
          <ToggleRow
            title="Unrecognized verification attempts"
            description="Notify me of a failed or unrecognized QR/RFID scan."
            checked={safety.unrecognizedVerification}
            onChange={() => toggle(setSafety, "unrecognizedVerification")}
          />
        </div>
      </div>

      <div className="two-col-grid">
        <div className="card">
          <div className="card__header">
            <span className="settings-section__icon"><MapPinned size={16} /></span>
            <div>
              <h3>Location Updates</h3>
              <p>Controls for the bus's GPS, not your child's location.</p>
            </div>
          </div>
          <div className="toggle-list">
            <ToggleRow
              title="Live bus tracking"
              description="Show the bus's live position on the map."
              checked={location.liveTracking}
              onChange={() => toggle(setLocation, "liveTracking")}
            />
            <ToggleRow
              title="Share trip status with school"
              description="Let the school view this trip's live status."
              checked={location.shareWithSchool}
              onChange={() => toggle(setLocation, "shareWithSchool")}
            />
            <ToggleRow
              title="Background updates"
              description="Keep the bus location refreshing when the app is in the background."
              checked={location.backgroundUpdates}
              onChange={() => toggle(setLocation, "backgroundUpdates")}
            />
          </div>
        </div>

        <div className="card">
          <div className="card__header">
            <span className="settings-section__icon"><Lock size={16} /></span>
            <div>
              <h3>Privacy Settings</h3>
              <p>Manage how your account data is used.</p>
            </div>
          </div>
          <div className="toggle-list">
            <ToggleRow
              title="Share anonymized usage analytics"
              description="Help improve SafeRide with anonymized usage data."
              checked={privacy.shareDataAnalytics}
              onChange={() => toggle(setPrivacy, "shareDataAnalytics")}
            />
            <ToggleRow
              title="Two-factor authentication"
              description="Require a verification code when signing in."
              checked={privacy.twoFactor}
              onChange={() => toggle(setPrivacy, "twoFactor")}
            />
          </div>
        </div>
      </div>

      <div className="card">
        <div className="card__header">
          <span className="settings-section__icon"><UserCog size={16} /></span>
          <div>
            <h3>Account Settings</h3>
            <p>Basic account details used across the portal.</p>
          </div>
        </div>
        <div className="account-form">
          <label>
            <span>Full Name</span>
            <input type="text" defaultValue="Geya Reddy" className="select-input" />
          </label>
          <label>
            <span>Email</span>
            <input type="email" defaultValue="anitha.reddy@example.com" className="select-input" />
          </label>
          <label>
            <span>Phone</span>
            <input type="tel" defaultValue="+91 98765 43210" className="select-input" />
          </label>
          <label>
            <span>Preferred Language</span>
            <select className="select-input" defaultValue="English">
              <option>English</option>
              <option>Hindi</option>
              <option>Telugu</option>
            </select>
          </label>
        </div>
      </div>
    </div>
  );
}
