import { Satellite, Clock3, Gauge, MapPin, Flag } from "lucide-react";
import MapPanel from "../components/MapPanel.jsx";
import BusCard from "../components/BusCard.jsx";
import RouteProgress from "../components/RouteProgress.jsx";
import StatusBadge from "../components/StatusBadge.jsx";
import { useSafeRideData } from "../context/SafeRideDataContext.jsx";
import { useAuth } from "../context/AuthContext.jsx";
import { findDropStop, findStopByName } from "../utils/stops.js";
import "./common.css";


export default function LiveTracking() {
  const { bus, driver, route, activeTrip, currentGpsLocation, lastUpdatedLabel, student } = useSafeRideData();
  const { user } = useAuth();
  const dropStop = user?.role === "parent" ? findDropStop(route.stops, student) : null;
  const currentStop = findStopByName(route.stops, activeTrip.currentStop);
  const nextStop = findStopByName(route.stops, activeTrip.nextStop);
  return (
    <div className="page">
      <div className="page-header">
        <div>
          <h2>Live Tracking</h2>
          <p className="page-header__eyebrow">
            {bus.bus_number} is currently {activeTrip.status.toLowerCase()} on {route.route_name}.
          </p>
        </div>
        <StatusBadge tone="success">Live · GPS Active</StatusBadge>
      </div>

      <div className="tracking-grid">
        <div className="card" style={{ padding: 0, overflow: "hidden" }}>
          <MapPanel
            stops={route.stops}
            progress={activeTrip.progress}
            currentLocation={currentGpsLocation}
            busLabel={bus.bus_number}
            lastUpdated={lastUpdatedLabel}
            dropStopName={dropStop?.name}
            currentStop={currentStop}
          />
        </div>

        <div style={{ display: "flex", flexDirection: "column", gap: "20px" }}>
          <BusCard
            bus={bus}
            driver={driver}
            routeName={route.route_name}
            status={activeTrip.status}
            lastUpdated={lastUpdatedLabel}
          />

          <div className="card">
            <div className="card__header">
              <h3>Trip Snapshot</h3>
            </div>
            <ul className="snapshot-list">
              <li>
                <span><Gauge size={14} /> Speed (est.)</span>
                <span className="snapshot-list__value">34 km/h</span>
              </li>
              <li>
                <span><Satellite size={14} /> Coordinates</span>
                <span className="snapshot-list__value">
                  {currentGpsLocation.latitude.toFixed(4)}, {currentGpsLocation.longitude.toFixed(4)}
                </span>
              </li>
              <li>
                <span><MapPin size={14} /> Now at</span>
                <span className="snapshot-list__value">{currentStop?.location || activeTrip.currentStop}</span>
              </li>
              {nextStop && (
                <li>
                  <span><Flag size={14} /> Next</span>
                  <span className="snapshot-list__value">{nextStop.location || nextStop.name}</span>
                </li>
              )}
              {dropStop && (
                <li>
                  <span><Flag size={14} /> Child's Stop</span>
                  <span className="snapshot-list__value">{dropStop.name}</span>
                </li>
              )}
              <li>
                <span><Clock3 size={14} /> ETA</span>
                <span className="snapshot-list__value">{activeTrip.eta}</span>
              </li>
            </ul>
          </div>
        </div>
      </div>

      <div className="card">
        <div className="card__header">
          <div>
            <h3>Route Progress</h3>
            <p>
              {route.stops.map((st) => st.name).join(" → ")}
            </p>
          </div>
        </div>
        <RouteProgress
          stops={route.stops}
          currentStop={activeTrip.currentStop}
          progress={activeTrip.progress}
          dropStopName={dropStop?.name}
        />
      </div>
    </div>
  );
}
