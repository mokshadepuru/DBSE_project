import { useMemo, useState } from "react";
import { Filter } from "lucide-react";
import DataTable from "../components/DataTable.jsx";
import { useSafeRideData } from "../context/SafeRideDataContext.jsx";
import "./common.css";


const COLUMNS = ["Date", "Bus", "Route", "Boarded", "Alighted", "Verification", "Status"];

export default function JourneyHistory() {
  const { journeyHistory } = useSafeRideData();
  const [busFilter, setBusFilter] = useState("All Buses");
  const [statusFilter, setStatusFilter] = useState("All Status");
  const [verifyFilter, setVerifyFilter] = useState("All Methods");

  const buses = useMemo(() => ["All Buses", ...new Set(journeyHistory.map((j) => j.bus))], [journeyHistory]);
  const statuses = useMemo(() => ["All Status", ...new Set(journeyHistory.map((j) => j.status))], [journeyHistory]);
  const methods = useMemo(
    () => ["All Methods", ...new Set(journeyHistory.map((j) => j.verification).filter((v) => v !== "—"))],
    []
  );

  const rows = journeyHistory.filter((j) => {
    if (busFilter !== "All Buses" && j.bus !== busFilter) return false;
    if (statusFilter !== "All Status" && j.status !== statusFilter) return false;
    if (verifyFilter !== "All Methods" && j.verification !== verifyFilter) return false;
    return true;
  });

  return (
    <div className="page">
      <div className="page-header">
        <div>
          <h2>Journey History</h2>
          <p className="page-header__eyebrow">A complete record of every verified trip.</p>
        </div>
      </div>

      <div className="card">
        <div className="card__header">
          <div className="filter-row">
            <span className="filter-row__icon"><Filter size={15} /></span>
            <select className="select-input" value={busFilter} onChange={(e) => setBusFilter(e.target.value)}>
              {buses.map((b) => (
                <option key={b}>{b}</option>
              ))}
            </select>
            <select className="select-input" value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)}>
              {statuses.map((s) => (
                <option key={s}>{s}</option>
              ))}
            </select>
            <select className="select-input" value={verifyFilter} onChange={(e) => setVerifyFilter(e.target.value)}>
              {methods.map((m) => (
                <option key={m}>{m}</option>
              ))}
            </select>
            <input type="date" className="select-input" defaultValue="2026-09-09" />
          </div>
        </div>

        <DataTable columns={COLUMNS} rows={rows} />
      </div>
    </div>
  );
}
