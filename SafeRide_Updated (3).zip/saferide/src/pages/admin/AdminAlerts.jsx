import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { BellOff } from "lucide-react";
import AlertCard from "../../components/AlertCard.jsx";
import { useSafeRideData } from "../../context/SafeRideDataContext.jsx";
import "../common.css";
import "./admin.css";


const FILTERS = ["All", "Unread", "Safety", "GPS", "Route", "Journey"];

export default function AdminAlerts() {
  const { adminAlerts, markAlertRead } = useSafeRideData();
  const navigate = useNavigate();
  const [filter, setFilter] = useState("All");

  const handleAlertAction = (alert) => {
    markAlertRead(alert.alert_id, true);
    const paths = {
      "Route Deviation": "/admin/gps",
      "GPS Offline": "/admin/gps",
      "Bus Delay": "/admin/trips",
      "Boarding Alert": "/admin/students",
      "Boarding Verified": "/admin/boarding",
      "Bus On Route": "/admin/gps",
    };
    navigate(paths[alert.alert_type] || "/admin");
  };

  const filtered = adminAlerts.filter((a) => {
    if (filter === "All") return true;
    if (filter === "Unread") return a.status === "unread";
    return a.category === filter.toLowerCase();
  });

  return (
    <div className="page">
      <div className="page-header">
        <div>
          <h2>Alerts</h2>
          <p className="page-header__eyebrow">Every safety, GPS, route, and journey alert across the fleet.</p>
        </div>
      </div>

      <div className="card">
        <div className="card__header">
          <div className="filter-row">
            {FILTERS.map((f) => (
              <button
                key={f}
                className={`pill-btn ${filter === f ? "pill-btn--active" : ""}`}
                onClick={() => setFilter(f)}
              >
                {f}
              </button>
            ))}
          </div>
        </div>

        {filtered.length === 0 ? (
          <div className="empty-state">
            <span className="empty-state__icon"><BellOff size={20} /></span>
            <p style={{ fontWeight: 600, color: "var(--ink-900)" }}>Nothing here</p>
            <p>There are no alerts in this category right now.</p>
          </div>
        ) : (
          <div className="alert-list">
            {filtered.map((a) => (
              <AlertCard key={a.alert_id} alert={a} onAction={handleAlertAction} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
