import { useState } from "react";
import AdminTable from "../../components/admin/AdminTable.jsx";
import AdminToolbar from "../../components/admin/AdminToolbar.jsx";
import StatusBadge from "../../components/StatusBadge.jsx";
import { useSafeRideData } from "../../context/SafeRideDataContext.jsx";
import "../common.css";
import "./admin.css";


export default function AdminAlighting() {
  const { adminAlightingRecords } = useSafeRideData();
  const [search, setSearch] = useState("");

  const rows = adminAlightingRecords.filter((r) => {
    if (!search.trim()) return true;
    const q = search.toLowerCase();
    return r.student.toLowerCase().includes(q) || r.bus.toLowerCase().includes(q);
  });

  return (
    <div className="page">
      <div className="page-header">
        <div>
          <h2>Alighting Records</h2>
          <p className="page-header__eyebrow">Every verified alighting event, matched back to its boarding trip.</p>
        </div>
      </div>

      <div className="card">
        <AdminToolbar
          searchValue={search}
          onSearchChange={setSearch}
          searchPlaceholder="Search by student or bus…"
        />

        <AdminTable
          columns={[
            { header: "Student", accessor: "student" },
            { header: "Bus", accessor: "bus" },
            { header: "Trip", accessor: "trip" },
            { header: "Alighting Time", accessor: "alighting_time" },
            {
              header: "Verification",
              accessor: (row) => <StatusBadge tone="wine" dot={false}>{row.verification_method}</StatusBadge>,
            },
            { header: "Location", accessor: "location" },
          ]}
          rows={rows}
          emptyMessage="No alighting records match your search."
        />
      </div>
    </div>
  );
}
