import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { BellOff } from "lucide-react";
import AlertCard from "../components/AlertCard.jsx";
import { useSafeRideData } from "../context/SafeRideDataContext.jsx";
import "./common.css";


const FILTERS = ["All", "Unread", "Safety", "Journey"];

export default function Alerts() {
  const { alerts: allAlerts, markAlertRead } = useSafeRideData();
  const navigate = useNavigate();
  const [filter, setFilter] = useState("All");

  const handleAlertAction = (alert) => {
    markAlertRead(alert.alert_id);
    const paths = {
      "Route Deviation": "/route",
      "Boarding Verified": "/my-child",
      "Bus On Route": "/live-tracking",
      "Trip Started": "/journey-history",
      "GPS Unavailable": "/live-tracking",
      "Alighting Verified": "/journey-history",
    };
    navigate(paths[alert.alert_type] || "/live-tracking");
  };

  const filtered = allAlerts.filter((a) => {
    if (filter === "All") return true;
    if (filter === "Unread") return a.status === "unread";
    if (filter === "Safety") return a.category === "safety";
    if (filter === "Journey") return a.category === "journey";
    return true;
  });

  return (
    <div className="page">
      <div className="page-header">
        <div>
          <h2>Safety Alerts</h2>
          <p className="page-header__eyebrow">
            Route deviations, boarding events, and every safety notification, in one place.
          </p>
        </div>
      </div>

      <div className="card">
        <div className="card__header">
          <div className="filter-row">
            {FILTERS.map((f) => (
              <button
                key={f}
                className={`pill-btn ${filter === f ? "pill-btn--active" : ""}`}
                onClick={() => setFilter(f)}
              >
                {f}
              </button>
            ))}
          </div>
        </div>

        {filtered.length === 0 ? (
          <div className="empty-state">
            <span className="empty-state__icon"><BellOff size={20} /></span>
            <p style={{ fontWeight: 600, color: "var(--ink-900)" }}>Nothing here</p>
            <p>There are no alerts in this category right now.</p>
          </div>
        ) : (
          <div className="alert-list">
            {filtered.map((a) => (
              <AlertCard key={a.alert_id} alert={a} onAction={handleAlertAction} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
