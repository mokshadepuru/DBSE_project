import { useEffect, useState } from "react";
import { Link, Navigate, useLocation, useNavigate } from "react-router-dom";
import { ArrowRight, BusFront, Eye, EyeOff, ShieldCheck, UserRound } from "lucide-react";
import { useAuth } from "../context/AuthContext.jsx";
import { DEMO_USERS } from "../context/AuthContext.jsx";
import "./auth.css";

const ROLE_CONFIG = {
  parent: { label: "Parent", icon: UserRound, subtitle: "Track your child's school journey" },
  driver: { label: "Driver", icon: BusFront, subtitle: "Manage trips and student boarding" },
  admin: { label: "Admin", icon: ShieldCheck, subtitle: "Manage the complete SafeRide system" },
};

export default function Login() {
  const { user, login } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [role, setRole] = useState("parent");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    setEmail("");
    setPassword("");
    setError("");
  }, [role]);

  if (user) {
    return <Navigate to={user.role === "admin" ? "/admin" : user.role === "driver" ? "/driver" : "/"} replace />;
  }

  const config = ROLE_CONFIG[role];
  const Icon = config.icon;

  const handleSubmit = (event) => {
    event.preventDefault();
    const result = login(email, password, role);
    if (!result.ok) {
      setError(result.message);
      return;
    }
    const requested = location.state?.from;
    const destination = requested && !requested.startsWith("/admin") ? requested : role === "admin" ? "/admin" : role === "driver" ? "/driver" : "/";
    navigate(destination, { replace: true });
  };

  const fillDemo = () => {
    const demo = DEMO_USERS.find((candidate) => candidate.role === role);
    setEmail(demo.email);
    setPassword(demo.password);
    setError("");
  };

  return (
    <div className="auth-page">
      <div className="auth-page__glow auth-page__glow--one" />
      <div className="auth-page__glow auth-page__glow--two" />

      <div className="auth-card">
        <div className="auth-card__brand">
          <div className="auth-card__logo"><BusFront size={25} /></div>
          <div>
            <p className="auth-card__brand-name">SafeRide</p>
            <p className="auth-card__brand-sub">Student Safety Portal</p>
          </div>
        </div>

        <div className="auth-card__intro">
          <p className="auth-card__eyebrow">WELCOME BACK</p>
          <h1>Sign in to SafeRide</h1>
          <p>Secure school transport tracking for families, drivers and administrators.</p>
        </div>

        <div className="role-tabs" aria-label="Choose account type">
          {Object.entries(ROLE_CONFIG).map(([key, item]) => {
            const RoleIcon = item.icon;
            return (
              <button key={key} type="button" className={`role-tab ${role === key ? "role-tab--active" : ""}`} onClick={() => setRole(key)}>
                <RoleIcon size={17} />
                <span>{item.label}</span>
              </button>
            );
          })}
        </div>

        <p className="role-hint"><Icon size={15} /> {config.subtitle}</p>

        <form className="auth-form" onSubmit={handleSubmit}>
          <label>
            Email address
            <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder={`${role}@saferide.com`} required autoComplete="email" />
          </label>

          <label>
            Password
            <span className="password-field">
              <input type={showPassword ? "text" : "password"} value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Enter your password" required autoComplete="current-password" />
              <button type="button" onClick={() => setShowPassword((value) => !value)} aria-label={showPassword ? "Hide password" : "Show password"}>
                {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
              </button>
            </span>
          </label>

          {error && <div className="auth-error" role="alert">{error}</div>}

          <button className="auth-submit" type="submit">
            Sign in as {config.label}
            <ArrowRight size={18} />
          </button>
        </form>

        {role !== "admin" && (
          <p className="auth-register">New {role}? <Link to={`/register?role=${role}`}>Create an account</Link></p>
        )}

        <button type="button" className="demo-link" onClick={fillDemo}>Use demo {config.label.toLowerCase()} credentials</button>

        <div className="auth-demo-box">
          <span>Demo account</span>
          <strong>{DEMO_USERS.find((candidate) => candidate.role === role)?.email}</strong>
          <small>{DEMO_USERS.find((candidate) => candidate.role === role)?.password}</small>
        </div>
      </div>

      <p className="auth-footer">© 2026 SafeRide · School transport safety system</p>
    </div>
  );
}
