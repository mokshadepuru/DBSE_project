import { useState } from "react";
import { Link, useNavigate, useSearchParams } from "react-router-dom";
import { ArrowLeft, ArrowRight, BusFront, Eye, EyeOff, UserRound } from "lucide-react";
import { useAuth } from "../context/AuthContext.jsx";
import "./auth.css";

export default function Register() {
  const { register } = useAuth();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const initialRole = searchParams.get("role") === "driver" ? "driver" : "parent";
  const [role, setRole] = useState(initialRole);
  const [form, setForm] = useState({ name: "", email: "", password: "", confirmPassword: "" });
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState("");

  const update = (key, value) => setForm((current) => ({ ...current, [key]: value }));

  const handleSubmit = (event) => {
    event.preventDefault();
    if (form.password !== form.confirmPassword) {
      setError("Passwords do not match.");
      return;
    }
    const result = register({ name: form.name, email: form.email, password: form.password, role });
    if (!result.ok) {
      setError(result.message);
      return;
    }
    navigate(role === "driver" ? "/driver" : "/", { replace: true });
  };

  return (
    <div className="auth-page">
      <div className="auth-card auth-card--register">
        <Link className="auth-back" to="/login"><ArrowLeft size={16} /> Back to login</Link>
        <div className="auth-card__brand">
          <div className="auth-card__logo"><BusFront size={25} /></div>
          <div><p className="auth-card__brand-name">SafeRide</p><p className="auth-card__brand-sub">Create your account</p></div>
        </div>
        <div className="auth-card__intro">
          <p className="auth-card__eyebrow">GET STARTED</p>
          <h1>Create an account</h1>
          <p>Parents and drivers can create their own accounts. Admin accounts are managed separately.</p>
        </div>

        <div className="role-tabs">
          <button type="button" className={`role-tab ${role === "parent" ? "role-tab--active" : ""}`} onClick={() => setRole("parent")}><UserRound size={17} /> Parent</button>
          <button type="button" className={`role-tab ${role === "driver" ? "role-tab--active" : ""}`} onClick={() => setRole("driver")}><BusFront size={17} /> Driver</button>
        </div>

        <form className="auth-form" onSubmit={handleSubmit}>
          <label>Full name<input value={form.name} onChange={(e) => update("name", e.target.value)} placeholder="Enter your full name" required /></label>
          <label>Email address<input type="email" value={form.email} onChange={(e) => update("email", e.target.value)} placeholder="you@example.com" required /></label>
          <label>Password<span className="password-field"><input type={showPassword ? "text" : "password"} value={form.password} onChange={(e) => update("password", e.target.value)} placeholder="At least 8 characters" required /><button type="button" onClick={() => setShowPassword((value) => !value)}>{showPassword ? <EyeOff size={18} /> : <Eye size={18} />}</button></span></label>
          <label>Confirm password<input type="password" value={form.confirmPassword} onChange={(e) => update("confirmPassword", e.target.value)} placeholder="Re-enter your password" required /></label>
          {error && <div className="auth-error" role="alert">{error}</div>}
          <button className="auth-submit" type="submit">Create {role} account <ArrowRight size={18} /></button>
        </form>
        <p className="auth-register">Already have an account? <Link to="/login">Sign in</Link></p>
      </div>
      <p className="auth-footer">For the prototype, accounts are stored in this browser. Connect registration to MySQL before production.</p>
    </div>
  );
}
