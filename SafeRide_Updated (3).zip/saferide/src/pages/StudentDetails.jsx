import { Phone, MapPin, Bus, User, Clock3, QrCode, LogOut } from "lucide-react";
import StatusBadge from "../components/StatusBadge.jsx";
import { useSafeRideData } from "../context/SafeRideDataContext.jsx";
import "./common.css";
import "./StudentDetails.css";


export default function StudentDetails() {
  const { student, bus, driver, activeTrip, boardingRecord, alightingRecord } = useSafeRideData();
  const initials = student.name
    .split(" ")
    .map((w) => w[0])
    .join("")
    .toUpperCase();

  return (
    <div className="page">
      <div className="page-header">
        <div>
          <h2>My Child</h2>
          <p className="page-header__eyebrow">Everything about {student.name}'s trip today.</p>
        </div>
      </div>

      <div className="student-profile card">
        <div className="student-profile__header">
          <div className="student-profile__avatar">{initials}</div>
          <div>
            <p className="student-profile__name">{student.name}</p>
            <p className="student-profile__roll">Roll No: {student.roll_number}</p>
          </div>
          <StatusBadge tone="success">Currently on bus</StatusBadge>
        </div>

        <div className="student-profile__grid">
          <div className="detail-block">
            <span className="detail-block__icon"><MapPin size={15} /></span>
            <div>
              <p className="detail-block__label">Pickup Stop</p>
              <p className="detail-block__value">{student.pickup_stop}</p>
            </div>
          </div>
          <div className="detail-block">
            <span className="detail-block__icon"><MapPin size={15} /></span>
            <div>
              <p className="detail-block__label">Drop Stop</p>
              <p className="detail-block__value">{student.drop_stop}</p>
            </div>
          </div>
          <div className="detail-block">
            <span className="detail-block__icon"><User size={15} /></span>
            <div>
              <p className="detail-block__label">Parent Name</p>
              <p className="detail-block__value">{student.parent_name}</p>
            </div>
          </div>
          <div className="detail-block">
            <span className="detail-block__icon"><Phone size={15} /></span>
            <div>
              <p className="detail-block__label">Parent Phone</p>
              <p className="detail-block__value">{student.parent_phone}</p>
            </div>
          </div>
        </div>
      </div>

      <div className="two-col-grid">
        <div className="card">
          <div className="card__header">
            <h3>Current Trip</h3>
          </div>
          <ul className="snapshot-list">
            <li>
              <span><Bus size={14} /> Bus</span>
              <span className="snapshot-list__value">{bus.bus_number}</span>
            </li>
            <li>
              <span><User size={14} /> Driver</span>
              <span className="snapshot-list__value">{driver.name}</span>
            </li>
            <li>
              <span><Clock3 size={14} /> Trip Status</span>
              <span className="snapshot-list__value">{activeTrip.status}</span>
            </li>
            <li>
              <span><Clock3 size={14} /> ETA</span>
              <span className="snapshot-list__value">{activeTrip.eta}</span>
            </li>
          </ul>
        </div>

        <div className="card">
          <div className="card__header">
            <h3>Verification Log</h3>
          </div>
          <div className="verify-log">
            <div className="verify-log__item verify-log__item--done">
              <span className="verify-log__icon"><QrCode size={15} /></span>
              <div>
                <p className="verify-log__title">Boarding Verified</p>
                <p className="verify-log__sub">{boardingRecord.boarding_time} · {boardingRecord.verification_method} scan</p>
              </div>
              <StatusBadge tone="success" dot={false}>Confirmed</StatusBadge>
            </div>
            <div className="verify-log__item">
              <span className="verify-log__icon"><LogOut size={15} /></span>
              <div>
                <p className="verify-log__title">Alighting</p>
                <p className="verify-log__sub">{alightingRecord.status}</p>
              </div>
              <StatusBadge tone="neutral" dot={false}>Pending</StatusBadge>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
