import { useEffect, useState } from "react";
import { Routes, Route, useLocation } from "react-router-dom";
import Sidebar from "./components/Sidebar.jsx";
import Navbar from "./components/Navbar.jsx";
import ProtectedRoute from "./components/ProtectedRoute.jsx";
import Dashboard from "./pages/Dashboard.jsx";
import LiveTracking from "./pages/LiveTracking.jsx";
import StudentDetails from "./pages/StudentDetails.jsx";
import JourneyHistory from "./pages/JourneyHistory.jsx";
import Alerts from "./pages/Alerts.jsx";
import RoutePage from "./pages/Route.jsx";
import Profile from "./pages/Profile.jsx";
import Settings from "./pages/Settings.jsx";
import Login from "./pages/Login.jsx";
import Register from "./pages/Register.jsx";
import DriverDashboard from "./pages/DriverDashboard.jsx";
import AdminDashboard from "./pages/admin/AdminDashboard.jsx";
import AdminStudents from "./pages/admin/AdminStudents.jsx";
import AdminBuses from "./pages/admin/AdminBuses.jsx";
import AdminDrivers from "./pages/admin/AdminDrivers.jsx";
import AdminTrips from "./pages/admin/AdminTrips.jsx";
import AdminBoarding from "./pages/admin/AdminBoarding.jsx";
import AdminAlighting from "./pages/admin/AdminAlighting.jsx";
import AdminGps from "./pages/admin/AdminGps.jsx";
import AdminAlerts from "./pages/admin/AdminAlerts.jsx";
import { SafeRideDataProvider } from "./context/SafeRideDataContext.jsx";
import { AuthProvider } from "./context/AuthContext.jsx";
import { useAuth } from "./context/AuthContext.jsx";
import "./App.css";

const PAGE_TITLES = { "/":"Dashboard", "/live-tracking":"Live Tracking", "/my-child":"My Child", "/journey-history":"Journey History", "/alerts":"Safety Alerts", "/route":"Route", "/profile":"Profile", "/settings":"Settings", "/driver":"Driver Dashboard", "/admin":"Admin Dashboard", "/admin/students":"Students", "/admin/buses":"Buses", "/admin/drivers":"Drivers", "/admin/trips":"Trips", "/admin/boarding":"Boarding Records", "/admin/alighting":"Alighting Records", "/admin/gps":"GPS Monitoring", "/admin/alerts":"Admin Alerts" };

function AppShell() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const location = useLocation();
  const { user } = useAuth();
  const title = PAGE_TITLES[location.pathname] ?? "Dashboard";
  useEffect(() => setSidebarOpen(false), [location.pathname]);

  const authPath = location.pathname === "/login" || location.pathname === "/register";
  if (authPath) return <Routes><Route path="/login" element={<Login />} /><Route path="/register" element={<Register />} /></Routes>;

  return <div className="shell"><Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />{sidebarOpen && <button className="shell__scrim" aria-label="Close menu" onClick={() => setSidebarOpen(false)} />}<div className="shell__main"><Navbar title={title} onMenuClick={() => setSidebarOpen(true)} /><main className="shell__content"><Routes>
    <Route element={<ProtectedRoute allowedRoles={["parent"]} />}><Route path="/" element={<Dashboard/>}/><Route path="/my-child" element={<StudentDetails/>}/><Route path="/journey-history" element={<JourneyHistory/>}/><Route path="/alerts" element={<Alerts/>}/><Route path="/profile" element={<Profile/>}/><Route path="/settings" element={<Settings/>}/></Route>
    <Route element={<ProtectedRoute allowedRoles={["parent","driver"]} />}><Route path="/live-tracking" element={<LiveTracking/>}/><Route path="/route" element={<RoutePage/>}/></Route>
    <Route element={<ProtectedRoute allowedRoles={["driver"]} />}><Route path="/driver" element={<DriverDashboard/>}/></Route>
    <Route element={<ProtectedRoute allowedRoles={["admin"]} />}><Route path="/admin" element={<AdminDashboard/>}/><Route path="/admin/students" element={<AdminStudents/>}/><Route path="/admin/buses" element={<AdminBuses/>}/><Route path="/admin/drivers" element={<AdminDrivers/>}/><Route path="/admin/trips" element={<AdminTrips/>}/><Route path="/admin/boarding" element={<AdminBoarding/>}/><Route path="/admin/alighting" element={<AdminAlighting/>}/><Route path="/admin/gps" element={<AdminGps/>}/><Route path="/admin/alerts" element={<AdminAlerts/>}/></Route>
    <Route path="*" element={<Login/>}/>
  </Routes></main></div></div>;
}

export default function App() { return <AuthProvider><SafeRideDataProvider><AppShell/></SafeRideDataProvider></AuthProvider>; }
