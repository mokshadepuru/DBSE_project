import { route as mockRoute } from "../data/mockData.js";

// Specific location details keyed by stop name. Used to enrich stops that
// arrive without them (e.g. from the backend, whose stop list only has
// name/type/lat/lng), so the underlying data always carries location info.
const DETAILS = Object.fromEntries(mockRoute.stops.map((s) => [s.name, s]));

export function enrichStops(stops = []) {
  return stops.map((s, i) => {
    const d = DETAILS[s.name] || {};
    return {
      ...d,
      ...s,
      sequence: s.sequence ?? d.sequence ?? i + 1,
      location: s.location || s.address || d.location || s.name,
      lat: s.lat ?? d.lat,
      lng: s.lng ?? d.lng,
    };
  });
}

// The child's get-down stop comes from the student's existing drop_stop field.
export function findDropStop(stops = [], student) {
  const name = student?.drop_stop;
  return stops.find((s) => s.name === name) || null;
}

export function findStopByName(stops = [], name) {
  return stops.find((s) => s.name === name) || null;
}
