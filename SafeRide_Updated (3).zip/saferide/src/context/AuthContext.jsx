import { createContext, useContext, useEffect, useMemo, useState } from "react";

const AUTH_KEY = "saferide_auth";
const USERS_KEY = "saferide_users";

const DEMO_USERS = [
  {
    id: "parent-001",
    name: "Geya Reddy",
    email: "parent@saferide.com",
    password: "Parent@123",
    role: "parent",
  },
  {
    id: "driver-001",
    name: "Rajesh Kumar",
    email: "driver@saferide.com",
    password: "Driver@123",
    role: "driver",
  },
  {
    id: "admin-001",
    name: "SafeRide Administrator",
    email: "admin@saferide.com",
    password: "Admin@123",
    role: "admin",
  },
];

function getStoredUsers() {
  try {
    const stored = JSON.parse(localStorage.getItem(USERS_KEY));
    return Array.isArray(stored) && stored.length ? stored : DEMO_USERS;
  } catch {
    return DEMO_USERS;
  }
}

function saveUsers(users) {
  localStorage.setItem(USERS_KEY, JSON.stringify(users));
}

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(() => {
    try {
      return JSON.parse(localStorage.getItem(AUTH_KEY)) || null;
    } catch {
      return null;
    }
  });

  useEffect(() => {
    if (user) localStorage.setItem(AUTH_KEY, JSON.stringify(user));
    else localStorage.removeItem(AUTH_KEY);
  }, [user]);

  const login = (email, password, role) => {
    const users = getStoredUsers();
    const match = users.find(
      (candidate) =>
        candidate.email.toLowerCase() === email.trim().toLowerCase() &&
        candidate.password === password &&
        candidate.role === role
    );

    if (!match) {
      return { ok: false, message: "Invalid email, password, or account type." };
    }

    const sessionUser = { id: match.id, name: match.name, email: match.email, role: match.role };
    setUser(sessionUser);
    return { ok: true, user: sessionUser };
  };

  const register = ({ name, email, password, role }) => {
    const users = getStoredUsers();
    const exists = users.some((candidate) => candidate.email.toLowerCase() === email.trim().toLowerCase());

    if (exists) return { ok: false, message: "An account with this email already exists." };
    if (password.length < 8) return { ok: false, message: "Password must contain at least 8 characters." };

    const newUser = {
      id: `${role}-${Date.now()}`,
      name: name.trim(),
      email: email.trim().toLowerCase(),
      password,
      role,
    };
    saveUsers([...users, newUser]);
    const sessionUser = { id: newUser.id, name: newUser.name, email: newUser.email, role: newUser.role };
    setUser(sessionUser);
    return { ok: true, user: sessionUser };
  };

  const logout = () => setUser(null);

  const value = useMemo(() => ({ user, login, register, logout }), [user]);
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) throw new Error("useAuth must be used inside AuthProvider");
  return context;
}

export { DEMO_USERS };
