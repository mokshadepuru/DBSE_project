import { createContext, useContext, useEffect, useState } from "react";
import {
  student as mockStudent, bus as mockBus, driver as mockDriver, route as mockRoute,
  activeTrip as mockActiveTrip, boardingRecord as mockBoardingRecord,
  alightingRecord as mockAlightingRecord, gpsLocations as mockGpsLocations,
  currentGpsLocation as mockCurrentGpsLocation, lastUpdatedLabel as mockLastUpdated,
  alerts as mockAlerts, journeyTimeline as mockJourneyTimeline,
  journeyHistory as mockJourneyHistory, dashboardStats as mockDashboardStats,
  parentProfile as mockParentProfile,
} from "../data/mockData.js";
import { enrichStops } from "../utils/stops.js";
import {
  adminSummary as mockAdminSummary, adminBuses as mockAdminBuses,
  fleetMapBuses as mockFleetMapBuses, adminAlerts as mockAdminAlerts,
  adminRecentActivity as mockAdminRecentActivity, adminStudents as mockAdminStudents,
  adminDrivers as mockAdminDrivers, adminTrips as mockAdminTrips,
  adminBoardingRecords as mockAdminBoardingRecords, adminAlightingRecords as mockAdminAlightingRecords,
  adminGpsMonitoring as mockAdminGpsMonitoring,
} from "../data/adminMockData.js";

const API_BASE = import.meta.env.VITE_API_URL || "http://localhost:5000";

const initial = {
  student: mockStudent, bus: mockBus, driver: mockDriver, route: mockRoute,
  activeTrip: mockActiveTrip, boardingRecord: mockBoardingRecord, alightingRecord: mockAlightingRecord,
  gpsLocations: mockGpsLocations, currentGpsLocation: mockCurrentGpsLocation,
  lastUpdatedLabel: mockLastUpdated, alerts: mockAlerts, journeyTimeline: mockJourneyTimeline,
  journeyHistory: mockJourneyHistory, dashboardStats: mockDashboardStats, parentProfile: mockParentProfile,
  adminSummary: mockAdminSummary, adminBuses: mockAdminBuses, fleetMapBuses: mockFleetMapBuses,
  adminAlerts: mockAdminAlerts, adminRecentActivity: mockAdminRecentActivity,
  adminStudents: mockAdminStudents, adminDrivers: mockAdminDrivers, adminTrips: mockAdminTrips,
  adminBoardingRecords: mockAdminBoardingRecords, adminAlightingRecords: mockAdminAlightingRecords,
  adminGpsMonitoring: mockAdminGpsMonitoring,
};

const DataContext = createContext(initial);

export function SafeRideDataProvider({ children }) {
  const [data, setData] = useState(initial);
  const [backendOnline, setBackendOnline] = useState(false);

  useEffect(() => {
    let alive = true;
    async function load() {
      try {
        const endpoints = [
          `${API_BASE}/api/dashboard?student_id=1`,
          `${API_BASE}/api/admin/dashboard`,
          `${API_BASE}/api/admin/students`,
          `${API_BASE}/api/admin/buses`,
          `${API_BASE}/api/admin/drivers`,
          `${API_BASE}/api/admin/trips`,
          `${API_BASE}/api/admin/boarding`,
          `${API_BASE}/api/admin/alighting`,
          `${API_BASE}/api/admin/gps`,
          `${API_BASE}/api/admin/alerts`,
        ];
        const responses = await Promise.all(endpoints.map((url) => fetch(url)));
        if (responses.some((response) => !response.ok)) throw new Error("API unavailable");
        const [parent, admin, adminStudents, adminBuses, adminDrivers, adminTrips, adminBoardingRecords, adminAlightingRecords, adminGpsMonitoring, adminAlerts] =
          await Promise.all(responses.map((response) => response.json()));
        if (!alive) return;
        setData((prev) => ({
          ...prev,
          ...parent,
          ...admin,
          adminStudents,
          adminBuses,
          adminDrivers,
          adminTrips,
          adminBoardingRecords,
          adminAlightingRecords,
          adminGpsMonitoring,
          adminAlerts,
        }));
        setBackendOnline(true);
      } catch {
        if (alive) setBackendOnline(false);
      }
    }
    load();
    const timer = setInterval(load, 30000);
    return () => { alive = false; clearInterval(timer); };
  }, []);

  const markAlertRead = (alertId, admin = false) => {
    setData((prev) => {
      const key = admin ? "adminAlerts" : "alerts";
      return {
        ...prev,
        [key]: prev[key].map((alert) =>
          alert.alert_id === alertId ? { ...alert, status: "read" } : alert
        ),
      };
    });
  };

  const route = data.route ? { ...data.route, stops: enrichStops(data.route.stops) } : data.route;

  return <DataContext.Provider value={{ ...data, route, backendOnline, apiBase: API_BASE, markAlertRead }}>{children}</DataContext.Provider>;
}

export function useSafeRideData() {
  return useContext(DataContext);
}
