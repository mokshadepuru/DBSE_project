/**
 * Mock data for the Admin dashboard.
 *
 * Kept in its own file, separate from `mockData.js` (which powers the
 * parent-facing pages), so nothing here can ever affect the parent
 * dashboard. Every export mirrors a table — or a join across tables — in
 * the same `school_bus_safety` MySQL schema described in the project spec,
 * so this can be swapped for real `/api/admin/...` responses later without
 * changing any admin component.
 *
 * As with the parent-side mock data: GPS rows always belong to a bus
 * (`bus_id`), never to a student. A student is only ever linked to a bus
 * indirectly, through a boarding record on a trip.
 */

// ---- summary stats for the admin dashboard cards --------------------------
export const adminSummary = {
  totalStudents: { value: 124, meta: "Registered students" },
  activeBuses: { value: 8, meta: "Currently operating" },
  activeTrips: { value: 6, meta: "Trips in progress" },
  activeDrivers: { value: 8, meta: "Drivers on duty" },
  safetyAlerts: { value: 3, meta: "Requires attention" },
};

// ---- drivers ---------------------------------------------------------
export const adminDrivers = [
  { driver_id: 1, name: "Ramesh Kumar", phone: "+91 90142 55631", license_number: "TS10 2016 0042311", assigned_bus: "BUS-01", status: "On Duty" },
  { driver_id: 2, name: "Suresh Rao", phone: "+91 90142 11209", license_number: "TS10 2017 0038820", assigned_bus: "BUS-02", status: "On Duty" },
  { driver_id: 3, name: "Arjun Kumar", phone: "+91 90142 77341", license_number: "TS10 2015 0091124", assigned_bus: "BUS-03", status: "On Duty" },
  { driver_id: 4, name: "Vijay Kumar", phone: "+91 90142 90087", license_number: "TS10 2018 0027733", assigned_bus: "BUS-04", status: "Off Duty" },
  { driver_id: 5, name: "Naveen Reddy", phone: "+91 90142 55210", license_number: "TS10 2016 0055902", assigned_bus: "BUS-05", status: "On Duty" },
  { driver_id: 6, name: "Kiran Babu", phone: "+91 90142 33581", license_number: "TS10 2019 0012276", assigned_bus: "BUS-06", status: "On Duty" },
  { driver_id: 7, name: "Mahesh Goud", phone: "+91 90142 88420", license_number: "TS10 2014 0066512", assigned_bus: "BUS-07", status: "On Duty" },
  { driver_id: 8, name: "Srinivas Rao", phone: "+91 90142 20938", license_number: "TS10 2020 0004471", assigned_bus: "BUS-08", status: "On Duty" },
];

// ---- routes --------------------------------------------------------------
export const adminRoutes = [
  { route_id: 1, route_name: "Route 1", start_location: "KPHB", destination: "KLH University", stops: ["KPHB", "Kukatpally", "JNTU", "KLH University"] },
  { route_id: 2, route_name: "Route 2", start_location: "Miyapur", destination: "KLH University", stops: ["Miyapur", "Bachupally", "Nizampet", "KLH University"] },
  { route_id: 3, route_name: "Route 3", start_location: "Ameerpet", destination: "KLH University", stops: ["Ameerpet", "SR Nagar", "ESI", "KLH University"] },
  { route_id: 4, route_name: "Route 4", start_location: "Madhapur", destination: "KLH University", stops: ["Madhapur", "Gachibowli", "Nanakramguda", "KLH University"] },
];

// ---- buses --------------------------------------------------------------
export const adminBuses = [
  { bus_id: 1, bus_number: "BUS-01", registration_number: "TS 09 EA 4471", capacity: 42, gps_device_id: "GPS001", driver: "Ramesh Kumar", route: "Route 1", status: "On Route", gps_status: "Active", last_updated: "2 min ago" },
  { bus_id: 2, bus_number: "BUS-02", registration_number: "TS 09 EA 5522", capacity: 40, gps_device_id: "GPS002", driver: "Suresh Rao", route: "Route 2", status: "On Route", gps_status: "Active", last_updated: "1 min ago" },
  { bus_id: 3, bus_number: "BUS-03", registration_number: "TS 09 EA 6614", capacity: 38, gps_device_id: "GPS003", driver: "Arjun Kumar", route: "Route 3", status: "Delayed", gps_status: "Active", last_updated: "4 min ago" },
  { bus_id: 4, bus_number: "BUS-04", registration_number: "TS 09 EA 7783", capacity: 40, gps_device_id: "GPS004", driver: "Vijay Kumar", route: "Route 4", status: "Stopped", gps_status: "Offline", last_updated: "8 min ago" },
  { bus_id: 5, bus_number: "BUS-05", registration_number: "TS 09 EA 8021", capacity: 42, gps_device_id: "GPS005", driver: "Naveen Reddy", route: "Route 1", status: "On Route", gps_status: "Active", last_updated: "3 min ago" },
  { bus_id: 6, bus_number: "BUS-06", registration_number: "TS 09 EA 8890", capacity: 36, gps_device_id: "GPS006", driver: "Kiran Babu", route: "Route 2", status: "On Route", gps_status: "Active", last_updated: "2 min ago" },
  { bus_id: 7, bus_number: "BUS-07", registration_number: "TS 09 EA 9142", capacity: 40, gps_device_id: "GPS007", driver: "Mahesh Goud", route: "Route 3", status: "Idle", gps_status: "Active", last_updated: "12 min ago" },
  { bus_id: 8, bus_number: "BUS-08", registration_number: "TS 09 EA 9987", capacity: 38, gps_device_id: "GPS008", driver: "Srinivas Rao", route: "Route 4", status: "Idle", gps_status: "Active", last_updated: "15 min ago" },
];

// Buses shown on the "Live Bus Monitoring" fleet map — a smaller, currently
// moving subset used to keep the visualization readable.
export const fleetMapBuses = [
  { bus_number: "BUS-01", route: "Route 1", stops: adminRoutes[0].stops, progress: 62, status: "On Route", lastUpdated: "2 min ago" },
  { bus_number: "BUS-02", route: "Route 2", stops: adminRoutes[1].stops, progress: 40, status: "On Route", lastUpdated: "1 min ago" },
  { bus_number: "BUS-03", route: "Route 3", stops: adminRoutes[2].stops, progress: 78, status: "Delayed", lastUpdated: "4 min ago" },
  { bus_number: "BUS-04", route: "Route 4", stops: adminRoutes[3].stops, progress: 15, status: "Stopped", lastUpdated: "8 min ago" },
];

// ---- students (admin-wide view; the parent dashboard has its own copy) ---
// Moksha's record intentionally matches the parent-side mock data exactly.
export const adminStudents = [
  { student_id: 1, name: "Moksha", roll_number: "2520030515", parent_name: "Geya Reddy", bus: "BUS-01", pickup_stop: "KPHB", drop_stop: "KLH University", status: "On Bus" },
  { student_id: 2, name: "Aarav Sharma", roll_number: "2520030516", parent_name: "Priya Sharma", bus: "BUS-02", pickup_stop: "Miyapur", drop_stop: "KLH University", status: "On Bus" },
  { student_id: 3, name: "Diya Patel", roll_number: "2520030517", parent_name: "Nitin Patel", bus: "BUS-03", pickup_stop: "Ameerpet", drop_stop: "KLH University", status: "On Bus" },
  { student_id: 4, name: "Rohan Verma", roll_number: "2520030518", parent_name: "Sunita Verma", bus: "BUS-04", pickup_stop: "Madhapur", drop_stop: "KLH University", status: "Not Boarded" },
  { student_id: 5, name: "Ananya Rao", roll_number: "2520030519", parent_name: "Kavitha Rao", bus: "BUS-01", pickup_stop: "Kukatpally", drop_stop: "KLH University", status: "On Bus" },
  { student_id: 6, name: "Vihaan Reddy", roll_number: "2520030520", parent_name: "Lakshmi Reddy", bus: "BUS-05", pickup_stop: "KPHB", drop_stop: "KLH University", status: "Alighted" },
  { student_id: 7, name: "Ishita Nair", roll_number: "2520030521", parent_name: "Ramesh Nair", bus: "BUS-06", pickup_stop: "Bachupally", drop_stop: "KLH University", status: "On Bus" },
];

// ---- trips --------------------------------------------------------------
export const adminTrips = [
  { trip_id: 501, bus: "BUS-01", driver: "Ramesh Kumar", route: "Route 1", date: "09 Sep 2026", start_time: "07:00 AM", end_time: "—", status: "In Progress" },
  { trip_id: 502, bus: "BUS-02", driver: "Suresh Rao", route: "Route 2", date: "09 Sep 2026", start_time: "07:05 AM", end_time: "—", status: "In Progress" },
  { trip_id: 503, bus: "BUS-03", driver: "Arjun Kumar", route: "Route 3", date: "09 Sep 2026", start_time: "07:02 AM", end_time: "—", status: "Delayed" },
  { trip_id: 504, bus: "BUS-04", driver: "Vijay Kumar", route: "Route 4", date: "09 Sep 2026", start_time: "06:58 AM", end_time: "07:40 AM", status: "Stopped" },
  { trip_id: 505, bus: "BUS-05", driver: "Naveen Reddy", route: "Route 1", date: "09 Sep 2026", start_time: "07:03 AM", end_time: "—", status: "In Progress" },
  { trip_id: 506, bus: "BUS-06", driver: "Kiran Babu", route: "Route 2", date: "09 Sep 2026", start_time: "07:01 AM", end_time: "—", status: "In Progress" },
  { trip_id: 498, bus: "BUS-01", driver: "Ramesh Kumar", route: "Route 1", date: "08 Sep 2026", start_time: "07:00 AM", end_time: "08:04 AM", status: "Completed" },
  { trip_id: 495, bus: "BUS-01", driver: "Ramesh Kumar", route: "Route 1", date: "07 Sep 2026", start_time: "07:00 AM", end_time: "08:08 AM", status: "Completed" },
];

// ---- boarding_records ------------------------------------------------
export const adminBoardingRecords = [
  { boarding_id: 9001, student: "Moksha", bus: "BUS-01", trip: "Trip 501", boarding_time: "07:32 AM", verification_method: "QR", location: "KPHB" },
  { boarding_id: 9010, student: "Aarav Sharma", bus: "BUS-02", trip: "Trip 502", boarding_time: "07:35 AM", verification_method: "RFID", location: "Miyapur" },
  { boarding_id: 9011, student: "Diya Patel", bus: "BUS-03", trip: "Trip 503", boarding_time: "07:40 AM", verification_method: "QR", location: "Ameerpet" },
  { boarding_id: 9012, student: "Ananya Rao", bus: "BUS-01", trip: "Trip 501", boarding_time: "07:45 AM", verification_method: "QR", location: "Kukatpally" },
  { boarding_id: 9013, student: "Ishita Nair", bus: "BUS-06", trip: "Trip 506", boarding_time: "07:33 AM", verification_method: "NFC", location: "Bachupally" },
];

// ---- alighting_records ------------------------------------------------
export const adminAlightingRecords = [
  { alighting_id: 8001, student: "Vihaan Reddy", bus: "BUS-05", trip: "Trip 505", alighting_time: "07:48 AM", verification_method: "QR", location: "KPHB" },
  { alighting_id: 8002, student: "Moksha", bus: "BUS-01", trip: "Trip 498", alighting_time: "08:04 AM", verification_method: "QR", location: "KLH University" },
  { alighting_id: 8003, student: "Diya Patel", bus: "BUS-03", trip: "Trip 495", alighting_time: "08:08 AM", verification_method: "RFID", location: "KLH University" },
];

// ---- gps_locations (latest reading per bus) ------------------------------
export const adminGpsMonitoring = [
  { bus: "BUS-01", gps_device_id: "GPS001", latitude: 17.4933, longitude: 78.3915, last_updated: "2 min ago", status: "Active" },
  { bus: "BUS-02", gps_device_id: "GPS002", latitude: 17.4991, longitude: 78.4192, last_updated: "1 min ago", status: "Active" },
  { bus: "BUS-03", gps_device_id: "GPS003", latitude: 17.4374, longitude: 78.4482, last_updated: "4 min ago", status: "Active" },
  { bus: "BUS-04", gps_device_id: "GPS004", latitude: 17.4483, longitude: 78.3915, last_updated: "8 min ago", status: "Offline" },
  { bus: "BUS-05", gps_device_id: "GPS005", latitude: 17.4938, longitude: 78.3915, last_updated: "3 min ago", status: "Active" },
  { bus: "BUS-06", gps_device_id: "GPS006", latitude: 17.4975, longitude: 78.3532, last_updated: "2 min ago", status: "Active" },
  { bus: "BUS-07", gps_device_id: "GPS007", latitude: 17.4239, longitude: 78.4738, last_updated: "12 min ago", status: "Active" },
  { bus: "BUS-08", gps_device_id: "GPS008", latitude: 17.4483, longitude: 78.3915, last_updated: "15 min ago", status: "Active" },
];

// ---- alerts --------------------------------------------------------------
export const adminAlerts = [
  {
    alert_id: 1,
    alert_type: "Route Deviation",
    category: "route",
    severity: "warning",
    student: null,
    bus: "BUS-01",
    message: "BUS-01 has deviated from the planned route.",
    created_at: "10 minutes ago",
    status: "unread",
    action_label: "View Route",
  },
  {
    alert_id: 2,
    alert_type: "GPS Offline",
    category: "gps",
    severity: "warning",
    student: null,
    bus: "BUS-04",
    message: "GPS device GPS004 is not responding.",
    created_at: "15 minutes ago",
    status: "unread",
    action_label: "Check Device",
  },
  {
    alert_id: 3,
    alert_type: "Bus Delay",
    category: "route",
    severity: "warning",
    student: null,
    bus: "BUS-03",
    message: "BUS-03 is delayed by approximately 8 minutes.",
    created_at: "20 minutes ago",
    status: "unread",
    action_label: "View Trip",
  },
  {
    alert_id: 4,
    alert_type: "Boarding Alert",
    category: "safety",
    severity: "warning",
    student: "Rohan Verma",
    bus: "BUS-04",
    message: "Expected student has not been verified.",
    created_at: "25 minutes ago",
    status: "read",
    action_label: "View Student",
  },
  {
    alert_id: 5,
    alert_type: "Boarding Verified",
    category: "journey",
    severity: "success",
    student: "Moksha",
    bus: "BUS-01",
    message: "Moksha successfully boarded BUS-01 via QR verification.",
    created_at: "07:32 AM",
    status: "read",
  },
  {
    alert_id: 6,
    alert_type: "Bus On Route",
    category: "journey",
    severity: "info",
    student: null,
    bus: "BUS-02",
    message: "BUS-02 is currently following the planned route.",
    created_at: "07:45 AM",
    status: "read",
  },
];

// ---- recent student activity (dashboard timeline) ------------------------
export const adminRecentActivity = [
  { time: "07:32 AM", title: "Moksha boarded BUS-01", detail: "QR Verified", type: "boarding" },
  { time: "07:35 AM", title: "Student boarded BUS-02", detail: "RFID Verified", type: "boarding" },
  { time: "07:48 AM", title: "Student alighted from BUS-03", detail: "QR Verified", type: "alighting" },
  { time: "08:00 AM", title: "Student boarding verification completed", detail: "BUS-01", type: "info" },
];
