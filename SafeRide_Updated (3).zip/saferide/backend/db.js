const mysql = require("mysql2/promise");
require("dotenv").config();

// A pooled connection is reused across requests instead of opening a new
// MySQL connection per API call. All credentials come from environment
// variables (see .env.example) — nothing is hard-coded, and nothing here
// is ever sent to the frontend.
const pool = mysql.createPool({
  host: process.env.DB_HOST || "localhost",
  port: Number(process.env.DB_PORT) || 3306,
  user: process.env.DB_USER || "root",
  password: process.env.DB_PASSWORD || "",
  database: process.env.DB_NAME || "school_bus_safety",
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
  dateStrings: true,
});

/**
 * Simple connectivity check used by GET /api/health and at server startup.
 * Never throws — callers get a boolean plus the raw error message so the
 * health endpoint can report a useful status either way.
 */
async function checkConnection() {
  try {
    const conn = await pool.getConnection();
    await conn.query("SELECT 1");
    conn.release();
    return { connected: true };
  } catch (err) {
    return { connected: false, error: err.message };
  }
}

module.exports = { pool, checkConnection };
