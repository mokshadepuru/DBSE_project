require("dotenv").config();
const fs=require("fs"),path=require("path"),mysql=require("mysql2/promise");
async function run(){
 const c=await mysql.createConnection({host:process.env.DB_HOST||"localhost",port:Number(process.env.DB_PORT)||3306,user:process.env.DB_USER||"root",password:process.env.DB_PASSWORD||"",multipleStatements:true});
 for(const file of ["schema.sql","seed.sql"]){
   const sql=fs.readFileSync(path.join(__dirname,"..","sql",file),"utf8");
   console.log(`→ Running ${file}...`);
   await c.query(sql);
 }
 await c.end(); console.log("✓ SafeRide database initialized.");
}
run().catch(e=>{console.error("Database initialization failed:",e.message);process.exit(1)});
