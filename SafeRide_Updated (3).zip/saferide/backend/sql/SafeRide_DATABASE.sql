-- =========================================================================
-- SafeRide — school_bus_safety schema
-- Matches the existing table structure exactly. Safe to re-run: every
-- CREATE TABLE uses IF NOT EXISTS, so it will not touch tables that already
-- exist in your database.
-- =========================================================================

CREATE DATABASE IF NOT EXISTS school_bus_safety;
USE school_bus_safety;

CREATE TABLE IF NOT EXISTS students (
  student_id     INT AUTO_INCREMENT PRIMARY KEY,
  name           VARCHAR(120) NOT NULL,
  roll_number    VARCHAR(40)  NOT NULL UNIQUE,
  parent_name    VARCHAR(120) NOT NULL,
  parent_phone   VARCHAR(30)  NOT NULL,
  pickup_stop    VARCHAR(120) NOT NULL,
  drop_stop      VARCHAR(120) NOT NULL
);

CREATE TABLE IF NOT EXISTS buses (
  bus_id               INT AUTO_INCREMENT PRIMARY KEY,
  bus_number           VARCHAR(30)  NOT NULL UNIQUE,
  registration_number  VARCHAR(30)  NOT NULL,
  capacity             INT          NOT NULL,
  gps_device_id        VARCHAR(30)  NOT NULL
);

CREATE TABLE IF NOT EXISTS drivers (
  driver_id       INT AUTO_INCREMENT PRIMARY KEY,
  name            VARCHAR(120) NOT NULL,
  phone           VARCHAR(30)  NOT NULL,
  license_number  VARCHAR(40)  NOT NULL
);

CREATE TABLE IF NOT EXISTS routes (
  route_id        INT AUTO_INCREMENT PRIMARY KEY,
  route_name      VARCHAR(80)  NOT NULL,
  start_location  VARCHAR(120) NOT NULL,
  destination     VARCHAR(120) NOT NULL
);

CREATE TABLE IF NOT EXISTS trips (
  trip_id     INT AUTO_INCREMENT PRIMARY KEY,
  bus_id      INT NOT NULL,
  driver_id   INT NOT NULL,
  route_id    INT NOT NULL,
  trip_date   DATE NOT NULL,
  start_time  TIME NOT NULL,
  end_time    TIME NULL,
  FOREIGN KEY (bus_id)    REFERENCES buses(bus_id),
  FOREIGN KEY (driver_id) REFERENCES drivers(driver_id),
  FOREIGN KEY (route_id)  REFERENCES routes(route_id)
);

CREATE TABLE IF NOT EXISTS boarding_records (
  boarding_id           INT AUTO_INCREMENT PRIMARY KEY,
  student_id            INT NOT NULL,
  trip_id               INT NOT NULL,
  boarding_time         DATETIME NOT NULL,
  boarding_latitude     DECIMAL(10, 6) NOT NULL,
  boarding_longitude    DECIMAL(10, 6) NOT NULL,
  verification_method   VARCHAR(20) NOT NULL,
  FOREIGN KEY (student_id) REFERENCES students(student_id),
  FOREIGN KEY (trip_id)    REFERENCES trips(trip_id)
);

CREATE TABLE IF NOT EXISTS alighting_records (
  alighting_id          INT AUTO_INCREMENT PRIMARY KEY,
  student_id            INT NOT NULL,
  trip_id               INT NOT NULL,
  alighting_time        DATETIME NOT NULL,
  alighting_latitude    DECIMAL(10, 6) NOT NULL,
  alighting_longitude   DECIMAL(10, 6) NOT NULL,
  verification_method   VARCHAR(20) NOT NULL,
  FOREIGN KEY (student_id) REFERENCES students(student_id),
  FOREIGN KEY (trip_id)    REFERENCES trips(trip_id)
);

CREATE TABLE IF NOT EXISTS gps_locations (
  location_id   INT AUTO_INCREMENT PRIMARY KEY,
  bus_id        INT NOT NULL,
  latitude      DECIMAL(10, 6) NOT NULL,
  longitude     DECIMAL(10, 6) NOT NULL,
  recorded_at   DATETIME NOT NULL,
  FOREIGN KEY (bus_id) REFERENCES buses(bus_id)
);

CREATE TABLE IF NOT EXISTS alerts (
  alert_id     INT AUTO_INCREMENT PRIMARY KEY,
  student_id   INT NULL,
  bus_id       INT NULL,
  alert_type   VARCHAR(60) NOT NULL,
  message      VARCHAR(255) NOT NULL,
  created_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  status       VARCHAR(20) NOT NULL DEFAULT 'unread',
  FOREIGN KEY (student_id) REFERENCES students(student_id),
  FOREIGN KEY (bus_id)     REFERENCES buses(bus_id)
);

CREATE INDEX idx_boarding_student   ON boarding_records(student_id);
CREATE INDEX idx_alighting_student  ON alighting_records(student_id);
CREATE INDEX idx_gps_bus_recorded   ON gps_locations(bus_id, recorded_at);
CREATE INDEX idx_alerts_student     ON alerts(student_id);
CREATE INDEX idx_trips_bus_date     ON trips(bus_id, trip_date);


-- ==================== SEED DATA ====================

USE school_bus_safety;

INSERT INTO students (student_id,name,roll_number,parent_name,parent_phone,pickup_stop,drop_stop) VALUES
(1,'Moksha','2520030515','Geya Reddy','+91 98765 43210','KPHB','KLH University'),
(2,'Aarav Sharma','2520030516','Priya Sharma','+91 90000 10001','Miyapur','KLH University'),
(3,'Diya Patel','2520030517','Nitin Patel','+91 90000 10002','Ameerpet','KLH University'),
(4,'Rohan Verma','2520030518','Sunita Verma','+91 90000 10003','Madhapur','KLH University'),
(5,'Ananya Rao','2520030519','Kavitha Rao','+91 90000 10004','Kukatpally','KLH University'),
(6,'Vihaan Reddy','2520030520','Lakshmi Reddy','+91 90000 10005','KPHB','KLH University'),
(7,'Ishita Nair','2520030521','Ramesh Nair','+91 90000 10006','Bachupally','KLH University')
ON DUPLICATE KEY UPDATE name=VALUES(name),parent_name=VALUES(parent_name),parent_phone=VALUES(parent_phone),pickup_stop=VALUES(pickup_stop),drop_stop=VALUES(drop_stop);

INSERT INTO buses (bus_id,bus_number,registration_number,capacity,gps_device_id) VALUES
(1,'BUS-01','TS 09 EA 4471',42,'GPS001'),(2,'BUS-02','TS 09 EA 5522',40,'GPS002'),
(3,'BUS-03','TS 09 EA 6614',38,'GPS003'),(4,'BUS-04','TS 09 EA 7783',40,'GPS004'),
(5,'BUS-05','TS 09 EA 8021',42,'GPS005'),(6,'BUS-06','TS 09 EA 8890',36,'GPS006'),
(7,'BUS-07','TS 09 EA 9142',40,'GPS007'),(8,'BUS-08','TS 09 EA 9987',38,'GPS008')
ON DUPLICATE KEY UPDATE registration_number=VALUES(registration_number),capacity=VALUES(capacity),gps_device_id=VALUES(gps_device_id);

INSERT INTO drivers (driver_id,name,phone,license_number) VALUES
(1,'Ramesh Kumar','+91 90142 55631','TS10 2016 0042311'),(2,'Suresh Rao','+91 90142 11209','TS10 2017 0038820'),
(3,'Arjun Kumar','+91 90142 77341','TS10 2015 0091124'),(4,'Vijay Kumar','+91 90142 90087','TS10 2018 0027733'),
(5,'Naveen Reddy','+91 90142 55210','TS10 2016 0055902'),(6,'Kiran Babu','+91 90142 33581','TS10 2019 0012276'),
(7,'Mahesh Goud','+91 90142 88420','TS10 2014 0066512'),(8,'Srinivas Rao','+91 90142 20938','TS10 2020 0004471')
ON DUPLICATE KEY UPDATE phone=VALUES(phone),license_number=VALUES(license_number);

INSERT INTO routes (route_id,route_name,start_location,destination) VALUES
(1,'Route 1','KPHB','KLH University'),(2,'Route 2','Miyapur','KLH University'),
(3,'Route 3','Ameerpet','KLH University'),(4,'Route 4','Madhapur','KLH University')
ON DUPLICATE KEY UPDATE start_location=VALUES(start_location),destination=VALUES(destination);

INSERT INTO trips (trip_id,bus_id,driver_id,route_id,trip_date,start_time,end_time) VALUES
(501,1,1,1,CURDATE(),'07:00:00',NULL),(502,2,2,2,CURDATE(),'07:05:00',NULL),
(503,3,3,3,CURDATE(),'07:02:00',NULL),(504,4,4,4,CURDATE(),'06:58:00','07:40:00'),
(505,5,5,1,CURDATE(),'07:03:00',NULL),(506,6,6,2,CURDATE(),'07:01:00',NULL),
(498,1,1,1,CURDATE()-INTERVAL 1 DAY,'07:00:00','08:04:00'),
(495,1,1,1,CURDATE()-INTERVAL 2 DAY,'07:00:00','08:08:00'),
(492,2,2,1,CURDATE()-INTERVAL 3 DAY,'07:02:00','08:10:00'),
(489,1,1,1,CURDATE()-INTERVAL 4 DAY,'07:00:00','08:03:00'),
(486,1,1,1,CURDATE()-INTERVAL 5 DAY,'07:00:00','08:05:00'),
(483,1,1,1,CURDATE()-INTERVAL 6 DAY,'07:00:00','08:02:00')
ON DUPLICATE KEY UPDATE trip_date=VALUES(trip_date),end_time=VALUES(end_time);

INSERT INTO boarding_records (boarding_id,student_id,trip_id,boarding_time,boarding_latitude,boarding_longitude,verification_method) VALUES
(9001,1,501,CONCAT(CURDATE(),' 07:32:00'),17.4938,78.3915,'QR'),
(9002,2,502,CONCAT(CURDATE(),' 07:35:00'),17.4991,78.4192,'RFID'),
(9003,3,503,CONCAT(CURDATE(),' 07:40:00'),17.4374,78.4482,'QR'),
(9004,5,501,CONCAT(CURDATE(),' 07:45:00'),17.4849,78.4108,'QR'),
(9005,7,506,CONCAT(CURDATE(),' 07:33:00'),17.4975,78.3532,'NFC'),
(9006,1,498,CONCAT(CURDATE()-INTERVAL 1 DAY,' 07:30:00'),17.4938,78.3915,'QR'),
(9007,1,495,CONCAT(CURDATE()-INTERVAL 2 DAY,' 07:34:00'),17.4938,78.3915,'RFID'),
(9008,1,492,CONCAT(CURDATE()-INTERVAL 3 DAY,' 07:36:00'),17.4938,78.3915,'QR'),
(9009,1,489,CONCAT(CURDATE()-INTERVAL 4 DAY,' 07:31:00'),17.4938,78.3915,'QR'),
(9010,1,483,CONCAT(CURDATE()-INTERVAL 6 DAY,' 07:29:00'),17.4938,78.3915,'NFC')
ON DUPLICATE KEY UPDATE boarding_time=VALUES(boarding_time),verification_method=VALUES(verification_method);

INSERT INTO alighting_records (alighting_id,student_id,trip_id,alighting_time,alighting_latitude,alighting_longitude,verification_method) VALUES
(8001,6,505,CONCAT(CURDATE(),' 07:48:00'),17.4938,78.3915,'QR'),
(8002,1,498,CONCAT(CURDATE()-INTERVAL 1 DAY,' 08:04:00'),17.5453,78.5731,'QR'),
(8003,1,495,CONCAT(CURDATE()-INTERVAL 2 DAY,' 08:08:00'),17.5453,78.5731,'RFID'),
(8004,1,492,CONCAT(CURDATE()-INTERVAL 3 DAY,' 08:10:00'),17.5453,78.5731,'QR'),
(8005,1,489,CONCAT(CURDATE()-INTERVAL 4 DAY,' 08:03:00'),17.5453,78.5731,'QR'),
(8006,1,483,CONCAT(CURDATE()-INTERVAL 6 DAY,' 08:02:00'),17.5453,78.5731,'NFC')
ON DUPLICATE KEY UPDATE alighting_time=VALUES(alighting_time),verification_method=VALUES(verification_method);

INSERT INTO gps_locations (location_id,bus_id,latitude,longitude,recorded_at) VALUES
(1,1,17.4938,78.3915,CONCAT(CURDATE(),' 07:00:00')),(2,1,17.4890,78.4010,CONCAT(CURDATE(),' 07:20:00')),
(3,1,17.4849,78.4108,CONCAT(CURDATE(),' 07:38:00')),(4,1,17.4933,78.3915,CONCAT(CURDATE(),' 07:50:00')),
(5,2,17.4991,78.4192,CONCAT(CURDATE(),' 07:45:00')),(6,3,17.4374,78.4482,CONCAT(CURDATE(),' 07:46:00')),
(7,4,17.4483,78.3915,CONCAT(CURDATE(),' 07:40:00')),(8,5,17.4938,78.3915,CONCAT(CURDATE(),' 07:47:00')),
(9,6,17.4975,78.3532,CONCAT(CURDATE(),' 07:45:00')),(10,7,17.4239,78.4738,CONCAT(CURDATE(),' 07:35:00')),
(11,8,17.4483,78.3915,CONCAT(CURDATE(),' 07:32:00'))
ON DUPLICATE KEY UPDATE latitude=VALUES(latitude),longitude=VALUES(longitude),recorded_at=VALUES(recorded_at);

INSERT INTO alerts (alert_id,student_id,bus_id,alert_type,message,created_at,status) VALUES
(1,1,1,'Route Deviation','BUS-01 has moved away from the planned route.',CONCAT(CURDATE(),' 07:55:00'),'unread'),
(2,NULL,4,'GPS Offline','GPS device GPS004 is not responding.',CONCAT(CURDATE(),' 07:45:00'),'unread'),
(3,NULL,3,'Bus Delay','BUS-03 is delayed by approximately 8 minutes.',CONCAT(CURDATE(),' 07:40:00'),'unread'),
(4,4,4,'Boarding Alert','Expected student has not been verified.',CONCAT(CURDATE(),' 07:35:00'),'read'),
(5,1,1,'Boarding Verified','Moksha successfully boarded BUS-01 via QR verification.',CONCAT(CURDATE(),' 07:32:00'),'read'),
(6,NULL,2,'Bus On Route','BUS-02 is currently following the planned route.',CONCAT(CURDATE(),' 07:45:00'),'read'),
(7,1,1,'Trip Started','BUS-01 departed from the depot for the morning trip.',CONCAT(CURDATE(),' 07:00:00'),'read'),
(8,NULL,1,'GPS Unavailable','GPS signal from BUS-01 was briefly unavailable near Kukatpally.',CONCAT(CURDATE()-INTERVAL 1 DAY,' 08:12:00'),'read'),
(9,1,1,'Alighting Verified','Moksha alighted safely at KLH University.',CONCAT(CURDATE()-INTERVAL 1 DAY,' 08:06:00'),'read')
ON DUPLICATE KEY UPDATE message=VALUES(message),status=VALUES(status);
