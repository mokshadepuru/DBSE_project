-- =========================================================================
-- SafeRide — school_bus_safety schema
-- Matches the existing table structure exactly. Safe to re-run: every
-- CREATE TABLE uses IF NOT EXISTS, so it will not touch tables that already
-- exist in your database.
-- =========================================================================

CREATE DATABASE IF NOT EXISTS school_bus_safety;
USE school_bus_safety;

CREATE TABLE IF NOT EXISTS students (
  student_id     INT AUTO_INCREMENT PRIMARY KEY,
  name           VARCHAR(120) NOT NULL,
  roll_number    VARCHAR(40)  NOT NULL UNIQUE,
  parent_name    VARCHAR(120) NOT NULL,
  parent_phone   VARCHAR(30)  NOT NULL,
  pickup_stop    VARCHAR(120) NOT NULL,
  drop_stop      VARCHAR(120) NOT NULL
);

CREATE TABLE IF NOT EXISTS buses (
  bus_id               INT AUTO_INCREMENT PRIMARY KEY,
  bus_number           VARCHAR(30)  NOT NULL UNIQUE,
  registration_number  VARCHAR(30)  NOT NULL,
  capacity             INT          NOT NULL,
  gps_device_id        VARCHAR(30)  NOT NULL
);

CREATE TABLE IF NOT EXISTS drivers (
  driver_id       INT AUTO_INCREMENT PRIMARY KEY,
  name            VARCHAR(120) NOT NULL,
  phone           VARCHAR(30)  NOT NULL,
  license_number  VARCHAR(40)  NOT NULL
);

CREATE TABLE IF NOT EXISTS routes (
  route_id        INT AUTO_INCREMENT PRIMARY KEY,
  route_name      VARCHAR(80)  NOT NULL,
  start_location  VARCHAR(120) NOT NULL,
  destination     VARCHAR(120) NOT NULL
);

CREATE TABLE IF NOT EXISTS trips (
  trip_id     INT AUTO_INCREMENT PRIMARY KEY,
  bus_id      INT NOT NULL,
  driver_id   INT NOT NULL,
  route_id    INT NOT NULL,
  trip_date   DATE NOT NULL,
  start_time  TIME NOT NULL,
  end_time    TIME NULL,
  FOREIGN KEY (bus_id)    REFERENCES buses(bus_id),
  FOREIGN KEY (driver_id) REFERENCES drivers(driver_id),
  FOREIGN KEY (route_id)  REFERENCES routes(route_id)
);

CREATE TABLE IF NOT EXISTS boarding_records (
  boarding_id           INT AUTO_INCREMENT PRIMARY KEY,
  student_id            INT NOT NULL,
  trip_id               INT NOT NULL,
  boarding_time         DATETIME NOT NULL,
  boarding_latitude     DECIMAL(10, 6) NOT NULL,
  boarding_longitude    DECIMAL(10, 6) NOT NULL,
  verification_method   VARCHAR(20) NOT NULL,
  FOREIGN KEY (student_id) REFERENCES students(student_id),
  FOREIGN KEY (trip_id)    REFERENCES trips(trip_id)
);

CREATE TABLE IF NOT EXISTS alighting_records (
  alighting_id          INT AUTO_INCREMENT PRIMARY KEY,
  student_id            INT NOT NULL,
  trip_id               INT NOT NULL,
  alighting_time        DATETIME NOT NULL,
  alighting_latitude    DECIMAL(10, 6) NOT NULL,
  alighting_longitude   DECIMAL(10, 6) NOT NULL,
  verification_method   VARCHAR(20) NOT NULL,
  FOREIGN KEY (student_id) REFERENCES students(student_id),
  FOREIGN KEY (trip_id)    REFERENCES trips(trip_id)
);

CREATE TABLE IF NOT EXISTS gps_locations (
  location_id   INT AUTO_INCREMENT PRIMARY KEY,
  bus_id        INT NOT NULL,
  latitude      DECIMAL(10, 6) NOT NULL,
  longitude     DECIMAL(10, 6) NOT NULL,
  recorded_at   DATETIME NOT NULL,
  FOREIGN KEY (bus_id) REFERENCES buses(bus_id)
);

CREATE TABLE IF NOT EXISTS alerts (
  alert_id     INT AUTO_INCREMENT PRIMARY KEY,
  student_id   INT NULL,
  bus_id       INT NULL,
  alert_type   VARCHAR(60) NOT NULL,
  message      VARCHAR(255) NOT NULL,
  created_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  status       VARCHAR(20) NOT NULL DEFAULT 'unread',
  FOREIGN KEY (student_id) REFERENCES students(student_id),
  FOREIGN KEY (bus_id)     REFERENCES buses(bus_id)
);

CREATE INDEX idx_boarding_student   ON boarding_records(student_id);
CREATE INDEX idx_alighting_student  ON alighting_records(student_id);
CREATE INDEX idx_gps_bus_recorded   ON gps_locations(bus_id, recorded_at);
CREATE INDEX idx_alerts_student     ON alerts(student_id);
CREATE INDEX idx_trips_bus_date     ON trips(bus_id, trip_date);
