const express = require("express");
const cors = require("cors");
require("dotenv").config();

const { checkConnection } = require("./db");

const studentsRoutes = require("./routes/studentsRoutes");
const busesRoutes = require("./routes/busesRoutes");
const driversRoutes = require("./routes/driversRoutes");
const routesRoutes = require("./routes/routesRoutes");
const tripsRoutes = require("./routes/tripsRoutes");
const boardingRoutes = require("./routes/boardingRoutes");
const alightingRoutes = require("./routes/alightingRoutes");
const gpsRoutes = require("./routes/gpsRoutes");
const alertsRoutes = require("./routes/alertsRoutes");
const adminRoutes = require("./routes/adminRoutes");
const dashboardRoutes = require("./routes/dashboardRoutes");

const app = express();
const PORT = Number(process.env.PORT) || 5000;
const FRONTEND_ORIGIN = process.env.FRONTEND_ORIGIN || "http://localhost:5173";

app.use(cors({ origin: FRONTEND_ORIGIN === "*" ? true : FRONTEND_ORIGIN }));
app.use(express.json());

app.get("/", (req, res) => {
  res.json({
    name: "SafeRide API",
    status: "running",
    database: "school_bus_safety",
  });
});

app.get("/api/health", async (req, res) => {
  const db = await checkConnection();
  res.status(db.connected ? 200 : 503).json({
    api: "ok",
    database: db.connected ? "connected" : "disconnected",
    ...(db.error ? { error: db.error } : {}),
  });
});

app.use("/api/dashboard", dashboardRoutes);
app.use("/api/students", studentsRoutes);
app.use("/api/buses", busesRoutes);
app.use("/api/drivers", driversRoutes);
app.use("/api/routes", routesRoutes);
app.use("/api/trips", tripsRoutes);
app.use("/api/boarding", boardingRoutes);
app.use("/api/alighting", alightingRoutes);
app.use("/api/gps", gpsRoutes);
app.use("/api/alerts", alertsRoutes);
app.use("/api/admin", adminRoutes);

app.use((req, res) => {
  res.status(404).json({ error: "Endpoint not found" });
});

app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({
    error: "Internal server error",
    message: err.message,
  });
});

async function start() {
  const db = await checkConnection();
  if (!db.connected) {
    console.error("MySQL connection failed:", db.error);
    console.error("Check backend/.env and make sure MySQL is running.");
    process.exit(1);
  }

  app.listen(PORT, () => {
    console.log(`SafeRide API running on http://localhost:${PORT}`);
    console.log(`Frontend origin: ${FRONTEND_ORIGIN}`);
    console.log("MySQL connected: school_bus_safety");
  });
}

start();

module.exports = app;
