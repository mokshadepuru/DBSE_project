const express = require("express");
const controller = require("../controllers/studentsController");
const router = express.Router();
router.get("/", controller.getAllStudents);
router.get("/:id/history", controller.getStudentHistory);
router.get("/:id", controller.getStudentById);
module.exports = router;
