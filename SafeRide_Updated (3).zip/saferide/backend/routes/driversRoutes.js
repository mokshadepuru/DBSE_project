const express = require("express");
const controller = require("../controllers/driversController");
const router = express.Router();
router.get("/", controller.getAllDrivers);
router.get("/:id", controller.getDriverById);
module.exports = router;
