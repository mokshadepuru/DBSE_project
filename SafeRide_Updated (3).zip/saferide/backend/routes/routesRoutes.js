const express = require("express");
const controller = require("../controllers/routesController");
const router = express.Router();
router.get("/", controller.getAllRoutes);
router.get("/:id", controller.getRouteById);
module.exports = router;
