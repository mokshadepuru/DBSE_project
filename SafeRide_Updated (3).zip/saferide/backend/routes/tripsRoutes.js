const express = require("express");
const controller = require("../controllers/tripsController");
const router = express.Router();
router.get("/", controller.getAllTrips);
router.get("/active", controller.getActiveTrip);
router.get("/:id/boarding", controller.getTripBoarding);
router.get("/:id/alighting", controller.getTripAlighting);
router.get("/:id", controller.getTripById);
module.exports = router;
