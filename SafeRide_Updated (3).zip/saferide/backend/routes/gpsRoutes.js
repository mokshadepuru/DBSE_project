const express = require("express");
const controller = require("../controllers/gpsController");
const router = express.Router();
router.get("/", controller.getLatestGps);
router.post("/", controller.createGps);
module.exports = router;
