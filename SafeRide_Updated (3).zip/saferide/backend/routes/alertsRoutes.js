const express = require("express");
const controller = require("../controllers/alertsController");
const router = express.Router();
router.get("/", controller.getAlerts);
router.patch("/:id/read", controller.markRead);
router.post("/", controller.createAlert);
module.exports = router;
