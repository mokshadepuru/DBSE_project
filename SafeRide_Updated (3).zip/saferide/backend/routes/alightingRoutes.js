const express = require("express");
const controller = require("../controllers/alightingController");
const router = express.Router();
router.get("/", controller.getAllAlighting);
router.post("/", controller.createAlighting);
module.exports = router;
