const express = require("express");
const controller = require("../controllers/boardingController");
const router = express.Router();
router.get("/", controller.getAllBoarding);
router.post("/", controller.createBoarding);
module.exports = router;
