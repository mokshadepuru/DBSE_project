const express = require("express");
const controller = require("../controllers/busesController");
const router = express.Router();
router.get("/", controller.getAllBuses);
router.get("/:id/locations", controller.getBusLocations);
router.get("/:id", controller.getBusById);
module.exports = router;
