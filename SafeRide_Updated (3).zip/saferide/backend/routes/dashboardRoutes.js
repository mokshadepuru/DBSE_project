const express = require("express");
const { getParentDashboard } = require("../controllers/dashboardController");
const router = express.Router();
router.get("/", getParentDashboard);
module.exports = router;
