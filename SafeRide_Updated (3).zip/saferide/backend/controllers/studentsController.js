const { pool } = require("../db");
const { asyncHandler, isValidId, formatTime, formatDate } = require("./helpers");

const getAllStudents = asyncHandler(async (req, res) => {
  const [rows] = await pool.query(`
    SELECT s.*,
      COALESCE(b.bus_number, '—') AS bus,
      CASE WHEN br.boarding_id IS NOT NULL AND ar.alighting_id IS NULL THEN 'On Bus'
           WHEN ar.alighting_id IS NOT NULL THEN 'Alighted'
           ELSE 'Not Boarded' END AS status
    FROM students s
    LEFT JOIN (
      SELECT br1.student_id, br1.trip_id
      FROM boarding_records br1
      JOIN trips t1 ON t1.trip_id = br1.trip_id
      JOIN (
        SELECT student_id, MAX(boarding_time) max_time
        FROM boarding_records GROUP BY student_id
      ) x ON x.student_id=br1.student_id AND x.max_time=br1.boarding_time
    ) latest ON latest.student_id=s.student_id
    LEFT JOIN trips t ON t.trip_id=latest.trip_id
    LEFT JOIN buses b ON b.bus_id=t.bus_id
    LEFT JOIN boarding_records br ON br.student_id=s.student_id AND br.trip_id=latest.trip_id
    LEFT JOIN alighting_records ar ON ar.student_id=s.student_id AND ar.trip_id=latest.trip_id
    ORDER BY s.name
  `);
  res.json(rows);
});

const getStudentById = asyncHandler(async (req, res) => {
  const { id } = req.params;
  if (!isValidId(id)) return res.status(400).json({ error: "Student id must be a number." });
  const [studentRows] = await pool.query("SELECT * FROM students WHERE student_id=?", [id]);
  if (!studentRows.length) return res.status(404).json({ error: "Student not found." });
  const student = studentRows[0];

  const [tripRows] = await pool.query(`
    SELECT t.trip_id,t.trip_date,t.start_time,t.end_time,
      b.bus_id,b.bus_number,b.registration_number,b.gps_device_id,
      d.driver_id,d.name driver_name,d.phone driver_phone,
      r.route_id,r.route_name,r.start_location,r.destination,
      br.boarding_id,br.boarding_time,br.boarding_latitude,br.boarding_longitude,
      br.verification_method boarding_verification,
      ar.alighting_id,ar.alighting_time,ar.alighting_latitude,ar.alighting_longitude,
      ar.verification_method alighting_verification
    FROM boarding_records br
    JOIN trips t ON t.trip_id=br.trip_id
    JOIN buses b ON b.bus_id=t.bus_id
    JOIN drivers d ON d.driver_id=t.driver_id
    JOIN routes r ON r.route_id=t.route_id
    LEFT JOIN alighting_records ar ON ar.trip_id=br.trip_id AND ar.student_id=br.student_id
    WHERE br.student_id=? ORDER BY br.boarding_time DESC LIMIT 1
  `,[id]);

  const currentTrip = tripRows[0] || null;
  const status = !currentTrip ? "No trip on record" : currentTrip.alighting_time ? "Alighted" : "Currently on bus";
  res.json({
    ...student,
    status,
    currentTrip: currentTrip ? {
      ...currentTrip,
      start_time: formatTime(currentTrip.start_time),
      end_time: formatTime(currentTrip.end_time),
      boarding_time: formatTime(currentTrip.boarding_time),
      alighting_time: formatTime(currentTrip.alighting_time)
    } : null
  });
});

const getStudentHistory = asyncHandler(async (req,res)=>{
  const {id}=req.params;
  if(!isValidId(id)) return res.status(400).json({error:"Student id must be a number."});
  const [exists]=await pool.query("SELECT student_id FROM students WHERE student_id=?",[id]);
  if(!exists.length) return res.status(404).json({error:"Student not found."});
  const [rows]=await pool.query(`
    SELECT t.trip_id,t.trip_date,t.end_time,b.bus_number,r.route_name,
      br.boarding_time,br.verification_method boarding_verification,
      ar.alighting_time,ar.verification_method alighting_verification
    FROM trips t JOIN buses b ON b.bus_id=t.bus_id JOIN routes r ON r.route_id=t.route_id
    LEFT JOIN boarding_records br ON br.trip_id=t.trip_id AND br.student_id=?
    LEFT JOIN alighting_records ar ON ar.trip_id=t.trip_id AND ar.student_id=?
    WHERE t.bus_id=COALESCE(
      (SELECT t2.bus_id FROM boarding_records br2 JOIN trips t2 ON t2.trip_id=br2.trip_id
       WHERE br2.student_id=? ORDER BY br2.boarding_time DESC LIMIT 1),
      (SELECT bus_id FROM buses ORDER BY bus_id LIMIT 1)
    )
    ORDER BY t.trip_date DESC,t.start_time DESC
  `,[id,id,id]);
  const history=rows.map(r=>({
    trip_id:r.trip_id,date:formatDate(r.trip_date),bus:r.bus_number,route:r.route_name,
    boarded:formatTime(r.boarding_time)||"—",alighted:formatTime(r.alighting_time)||"—",
    verification:r.boarding_verification||r.alighting_verification||"—",
    status:r.alighting_time?"Completed":r.boarding_time?(!r.end_time?"In Progress":"Completed"):"Missed"
  }));
  res.json(history);
});
module.exports={getAllStudents,getStudentById,getStudentHistory};
