function asyncHandler(fn) {
  return (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);
}
function isValidId(value) {
  return /^\d+$/.test(String(value));
}
function formatTime(value) {
  if (!value) return null;
  const text = String(value);
  const match = text.match(/(\d{2}):(\d{2})(?::\d{2})?/);
  if (!match) return text;
  let h = Number(match[1]);
  const m = match[2];
  const suffix = h >= 12 ? "PM" : "AM";
  h = h % 12 || 12;
  return `${String(h).padStart(2, "0")}:${m} ${suffix}`;
}
function formatDate(value) {
  if (!value) return null;
  const d = new Date(value);
  if (Number.isNaN(d.getTime())) return String(value);
  return d.toLocaleDateString("en-GB", { day: "2-digit", month: "short", year: "numeric" });
}
function minutesAgo(value) {
  const d = new Date(value);
  if (Number.isNaN(d.getTime())) return "Unknown";
  const mins = Math.max(0, Math.round((Date.now() - d.getTime()) / 60000));
  return mins < 1 ? "just now" : `${mins} min ago`;
}
module.exports = { asyncHandler, isValidId, formatTime, formatDate, minutesAgo };
