const {pool}=require("../db");
const {asyncHandler,isValidId,minutesAgo,formatTime}=require("./helpers");
const getAllBuses=asyncHandler(async(req,res)=>{
 const [rows]=await pool.query(`
 SELECT b.*, COALESCE(d.name,'—') driver, COALESCE(r.route_name,'—') route,
 CASE WHEN t.trip_id IS NOT NULL AND t.end_time IS NULL THEN 'On Route' ELSE 'Idle' END status,
 CASE WHEN g.recorded_at IS NULL OR TIMESTAMPDIFF(MINUTE,g.recorded_at,NOW())>10 THEN 'Offline' ELSE 'Active' END gps_status,
 COALESCE(g.recorded_at,NULL) last_gps
 FROM buses b
 LEFT JOIN trips t ON t.trip_id=(SELECT t2.trip_id FROM trips t2 WHERE t2.bus_id=b.bus_id ORDER BY t2.trip_date DESC,t2.start_time DESC LIMIT 1)
 LEFT JOIN drivers d ON d.driver_id=t.driver_id LEFT JOIN routes r ON r.route_id=t.route_id
 LEFT JOIN gps_locations g ON g.location_id=(SELECT g2.location_id FROM gps_locations g2 WHERE g2.bus_id=b.bus_id ORDER BY g2.recorded_at DESC LIMIT 1)
 ORDER BY b.bus_number`);
 res.json(rows.map(x=>({...x,last_updated:x.last_gps?minutesAgo(x.last_gps):"Never"})));
});
const getBusById=asyncHandler(async(req,res)=>{
 const {id}=req.params;if(!isValidId(id))return res.status(400).json({error:"Bus id must be a number."});
 const [b]=await pool.query("SELECT * FROM buses WHERE bus_id=?",[id]);if(!b.length)return res.status(404).json({error:"Bus not found."});
 const [t]=await pool.query(`SELECT t.*,d.name driver_name,d.phone driver_phone,r.route_name,r.start_location,r.destination FROM trips t JOIN drivers d ON d.driver_id=t.driver_id JOIN routes r ON r.route_id=t.route_id WHERE t.bus_id=? ORDER BY t.trip_date DESC,t.start_time DESC LIMIT 1`,[id]);
 const [g]=await pool.query("SELECT latitude,longitude,recorded_at FROM gps_locations WHERE bus_id=? ORDER BY recorded_at DESC LIMIT 1",[id]);
 res.json({...b[0],status:t[0]&&!t[0].end_time?"On Route":"Idle",currentTrip:t[0]||null,lastKnownLocation:g[0]?{...g[0],recorded_at:g[0].recorded_at}:null});
});
const getBusLocations=asyncHandler(async(req,res)=>{
 const {id}=req.params;if(!isValidId(id))return res.status(400).json({error:"Bus id must be a number."});
 const [rows]=await pool.query("SELECT * FROM gps_locations WHERE bus_id=? ORDER BY recorded_at ASC",[id]);res.json(rows);
});
module.exports={getAllBuses,getBusById,getBusLocations};
