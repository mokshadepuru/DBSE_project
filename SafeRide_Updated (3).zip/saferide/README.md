# SafeRide — School Bus Tracking & Student Safety Portal

SafeRide is a React + Node.js/Express + MySQL prototype for school-bus visibility and student journey verification.

## Architecture

```text
React Frontend (5173)
        ↓ REST/JSON
Node.js + Express API (5000)
        ↓
MySQL: school_bus_safety
```

GPS belongs to the **bus**, while QR/RFID/NFC verification associates a student with a bus trip.

## 1. Start MySQL

Make sure MySQL is running.

## 2. Configure the backend

Open `backend/.env` and set your MySQL credentials:

```env
PORT=5000
DB_HOST=localhost
DB_PORT=3306
DB_USER=root
DB_PASSWORD=
DB_NAME=school_bus_safety
FRONTEND_ORIGIN=http://localhost:5173
```

Do not commit `.env`.

## 3. Initialize the database

Open a terminal inside `backend`:

```bash
npm install
npm run db:init
```

This creates the `school_bus_safety` database/tables and loads SafeRide demo data.

## 4. Start the backend

Still inside `backend`:

```bash
npm run dev
```

The API runs at:

`http://localhost:5000`

Health check:

`http://localhost:5000/api/health`

## 5. Start the frontend

Open a second terminal in the project root:

```bash
npm install
npm run dev
```

Open the Vite URL, normally:

`http://localhost:5173`

The frontend automatically requests live data from the backend every 30 seconds. If the backend is temporarily unavailable, the original demo data remains visible.

## Main API endpoints

| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/api/health` | API + MySQL status |
| GET | `/api/dashboard?student_id=1` | Parent dashboard data |
| GET | `/api/students` | All students |
| GET | `/api/students/:id` | Student + current trip |
| GET | `/api/students/:id/history` | Journey history |
| GET | `/api/buses` | Fleet |
| GET | `/api/buses/:id` | Bus details |
| GET | `/api/buses/:id/locations` | Bus GPS history |
| GET | `/api/drivers` | Drivers |
| GET | `/api/routes` | Routes |
| GET | `/api/trips` | Trips |
| GET | `/api/trips/active` | Active trip |
| GET | `/api/trips/:id/boarding` | Trip boarding records |
| GET | `/api/trips/:id/alighting` | Trip alighting records |
| GET | `/api/boarding` | All boarding records |
| POST | `/api/boarding` | Record boarding |
| GET | `/api/alighting` | All alighting records |
| POST | `/api/alighting` | Record alighting |
| GET | `/api/gps` | Latest GPS per bus |
| POST | `/api/gps` | Record GPS position |
| GET | `/api/alerts` | Alerts |
| PATCH | `/api/alerts/:id/read` | Mark alert read |
| POST | `/api/alerts` | Create alert |
| GET | `/api/admin/dashboard` | Admin dashboard |
| GET | `/api/admin/students` | Admin student view |
| GET | `/api/admin/buses` | Admin fleet view |
| GET | `/api/admin/drivers` | Admin driver view |
| GET | `/api/admin/trips` | Admin trip view |
| GET | `/api/admin/boarding` | Admin boarding view |
| GET | `/api/admin/alighting` | Admin alighting view |
| GET | `/api/admin/gps` | Admin GPS monitoring |
| GET | `/api/admin/alerts` | Admin alerts |

## Project structure

```text
saferide/
├── backend/
│   ├── controllers/
│   ├── routes/
│   ├── scripts/
│   ├── sql/
│   ├── db.js
│   ├── server.js
│   ├── package.json
│   └── .env.example
├── src/
│   ├── components/
│   ├── context/
│   │   └── SafeRideDataContext.jsx
│   ├── data/
│   ├── pages/
│   └── App.jsx
├── package.json
└── README.md
```

## Notes

This is a college prototype. The backend uses local MySQL demo data and simulated GPS records. A real deployment would add authenticated users, role-based authorization, secure secrets, real GPS-device ingestion, and push notification infrastructure.
